<?php
if (!defined('ABSPATH')) exit;

class GGLCT_AIOP_Utils {

    public static function get_default_options() {
        return [
            'api_key' => '',
            'default_text_model' => GGLCT_AIOP_DEFAULT_MODEL,
            'default_max_tokens' => 2000,
            'default_temperature' => 0.7,
            'default_image_model' => 'dall-e-3',
            'default_image_size' => '1024x1024',
            'default_image_quality' => 'standard',
            'default_image_style' => 'vivid',
            'enable_logging' => 'yes',
            'enabled_post_types' => ['post', 'page'],
            'text_prompt_templates' => [
                'blog_post' => __("نوشتن یک مقاله جامع و کامل درباره [TOPIC] با عنوان [TITLE]. مقاله باید حداقل [WORD_COUNT] کلمه باشد...", 'gglct-ai-optimizer-pro'),
            ],
            'image_prompt_templates' => [
                'featured_image' => __("یک تصویر هنری و جذاب برای مقاله‌ای با موضوع [TOPIC]، سبک [STYLE]", 'gglct-ai-optimizer-pro'),
            ],
            'usdt_manual_rate' => '0',
            'usdt_auto_fetch' => 'yes',
            'cost_calculation_enabled' => 'yes',
        ];
    }

    public static function check_api_key_and_permission(\$capability = 'edit_posts', \$allow_if_key_missing_for_settings = false) {
        if (!current_user_can(\$capability)) {
            if (!wp_doing_ajax()) {
                wp_die(__('شما اجازه انجام این عملیات را ندارید.', 'gglct-ai-optimizer-pro'));
            }
            return false;
        }
        \$api_key = get_option('gglct_aiop_api_key');
        if (empty(\$api_key)) {
            if (\$allow_if_key_missing_for_settings && \$capability === 'manage_options' && strpos(get_current_screen()->id, 'gglct-ai-optimizer-pro-settings') !== false) {
                // Allow access to settings page if only API key is missing
            } else {                if (!wp_doing_ajax()) {
                     echo '<div class="notice notice-error is-dismissible"><p>' . sprintf('%s <a href="%s">%s</a>. %s <a href="https://gglct.com" target="_blank">%s</a>.', __('لطفا ابتدا کلید API خود را از صفحه تنظیمات وارد کنید.', 'gglct-ai-optimizer-pro'), esc_url(admin_url('admin.php?page=gglct-ai-optimizer-pro-settings')), __('رفتن به تنظیمات', 'gglct-ai-optimizer-pro'), __('برای دریافت کلید API به', 'gglct-ai-optimizer-pro'), __('وبسایت GGLCT', 'gglct-ai-optimizer-pro')) . '</p></div>';
                }
                return false;            }
        }
        return \$api_key; // Returns API key if valid, or true if key missing but allowed
    }

    public static function get_page_common_data(\$include_image_models = false, \$include_text_models = true) {
        \$data = [
            'text_prompt_templates' => get_option('gglct_aiop_text_prompt_templates', self::get_default_options()['text_prompt_templates']),
            'image_prompt_templates' => get_option('gglct_aiop_image_prompt_templates', self::get_default_options()['image_prompt_templates']),
            'available_text_models' => [],
            'available_image_models' => [],
            'default_text_model' => get_option('gglct_aiop_default_text_model', GGLCT_AIOP_DEFAULT_MODEL),
            'default_image_model' => get_option('gglct_aiop_default_image_model', 'dall-e-3'),
        ];

        if (\$include_text_models) {
            \$text_models_full = self::get_models_from_cache_or_api('text');
            \$data['available_text_models'] = self::format_models_for_select(\$text_models_full);
            \$data['all_text_models_data'] = \$text_models_full;
        }
        if (\$include_image_models) {
            \$image_models_full = self::get_models_from_cache_or_api('image');
            \$data['available_image_models'] = self::format_models_for_select(\$image_models_full);            \$data['all_image_models_data'] = \$image_models_full;
            \$data['image_model_details'] = self::get_all_image_model_details_structured(\$image_models_full);
        }
        return \$data;
    }

    public static function get_models_from_cache_or_api(\$type = 'text') {
        \$cache_key = 'gglct_aiop_models_data_cache_' . \$type;
        \$cached_models = get_transient(\$cache_key);
        if (false !== \$cached_models && is_array(\$cached_models)) {
            return \$cached_models;
        }

        \$api_key = get_option('gglct_aiop_api_key');
        if (empty(\$api_key)) return [];

        \$response = GGLCT_AIOP_API_Handler::make_api_request([], 'models', 'GET');
        if (is_wp_error(\$response)) return [];

        \$response_body = json_decode(wp_remote_retrieve_body(\$response), true);        if (isset(\$response_body['data']) && is_array(\$response_body['data'])) {
            \$all_models = \$response_body['data'];
            \$filtered_models = [];            foreach (\$all_models as \$model) {
                // Basic filtering, can be expanded
                if (\$type === 'text' && (strpos(\$model['id'], 'gpt') !== false || strpos(\$model['id'], 'gemini') !== false || strpos(\$model['id'], 'claude') !== false)) {
                    if (isset(\$model['pricing']['input']) || isset(\$model['pricing']['output'])) { // Ensure it has pricing
                        \$filtered_models[] = \$model;
                    }
                } elseif (\$type === 'image' && (strpos(\$model['id'], 'dall-e') !== false || strpos(\$model['id'], 'stable-diffusion') !== false ) ) {
                     if (isset(\$model['pricing']['standard']) || isset(\$model['pricing']['hd']) || isset(\$model['pricing']['per_request'])) { // Image pricing structure
                        \$filtered_models[] = \$model;
                    }
                }            }
            // Sort models, e.g., by ID or a predefined order
            usort(\$filtered_models, function(\$a, \$b) { return strcmp(\$a['id'], \$b['id']); });
            set_transient(\$cache_key, \$filtered_models, HOUR_IN_SECONDS * 12);
            return \$filtered_models;
        }
        return [];
    }

    public static function format_models_for_select(\$models_data) {
        \$formatted = [];
        if (is_array(\$models_data)) {
            foreach (\$models_data as \$model) {
                \$formatted[\$model['id']] = \$model['id']; // Or \$model['name'] if available and preferred
            }
        }
        return \$formatted;
    }
    
    public static function get_image_model_details(\$model_id, \$all_image_models_data = null) {
        if (\$all_image_models_data === null) {
            \$all_image_models_data = self::get_models_from_cache_or_api('image');
        }
        foreach (\$all_image_models_data as \$model) {
            if (\$model['id'] === \$model_id) {                return [
                    'id' => \$model['id'],
                    'name' => \$model['name'] ?? \$model['id'],
                    'sizes' => \$model['capabilities']['sizes'] ?? ['1024x1024'],
                    'qualities' => \$model['capabilities']['qualities'] ?? ['standard'],
                    'styles' => \$model['capabilities']['styles'] ?? ['vivid', 'natural'], // For DALL-E 3
                    'max_per_request' => \$model['capabilities']['max_n'] ?? 1,
                    'pricing' => \$model['pricing'] ?? [],
                ];
            }
        }
        // Fallback for DALL-E if not found in API response (should ideally be from API)
        if (\$model_id === 'dall-e-3') return ['id'=>'dall-e-3', 'name'=>'DALL·E 3', 'sizes'=>['1024x1024', '1792x1024', '1024x1792'], 'qualities'=>['standard', 'hd'], 'styles'=>['vivid', 'natural'], 'max_per_request'=>1, 'pricing'=>['standard'=>0.04, 'hd'=>0.08]];
        if (\$model_id === 'dall-e-2') return ['id'=>'dall-e-2', 'name'=>'DALL·E 2', 'sizes'=>['256x256', '512x512', '1024x1024'], 'qualities'=>['standard'], 'styles'=>[], 'max_per_request'=>10, 'pricing'=>['standard_1024x1024'=>0.02, 'standard_512x512'=>0.018, 'standard_256x256'=>0.016]];
        return null;
    }
    
    public static function get_all_image_model_details_structured(\$all_image_models_data = null){
        if (\$all_image_models_data === null) {
            \$all_image_models_data = self::get_models_from_cache_or_api('image');
        }
        \$structured_details = [];
        foreach(\$all_image_models_data as \$model_data){
            \$details = self::get_image_model_details(\$model_data['id'], \$all_image_models_data);
            if(\$details) \$structured_details[\$model_data['id']] = \$details;
        }
        return \$structured_details;
    }

    public static function get_system_message_for_prompt(\$prompt) {
        \$default_system_message = __("شما یک دستیار هوش مصنوعی هستید که به زبان فارسی محتوای با کیفیت، دقیق و بهینه شده برای موتورهای جستجو تولید می‌کنید. پاسخ‌های شما باید دارای ساختار مناسب HTML با استفاده از تگ‌های h2, h3, p, ul, ol, li, strong, em باشد. از تگ h1 استفاده نکنید. پاسخ باید کاملا به زبان فارسی باشد مگر اینکه در پرامپت به صراحت زبان دیگری خواسته شده باشد.", 'gglct-ai-optimizer-pro');
        // Add more sophisticated language/intent detection if needed
        if (preg_match('/(ترجمه کن به انگلیسی|translate to english)/ui', \$prompt)) {
            return 'You are an AI assistant. Translate the given Persian text to English. Provide only the English translation. If the original text contains HTML, preserve the HTML structure in the English translation.';
        }
        return \$default_system_message;
    }

    public static function calculate_request_cost(\$type, \$model_id, \$input_tokens = 0, \$output_tokens = 0, \$num_images = 0, \$image_size = '', \$image_quality = '') {
        \$cost_usd = 0.0;
        \$usdt_rate_str = get_option('gglct_aiop_usdt_manual_rate', '0');
        \$usdt_rate = floatval(str_replace(',', '.', \$usdt_rate_str));

        if (get_option('gglct_aiop_cost_calculation_enabled', 'yes') !== 'yes') {
            return ['usd' => 0, 'toman' => 0, 'rate' => \$usdt_rate];
        }        \$all_models = self::get_models_from_cache_or_api(\$type);
        \$model_pricing_data = null;
        foreach (\$all_models as \$m) {
            if (\$m['id'] === \$model_id) {
                \$model_pricing_data = \$m['pricing'] ?? null;
                break;
            }
        }

        if (\$model_pricing_data) {            if (\$type === 'text') {
                \$input_price_pm = floatval(\$model_pricing_data['input'] ?? (\$model_pricing_data['cached_input'] ?? 0));
                \$output_price_pm = floatval(\$model_pricing_data['output'] ?? 0);
                \$cost_usd = ((\$input_tokens / 1000000) * \$input_price_pm) + ((\$output_tokens / 1000000) * \$output_price_pm);
            } elseif (\$type === 'image' && \$num_images > 0) {
                if (\$model_id === 'dall-e-3') {
                    \$price_per_image = floatval(\$model_pricing_data[\$image_quality] ?? (\$model_pricing_data['standard'] ?? 0.04));
                    \$cost_usd = \$price_per_image * \$num_images;
                } elseif (\$model_id === 'dall-e-2') {
                    \$price_key = 'standard_' . \$image_size; // e.g. standard_1024x1024                    \$price_per_image = floatval(\$model_pricing_data[\$price_key] ?? (\$model_pricing_data['standard_1024x1024'] ?? 0.02));
                    \$cost_usd = \$price_per_image * \$num_images;
                }                // Add other image models pricing here if needed
            }
        }

        \$cost_toman = (\$usdt_rate > 0) ? (\$cost_usd * \$usdt_rate) : 0;
        return ['usd' => round(\$cost_usd, 6), 'toman' => round(\$cost_toman, 2), 'rate' => \$usdt_rate];
    }

    public static function get_common_script_params() {
        global \$post;
        \$current_post_id = isset(\$post->ID) ? \$post->ID : (isset(\$_GET['post']) ? intval(\$_GET['post']) : 0);
        \$current_post_type = isset(\$post->post_type) ? \$post->post_type : (isset(\$_GET['post_type']) ? sanitize_text_field(\$_GET['post_type']) : 'post');
        if (!\$current_post_type && \$current_post_id) { \$current_post_type = get_post_type(\$current_post_id); }

        \$page_data = self::get_page_common_data(true, true); // Get all models data

        return [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('gglct_aiop_nonce'),
            'wpToolsNonce' => wp_create_nonce('gglct_aiop_wp_tools_nonce'),
            'strings' => self::get_js_strings(),
            'postId' => \$current_post_id,
            'postType' => \$current_post_type,
            'pluginUrl' => GGLCT_AIOP_PLUGIN_URL,
            'isRTL' => is_rtl(),
            'defaultTextModel' => \$page_data['default_text_model'],
            'defaultImageModel' => \$page_data['default_image_model'],
            'usdtManualRate' => floatval(str_replace(',', '.', get_option('gglct_aiop_usdt_manual_rate', '0'))),            'usdtAutoFetch' => get_option('gglct_aiop_usdt_auto_fetch', 'yes') === 'yes',
            'costCalculationEnabled' => get_option('gglct_aiop_cost_calculation_enabled', 'yes') === 'yes',
            'availableTextModels' => \$page_data['available_text_models'],
            'availableImageModels' => \$page_data['available_image_models'],
            'allTextModelsData' => \$page_data['all_text_models_data'],
            'allImageModelsData' => \$page_data['all_image_models_data'],
            'imageModelDetails' => \$page_data['image_model_details'],
            'defaultMaxTokens' => intval(get_option('gglct_aiop_default_max_tokens', 2000)),
            'defaultTemperature' => floatval(get_option('gglct_aiop_default_temperature', 0.7)),
            'defaultImageSize' => get_option('gglct_aiop_default_image_size', '1024x1024'),
            'defaultImageQuality' => get_option('gglct_aiop_default_image_quality', 'standard'),
            'defaultImageStyle' => get_option('gglct_aiop_default_image_style', 'vivid'),
        ];
    }

    public static function get_js_strings() {
        return [
            'generating' => __('در حال تولید...', 'gglct-ai-optimizer-pro'),
            'generatingContent' => __('در حال تولید محتوا...', 'gglct-ai-optimizer-pro'),
            'generatingImage' => __('در حال تولید تصویر...', 'gglct-ai-optimizer-pro'),
            'insertSuccess' => __('محتوا با موفقیت درج شد.', 'gglct-ai-optimizer-pro'),
            'error' => __('خطا در انجام عملیات.', 'gglct-ai-optimizer-pro'),
            'apiError' => __('خطا در ارتباط با API.', 'gglct-ai-optimizer-pro'),
            'confirmDelete' => __('آیا از حذف این مورد اطمینان دارید؟', 'gglct-ai-optimizer-pro'),
            'loadingContent' => __('در حال بارگذاری محتوا...', 'gglct-ai-optimizer-pro'),
            'contentCopied' => __('محتوا با موفقیت کپی شد.', 'gglct-ai-optimizer-pro'),
            'imageCopied' => __('آدرس تصویر کپی شد.', 'gglct-ai-optimizer-pro'),
            'errorFetchingContent' => __('خطا در دریافت محتوا.', 'gglct-ai-optimizer-pro'),
            'errorServerConnection' => __('خطا در ارتباط با سرور.', 'gglct-ai-optimizer-pro'),
            'promptRequired' => __('لطفا یک پرامپت وارد کنید.', 'gglct-ai-optimizer-pro'),
            'apiKeyRequired' => __('لطفا کلید API را وارد کنید.', 'gglct-ai-optimizer-pro'),
            'connectionTestSuccess' => __('ارتباط با API با موفقیت برقرار شد.', 'gglct-ai-optimizer-pro'),
            'connectionTestError' => __('خطا در ارتباط با API.', 'gglct-ai-optimizer-pro'),
            'fetchModelsError' => __('خطا در دریافت اطلاعات مدل‌ها.', 'gglct-ai-optimizer-pro'),
            'tetherRateError' => __('خطا در دریافت نرخ تتر.', 'gglct-ai-optimizer-pro'),
            'tetherRateSource' => __('منبع: تترلند', 'gglct-ai-optimizer-pro'),
            'tetherManualRate' => __('نرخ دستی', 'gglct-ai-optimizer-pro'),
            'tetherRateSavedSuccess' => __('نرخ تتر با موفقیت ذخیره شد.', 'gglct-ai-optimizer-pro'),
            'unknownError' => __('خطای نامشخص.', 'gglct-ai-optimizer-pro'),
            'contentGeneratedSuccess' => __('محتوا با موفقیت تولید شد.', 'gglct-ai-optimizer-pro'),
            'imageGeneratedSuccess' => __('تصویر (ها) با موفقیت تولید شد.', 'gglct-ai-optimizer-pro'),
            'token' => __('توکن', 'gglct-ai-optimizer-pro'),
            'tokens' => __('توکن‌ها', 'gglct-ai-optimizer-pro'),
            'generatedContentTitle' => __('محتوای تولید شده', 'gglct-ai-optimizer-pro'),
            'tokenCount' => __('تعداد توکن', 'gglct-ai-optimizer-pro'),
            'toggleApiKeyVisibility' => __('نمایش/مخفی کردن کلید API', 'gglct-ai-optimizer-pro'),
            'testingConnection' => __('در حال تست اتصال...', 'gglct-ai-optimizer-pro'),
            'tomanUnit' => __('تومان', 'gglct-ai-optimizer-pro'),
            'usdUnit' => __('دلار', 'gglct-ai-optimizer-pro'),
            'priceNotAvailable' => __('نامشخص', 'gglct-ai-optimizer-pro'),
            'clearCache' => __('پاکسازی کش مدل‌ها', 'gglct-ai-optimizer-pro'),
            'cacheCleared' => __('کش مدل‌ها با موفقیت پاک شد.', 'gglct-ai-optimizer-pro'),
            'errorClearingCache' => __('خطا در پاکسازی کش مدل‌ها.', 'gglct-ai-optimizer-pro'),
            'inputTokensEstimate' => __('توکن ورودی (تخمینی):', 'gglct-ai-optimizer-pro'),            'estimatedCostUSD' => __('هزینه تخمینی (دلار):', 'gglct-ai-optimizer-pro'),
            'estimatedCostToman' => __('هزینه تخمینی (تومان):', 'gglct-ai-optimizer-pro'),
            'finalCostUSD' => __('هزینه نهایی (دلار):', 'gglct-ai-optimizer-pro'),
            'finalCostToman' => __('هزینه نهایی (تومان):', 'gglct-ai-optimizer-pro'),
            'imageSize' => __('اندازه تصویر', 'gglct-ai-optimizer-pro'),
            'imageQuality' => __('کیفیت تصویر', 'gglct-ai-optimizer-pro'),
            'imageStyle' => __('سبک تصویر (DALL-E 3)', 'gglct-ai-optimizer-pro'),
            'numImages' => __('تعداد تصاویر', 'gglct-ai-optimizer-pro'),
            'uploadingImage' => __('در حال آپلود تصویر...', 'gglct-ai-optimizer-pro'),
            'imageUploaded' => __('تصویر با موفقیت آپلود شد.', 'gglct-ai-optimizer-pro'),
            'imageSetAsFeatured' => __('تصویر به عنوان شاخص تنظیم شد.', 'gglct-ai-optimizer-pro'),
            'errorUploadingImage' => __('خطا در آپلود تصویر.', 'gglct-ai-optimizer-pro'),
            'downloadingWordPress' => __('در حال دانلود آخرین نسخه وردپرس...', 'gglct-ai-optimizer-pro'),
            'downloadWordPressSuccess' => __('وردپرس با موفقیت دانلود شد.', 'gglct-ai-optimizer-pro'),
            'downloadWordPressError' => __('خطا در دانلود وردپرس.', 'gglct-ai-optimizer-pro'),
        ];
    }    
    public static function get_settings_fields_config(\$text_models = [], \$image_models = [], \$post_types = []) {
        // This would return a structured array for building settings page
        return [ /* ... detailed settings structure ... */ ];
    }
    
    public static function sanitize_setting_field(\$value, \$field_args) {
        \$type = \$field_args['type'] ?? 'text';
        switch (\$type) {
            case 'integer': return intval(\$value);
            case 'float': return floatval(str_replace(',', '.', \$value));
            case 'url': return esc_url_raw(\$value);
            case 'textarea': return sanitize_textarea_field(\$value);
            case 'array': return is_array(\$value) ? array_map('sanitize_text_field', \$value) : [];
            case 'select': // Fallthrough
            case 'text': // Fallthrough
            default: return sanitize_text_field(\$value);
        }
    }
    public static function sanitize_max_tokens(\$value) { return max(50, min(128000, intval(\$value))); }
    public static function sanitize_temperature(\$value) { return max(0, min(2, floatval(\$value))); }
    public static function sanitize_usdt_rate_string(\$value) { \$v_str = str_replace(',', '.', (string)\$value); \$v_f = floatval(\$v_str); return (string)max(0, \$v_f); }

    public static function save_prompt_templates(\$option_key_suffix) {
        \$option_name = 'gglct_aiop_' . \$option_key_suffix;
        \$keys_post_key = 'gglct_aiop_' . \$option_key_suffix . '_keys';
        \$values_post_key = 'gglct_aiop_' . \$option_key_suffix . '_values';

        if (isset(\$_POST[\$keys_post_key]) && isset(\$_POST[\$values_post_key])) {
            \$keys = array_map('sanitize_text_field', \$_POST[\$keys_post_key]);
            \$values = array_map('sanitize_textarea_field', \$_POST[\$values_post_key]);
            \$templates = [];
            for (\$i = 0; \$i < count(\$keys); \$i++) {
                if (!empty(\$keys[\$i]) && !empty(\$values[\$i])) {
                    \$templates[sanitize_key(\$keys[\$i])] = \$values[\$i];
                }
            }
            update_option(\$option_name, \$templates);
        } else {
            update_option(\$option_name, []);
        }
    }
    
    public static function ajax_upload_generated_image() {
        check_ajax_referer('gglct_aiop_nonce', 'nonce');
        if (!current_user_can('upload_files')) {
            wp_send_json_error(['message' => __('شما اجازه آپلود فایل را ندارید.', 'gglct-ai-optimizer-pro')]);
            return;
        }

        \$image_url = isset(\$_POST['image_url']) ? esc_url_raw(\$_POST['image_url']) : '';
        \$post_id = isset(\$_POST['post_id']) ? intval(\$_POST['post_id']) : 0;
        \$set_featured = isset(\$_POST['set_featured']) && \$_POST['set_featured'] === 'true';
        \$image_title_prompt = isset(\$_POST['image_title']) ? sanitize_text_field(\$_POST['image_title']) : '';


        if (empty(\$image_url)) {
            wp_send_json_error(['message' => __('آدرس تصویر نامعتبر است.', 'gglct-ai-optimizer-pro')]);
            return;
        }

        require_once ABSPATH . 'wp-admin/includes/media.php';        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        // Download file to temp location
        \$tmp_file = download_url(\$image_url);
        if (is_wp_error(\$tmp_file)) {
            wp_send_json_error(['message' => __('خطا در دانلود تصویر:', 'gglct-ai-optimizer-pro') . ' ' . \$tmp_file->get_error_message()]);
            return;
        }

        // Prepare file for media_handle_sideload
        \$file_array = [
            'name' => basename(\$image_url) . '.png', // Assume png, or try to detect from URL
            'tmp_name' => \$tmp_file
        ];
        
        // Create a better title if possible
        \$file_title = !empty(\$image_title_prompt) ? sanitize_file_name(\$image_title_prompt) : (\$post_id > 0 ? sanitize_file_name(get_the_title(\$post_id)) : 'gglct-ai-generated-image');
        if (strlen(\$file_title) > 50) \$file_title = substr(\$file_title, 0, 50); // Keep title reasonable

        \$attachment_id = media_handle_sideload(\$file_array, \$post_id, \$file_title);

        @unlink(\$tmp_file); // Delete temp file

        if (is_wp_error(\$attachment_id)) {
            wp_send_json_error(['message' => __('خطا در ذخیره تصویر در کتابخانه:', 'gglct-ai-optimizer-pro') . ' ' . \$attachment_id->get_error_message()]);
            return;
        }

        \$attachment_url = wp_get_attachment_url(\$attachment_id);
        \$response_data = [
            'message' => __('تصویر با موفقیت در کتابخانه ذخیره شد.', 'gglct-ai-optimizer-pro'),
            'attachment_id' => \$attachment_id,
            'attachment_url' => \$attachment_url,
            'thumbnail_html' => wp_get_attachment_image(\$attachment_id, 'thumbnail')
        ];

        if (\$set_featured && \$post_id > 0 && post_type_supports(get_post_type(\$post_id), 'thumbnail')) {
            set_post_thumbnail(\$post_id, \$attachment_id);
            \$response_data['featured_set'] = true;
             \$response_data['message'] .= ' ' . __('و به عنوان تصویر شاخص تنظیم شد.', 'gglct-ai-optimizer-pro');
        }
        wp_send_json_success(\$response_data);
    }
}