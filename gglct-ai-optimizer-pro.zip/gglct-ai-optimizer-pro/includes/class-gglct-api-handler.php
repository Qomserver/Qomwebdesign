<?php
if (!defined('ABSPATH')) exit;

class GGLCT_AIOP_API_Handler {

    public static function ajax_generate_content() {        check_ajax_referer('gglct_aiop_nonce', 'nonce');
        if (!GGLCT_AIOP_Utils::check_api_key_and_permission()) { wp_send_json_error(['message' => __('عدم دسترسی یا کلید API نامعتبر.', 'gglct-ai-optimizer-pro')]); return; }

        \$prompt = isset(\$_POST['prompt']) ? sanitize_textarea_field(\$_POST['prompt']) : '';
        \$model_id = isset(\$_POST['model']) ? sanitize_text_field(\$_POST['model']) : get_option('gglct_aiop_default_text_model', GGLCT_AIOP_DEFAULT_MODEL);
        \$max_tokens = isset(\$_POST['max_tokens']) ? intval(\$_POST['max_tokens']) : intval(get_option('gglct_aiop_default_max_tokens', 2000));
        \$temperature = isset(\$_POST['temperature']) ? floatval(\$_POST['temperature']) : floatval(get_option('gglct_aiop_default_temperature', 0.7));
        \$input_tokens_estimate = isset(\$_POST['input_tokens_estimate']) ? intval(\$_POST['input_tokens_estimate']) : 0;

        if (empty(\$prompt)) { wp_send_json_error(['message' => __('پرامپت نمی‌تواند خالی باشد.', 'gglct-ai-optimizer-pro')]); return; }

        \$system_message = GGLCT_AIOP_Utils::get_system_message_for_prompt(\$prompt);
        \$messages = [['role' => 'user', 'content' => \$prompt]];
        if (\$system_message) {
            array_unshift(\$messages, ['role' => 'system', 'content' => \$system_message]);
        }
        
        \$request_data = [
            'model' => \$model_id,
            'messages' => \$messages,
            'max_tokens' => GGLCT_AIOP_Utils::sanitize_max_tokens(\$max_tokens),
            'temperature' => GGLCT_AIOP_Utils::sanitize_temperature(\$temperature),
        ];

        \$response = self::make_api_request(\$request_data, 'chat/completions');

        if (is_wp_error(\$response)) { wp_send_json_error(['message' => \$response->get_error_message()]); return; }

        \$response_body = json_decode(wp_remote_retrieve_body(\$response), true);

        if (!isset(\$response_body['choices'][0]['message']['content'])) {
            \$error_msg = isset(\$response_body['error']['message']) ? \$response_body['error']['message'] : __('پاسخ نامعتبر از API دریافت شد.', 'gglct-ai-optimizer-pro');
            wp_send_json_error(['message' => \$error_msg, 'details' => \$response_body]); return;
        }

        \$content = \$response_body['choices'][0]['message']['content'];
        \$usage = \$response_body['usage'] ?? ['prompt_tokens' => \$input_tokens_estimate, 'completion_tokens' => 0, 'total_tokens' => \$input_tokens_estimate];
        
        \$cost_data = GGLCT_AIOP_Utils::calculate_request_cost('text', \$model_id, \$usage['prompt_tokens'], \$usage['completion_tokens']);

        if (get_option('gglct_aiop_enable_logging', 'yes') === 'yes') {
            GGLCT_AIOP_DB::save_to_history(
                isset(\$_POST['post_id']) ? intval(\$_POST['post_id']) : 0,
                isset(\$_POST['post_type']) ? sanitize_text_field(\$_POST['post_type']) : '',
                \$prompt, \$content, \$model_id, \$usage['total_tokens'],                \$cost_data['usd'], \$cost_data['toman'], \$cost_data['rate']
            );
        }

        wp_send_json_success([
            'content' => \$content,
            'usage' => \$usage,
            'model' => \$model_id,
            'cost' => \$cost_data
        ]);
    }
    
    public static function ajax_generate_image() {        check_ajax_referer('gglct_aiop_nonce', 'nonce');
        if (!GGLCT_AIOP_Utils::check_api_key_and_permission()) { wp_send_json_error(['message' => __('عدم دسترسی یا کلید API نامعتبر.', 'gglct-ai-optimizer-pro')]); return; }

        \$prompt = isset(\$_POST['prompt']) ? sanitize_textarea_field(\$_POST['prompt']) : '';
        \$model_id = isset(\$_POST['model']) ? sanitize_text_field(\$_POST['model']) : get_option('gglct_aiop_default_image_model', 'dall-e-3');
        \$size = isset(\$_POST['size']) ? sanitize_text_field(\$_POST['size']) : get_option('gglct_aiop_default_image_size', '1024x1024');
        \$quality = isset(\$_POST['quality']) ? sanitize_text_field(\$_POST['quality']) : get_option('gglct_aiop_default_image_quality', 'standard');
        \$n = isset(\$_POST['n']) ? intval(\$_POST['n']) : 1;
        \$style = isset(\$_POST['style']) ? sanitize_text_field(\$_POST['style']) : get_option('gglct_aiop_default_image_style', 'vivid'); // DALL-E 3 specific

        if (empty(\$prompt)) { wp_send_json_error(['message' => __('پرامپت تصویر نمی‌تواند خالی باشد.', 'gglct-ai-optimizer-pro')]); return; }
        
        \$image_model_details = GGLCT_AIOP_Utils::get_image_model_details(\$model_id);
        if (\$model_id === 'dall-e-3' && \$n > 1) \$n = 1; // DALL-E 3 generates one image
        if (isset(\$image_model_details['max_per_request']) && \$n > \$image_model_details['max_per_request']) \$n = \$image_model_details['max_per_request'];


        \$request_data = [
            'model' => \$model_id,
            'prompt' => \$prompt,
            'n' => \$n,
            'size' => \$size,
            'response_format' => 'url', // b64_json also possible
        ];
        if (\$model_id === 'dall-e-3') {
            \$request_data['quality'] = (\$quality === 'hd') ? 'hd' : 'standard';
            \$request_data['style'] = (\$style === 'natural') ? 'natural' : 'vivid';
        }


        \$response = self::make_api_request(\$request_data, 'images/generations');

        if (is_wp_error(\$response)) { wp_send_json_error(['message' => \$response->get_error_message()]); return; }
        \$response_body = json_decode(wp_remote_retrieve_body(\$response), true);

        if (!isset(\$response_body['data']) || empty(\$response_body['data'])) {
            \$error_msg = isset(\$response_body['error']['message']) ? \$response_body['error']['message'] : __('پاسخ نامعتبر از API تصویر دریافت شد.', 'gglct-ai-optimizer-pro');
            wp_send_json_error(['message' => \$error_msg, 'details' => \$response_body]); return;
        }

        \$images = [];
        foreach (\$response_body['data'] as \$img_data) {
            \$images[] = [
                'url' => \$img_data['url'],
                'revised_prompt' => \$img_data['revised_prompt'] ?? \$prompt,
            ];
        }
        
        \$cost_data = GGLCT_AIOP_Utils::calculate_request_cost('image', \$model_id, 0, 0, \$n, \$size, \$quality);        if (get_option('gglct_aiop_enable_logging', 'yes') === 'yes') {
            GGLCT_AIOP_DB::save_to_history(
                0, 'image_generation', \$prompt, json_encode(\$images), \$model_id, \$n, // Using n as token count for images
                \$cost_data['usd'], \$cost_data['toman'], \$cost_data['rate']
            );
        }
        
        wp_send_json_success([
            'images' => \$images,
            'cost' => \$cost_data
        ]);
    }

    public static function ajax_test_connection() {
        check_ajax_referer('gglct_aiop_nonce', 'nonce');
        if (!current_user_can('manage_options')) { wp_send_json_error(['message' => __('عدم دسترسی.', 'gglct-ai-optimizer-pro')]); return; }

        \$api_key_to_test = isset(\$_POST['api_key']) ? sanitize_text_field(\$_POST['api_key']) : get_option('gglct_aiop_api_key');
        if (empty(\$api_key_to_test)) { wp_send_json_error(['message' => __('کلید API برای تست ارائه نشده است.', 'gglct-ai-optimizer-pro')]); return; }

        \$response = self::make_api_request([], 'models', 'GET', \$api_key_to_test);

        if (is_wp_error(\$response)) {
            wp_send_json_error(['message' => __('تست اتصال ناموفق بود:', 'gglct-ai-optimizer-pro') . ' ' . \$response->get_error_message()]);
        } else {
            \$response_body = json_decode(wp_remote_retrieve_body(\$response), true);
            if (isset(\$response_body['data'])) {
                 wp_send_json_success(['message' => __('تست اتصال موفقیت آمیز بود. تعداد مدل‌های یافت شده:', 'gglct-ai-optimizer-pro') . ' ' . count(\$response_body['data'])]);
            } else {
                wp_send_json_error(['message' => __('پاسخ API معتبر نبود اما اتصال برقرار شد.', 'gglct-ai-optimizer-pro')]);
            }
        }
    }

    public static function ajax_get_models_data() {
        check_ajax_referer('gglct_aiop_nonce', 'nonce');
        if (!GGLCT_AIOP_Utils::check_api_key_and_permission('manage_options', true)) { wp_send_json_error(['message' => __('عدم دسترسی یا کلید API نامعتبر.', 'gglct-ai-optimizer-pro')]); return; }

        \$text_models = GGLCT_AIOP_Utils::get_models_from_cache_or_api('text');
        \$image_models = GGLCT_AIOP_Utils::get_models_from_cache_or_api('image');

        if (empty(\$text_models) && empty(\$image_models)) {
            wp_send_json_error(['message' => __('هیچ اطلاعات مدلی یافت نشد. لطفاً تنظیمات کلید API را بررسی کنید و حافظه پنهان را پاک کنید.', 'gglct-ai-optimizer-pro')]);
            return;
        }        wp_send_json_success(['text_models' => array_values(\$text_models), 'image_models' => array_values(\$image_models)]);
    }

    public static function make_api_request(\$data, \$endpoint_path, \$method = 'POST', \$custom_api_key = null) {
        \$api_key = \$custom_api_key ?? get_option('gglct_aiop_api_key');
        if (empty(\$api_key)) {
            return new WP_Error('api_key_missing', __('کلید API تنظیم نشده است.', 'gglct-ai-optimizer-pro'));
        }

        \$url = trailingslashit(GGLCT_AIOP_API_BASE_URL) . \$endpoint_path;
        \$headers = [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . \$api_key,
            'User-Agent' => 'GGLCT WordPress Plugin/' . GGLCT_AIOP_PLUGIN_VERSION,
        ];
        \$args = [
            'method' => strtoupper(\$method),
            'timeout' => 120, // Increased timeout
            'headers' => \$headers,
        ];

        if ('POST' === strtoupper(\$method) && !empty(\$data)) {
            \$args['body'] = wp_json_encode(\$data);
        } elseif ('GET' === strtoupper(\$method) && !empty(\$data)) {
            \$url = add_query_arg(\$data, \$url);
        }
        
        \$response = wp_remote_request(\$url, \$args);

        if (is_wp_error(\$response)) {
            return \$response;
        }

        \$response_code = wp_remote_retrieve_response_code(\$response);
        \$response_body = wp_remote_retrieve_body(\$response);
        \$decoded_body = json_decode(\$response_body, true);

        if (\$response_code >= 400) {
            \$error_message = isset(\$decoded_body['error']['message']) ? \$decoded_body['error']['message'] : \$response_body;
            if (empty(\$error_message) && isset(\$decoded_body['detail'])) {
                 \$error_message = is_array(\$decoded_body['detail']) ? wp_json_encode(\$decoded_body['detail']) : \$decoded_body['detail'];
            }
            return new WP_Error(
                'api_error_' . \$response_code,
                sprintf(__('خطا از API (%s): %s', 'gglct-ai-optimizer-pro'), \$response_code, esc_html(\$error_message))
            );
        }
        return \$response;
    }
}