<?php
if (!defined('ABSPATH')) exit;

class GGLCT_AIOP_DB {

    public static function create_tables() {
        global \$wpdb;
        \$charset_collate = \$wpdb->get_charset_collate();
        \$table_name = \$wpdb->prefix . 'gglct_aiop_content_history';
        \$sql = "CREATE TABLE IF NOT EXISTS \$table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,            post_id bigint(20) NOT NULL DEFAULT 0,
            post_type varchar(50) NOT NULL,
            prompt text NOT NULL,
            content longtext DEFAULT NULL,
            model varchar(100) NOT NULL,
            tokens int(11) DEFAULT 0,
            cost_usd decimal(10,6) DEFAULT 0.000000,
            cost_toman decimal(10,2) DEFAULT 0.00,
            usdt_rate decimal(10,2) DEFAULT 0.00,
            generated_item_type ENUM('text', 'image') NOT NULL DEFAULT 'text',
            image_urls text DEFAULT NULL, /* JSON array of URLs for images */
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),            KEY post_id (post_id),
            KEY model (model),
            KEY generated_item_type (generated_item_type)
        ) \$charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta(\$sql);
    }

    public static function save_to_history(\$post_id, \$post_type, \$prompt, \$content, \$model, \$tokens, \$cost_usd = 0, \$cost_toman = 0, \$usdt_rate = 0, \$item_type = 'text', \$image_urls_json = null) {
        global \$wpdb;
        \$table_name = \$wpdb->prefix . 'gglct_aiop_content_history';
        \$data = [
            'user_id' => get_current_user_id(),
            'post_id' => intval(\$post_id),            'post_type' => sanitize_text_field(\$post_type),
            'prompt' => \$prompt, // Already sanitized or wp_json_encode will handle
            'model' => sanitize_text_field(\$model),
            'tokens' => intval(\$tokens),
            'cost_usd' => floatval(\$cost_usd),
            'cost_toman' => floatval(\$cost_toman),            'usdt_rate' => floatval(\$usdt_rate),
            'generated_item_type' => (\$item_type === 'image') ? 'image' : 'text',
            'created_at' => current_time('mysql', 1),
        ];
        if (\$item_type === 'text') {
            \$data['content'] = \$content; // Already sanitized or wp_json_encode will handle
        } else {
            \$data['image_urls'] = \$image_urls_json; // Should be JSON string
        }        \$formats = [
            '%d', '%d', '%s', '%s', '%s', '%d', '%f', '%f', '%f', '%s', '%s'
        ];
        if (\$item_type === 'text') {
             array_splice(\$formats, 4, 0, '%s'); // format for content
        } else {
             array_splice(\$formats, 4, 0, '%s'); // format for image_urls
        }
        
        \$wpdb->insert(\$table_name, \$data, \$formats);
        return \$wpdb->insert_id;
    }

    public static function get_history_items(\$args = []) {
        global \$wpdb;
        \$table_name = \$wpdb->prefix . 'gglct_aiop_content_history';
                \$current_page = isset(\$args['paged']) ? max(1, intval(\$args['paged'])) : 1;
        \$per_page = 20;
        \$offset = (\$current_page - 1) * \$per_page;

        \$where_clauses = [];
        \$where_params = [];

        if (!current_user_can('manage_options')) {
            \$where_clauses[] = "user_id = %d";
            \$where_params[] = get_current_user_id();
        }

        if (!empty(\$args['post_type_filter'])) {
            \$where_clauses[] = "post_type = %s";
            \$where_params[] = sanitize_text_field(\$args['post_type_filter']);
        }
        if (!empty(\$args['item_type_filter'])) {
            \$where_clauses[] = "generated_item_type = %s";
            \$where_params[] = sanitize_text_field(\$args['item_type_filter']);
        }        // ... other filters ...
        \$where_sql = !empty(\$where_clauses) ? " WHERE " . implode(" AND ", \$where_clauses) : "";
        
        \$total_items_sql = "SELECT COUNT(*) FROM {\$table_name} \$where_sql";
        \$total_items = \$wpdb->get_var( empty(\$where_params) ? \$total_items_sql : \$wpdb->prepare(\$total_items_sql, \$where_params) );
        
        \$history_items_sql = "SELECT * FROM {\$table_name} \$where_sql ORDER BY created_at DESC LIMIT %d OFFSET %d";
        \$query_params = array_merge(\$where_params, [\$per_page, \$offset]);
        \$history_items = \$wpdb->get_results( \$wpdb->prepare(\$history_items_sql, \$query_params) );

        return [
            'history_items' => \$history_items,
            'total_pages' => ceil(\$total_items / \$per_page),
            'current_page' => \$current_page,
            'total_items' => \$total_items,
            'all_post_types_objects' => get_post_types(['public' => true], 'objects'),        ];
    }
    
    public static function ajax_get_history_content() {
        check_ajax_referer('gglct_aiop_nonce', 'nonce');
        if (!current_user_can('edit_posts')) { wp_send_json_error(['message' => __('عدم دسترسی.', 'gglct-ai-optimizer-pro')]); return; }

        \$history_id = isset(\$_POST['id']) ? intval(\$_POST['id']) : 0;
        if (!\$history_id) { wp_send_json_error(['message' => __('شناسه نامعتبر.', 'gglct-ai-optimizer-pro')]); return; }

        global \$wpdb;        \$table_name = \$wpdb->prefix . 'gglct_aiop_content_history';
        \$item_query = "SELECT * FROM {\$table_name} WHERE id = %d";
        \$prepared_query = \$wpdb->prepare(\$item_query, \$history_id);
        \$item = \$wpdb->get_row(\$prepared_query);

        if (!\$item) { wp_send_json_error(['message' => __('مورد تاریخچه یافت نشد.', 'gglct-ai-optimizer-pro')]); return; }
        if (!current_user_can('manage_options') && \$item->user_id != get_current_user_id()) {
             wp_send_json_error(['message' => __('شما اجازه مشاهده این مورد را ندارید.', 'gglct-ai-optimizer-pro')]); return;
        }
        
        // Sanitize output, especially content and prompt
        \$item->prompt = esc_textarea(\$item->prompt);
        \$item->content = (\$item->generated_item_type === 'text' && \$item->content) ? wp_kses_post(\$item->content) : null;
        if (\$item->generated_item_type === 'image' && \$item->image_urls) {
            \$item->image_urls_decoded = json_decode(\$item->image_urls, true);
            if (json_last_error() !== JSON_ERROR_NONE) \$item->image_urls_decoded = [];
        }


        wp_send_json_success(['item' => \$item]);
    }
}PHP;

$class_post_type_handler_php = <<<'PHP'
<?php
if (!defined('ABSPATH')) exit;

class GGLCT_AIOP_Post_Type_Handler {

    public static function add_meta_boxes() {
        if (!GGLCT_AIOP_Utils::check_api_key_and_permission('edit_posts', true)) return; // Allow if key missing for settings context potentially
        \$enabled_post_types = get_option('gglct_aiop_enabled_post_types', ['post', 'page']);
        if (empty(\$enabled_post_types) || !is_array(\$enabled_post_types)) return;

        foreach (\$enabled_post_types as \$post_type) {
            add_meta_box(
                'gglct-ai-optimizer-pro-metabox',
                __('GGLCT AI Optimizer Pro', 'gglct-ai-optimizer-pro'),
                array(self::class, 'render_metabox_content'),
                \$post_type,
                'normal',
                'high'
            );
        }    }

    public static function render_metabox_content(\$post) {
        \$page_data = GGLCT_AIOP_Utils::get_page_common_data(true, true); // text & image models
        extract(\$page_data);
        
        \$default_text_model = get_option('gglct_aiop_default_text_model', GGLCT_AIOP_DEFAULT_MODEL);
        \$default_max_tokens = get_option('gglct_aiop_default_max_tokens', 2000);
        \$default_temperature = get_option('gglct_aiop_default_temperature', 0.7);
        
        \$default_image_model = get_option('gglct_aiop_default_image_model', 'dall-e-3');
        \$default_image_size = get_option('gglct_aiop_default_image_size', '1024x1024');
        \$default_image_quality = get_option('gglct_aiop_default_image_quality', 'standard');
        \$default_image_style = get_option('gglct_aiop_default_image_style', 'vivid');


        wp_nonce_field('gglct_aiop_metabox_nonce', 'gglct_aiop_metabox_nonce_field');
        require GGLCT_AIOP_PLUGIN_DIR . 'includes/admin-parts/metabox-content.php';
    }

    public static function register_tinymce_plugin() {
        if (!GGLCT_AIOP_Utils::check_api_key_and_permission('edit_posts', true)) return;
        if (!current_user_can('edit_posts') && !current_user_can('edit_pages')) return;
        if (get_user_option('rich_editing') !== 'true') return;
        add_filter('mce_buttons', array(self::class, 'add_tinymce_button'));
        add_filter('mce_external_plugins', array(self::class, 'add_tinymce_script'));
    }

    public static function add_tinymce_button(\$buttons) {
        array_push(\$buttons, 'separator', 'gglct_aiop_tinymce_button');
        return \$buttons;
    }    public static function add_tinymce_script(\$plugins) {
        \$plugins['gglct_aiop_tinymce_button'] = GGLCT_AIOP_PLUGIN_URL . 'assets/js/gglct-tinymce.js';
        return \$plugins;
    }    public static function register_gutenberg_block() {
        if (!GGLCT_AIOP_Utils::check_api_key_and_permission('edit_posts', true)) return;
        if (!function_exists('register_block_type')) return;

        wp_register_script(
            'gglct-ai-optimizer-pro-gutenberg-block',
            GGLCT_AIOP_PLUGIN_URL . 'assets/js/gglct-gutenberg-block.js',
            array('wp-blocks', 'wp-element', 'wp-editor', 'wp-components', 'wp-i18n', 'wp-data', 'jquery'),
            GGLCT_AIOP_PLUGIN_VERSION,
            true
        );
        wp_set_script_translations('gglct-ai-optimizer-pro-gutenberg-block', 'gglct-ai-optimizer-pro', GGLCT_AIOP_PLUGIN_DIR . 'languages');
        
        wp_register_style(
            'gglct-ai-optimizer-pro-gutenberg-editor',
             GGLCT_AIOP_PLUGIN_URL . 'assets/css/gglct-gutenberg-editor.css',
             array('wp-edit-blocks'),
             GGLCT_AIOP_PLUGIN_VERSION
        );        register_block_type('gglct-ai-optimizer-pro/ai-content-generator', array(            'editor_script' => 'gglct-ai-optimizer-pro-gutenberg-block',
            'editor_style'  => 'gglct-ai-optimizer-pro-gutenberg-editor',
            'render_callback' => array(self::class, 'render_dynamic_gutenberg_block')
        ));
        wp_localize_script('gglct-ai-optimizer-pro-gutenberg-block', 'gglctAioGbParams', GGLCT_AIOP_Utils::get_common_script_params());
    }

    public static function render_dynamic_gutenberg_block(\$attributes, \$content) {
        if (isset(\$attributes['generatedHTML']) && !empty(\$attributes['generatedHTML'])) {
            return '<div class="gglct-aio-generated-block-content">' . wp_kses_post(\$attributes['generatedHTML']) . '</div>';
        }
        return '<!-- GGLCT AI Block Placeholder -->';
    }
    
    public static function ajax_create_new_post() {
        check_ajax_referer('gglct_aiop_nonce', 'nonce');
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(['message' => __('عدم دسترسی.', 'gglct-ai-optimizer-pro')]);
            return;
        }

        \$content = isset(\$_POST['content']) ? wp_kses_post(\$_POST['content']) : '';
        \$post_type = isset(\$_POST['post_type']) ? sanitize_text_field(\$_POST['post_type']) : 'post';
        \$title_suggestion = isset(\$_POST['title_suggestion']) ? sanitize_text_field(\$_POST['title_suggestion']) : '';        \$title = __('محتوای تولید شده با GGLCT AI', 'gglct-ai-optimizer-pro');
        if (!empty(\$title_suggestion)) {
            \$title = \$title_suggestion;
        } elseif (preg_match('/<h[1-6][^>]*>(.*?)<\/h[1-6]>/i', \$content, \$matches)) {
            \$title = strip_tags(\$matches[1]);
            \$title = substr(\$title, 0, 100); // Limit title length
        }
        if (empty(\$title)) \$title = __('بدون عنوان', 'gglct-ai-optimizer-pro');

        \$post_data = [
            'post_title' => \$title,            'post_content' => \$content,
            'post_status' => 'draft',
            'post_type' => \$post_type,
            'post_author' => get_current_user_id(),
        ];
        \$new_post_id = wp_insert_post(\$post_data, true);

        if (is_wp_error(\$new_post_id)) {
            wp_send_json_error(['message' => __('خطا در ایجاد پست جدید:', 'gglct-ai-optimizer-pro') . ' ' . \$new_post_id->get_error_message()]);
        } else {
            wp_send_json_success([
                'message' => __('پست جدید با موفقیت ایجاد شد (پیش‌نویس).', 'gglct-ai-optimizer-pro'),
                'edit_url' => admin_url('post.php?post=' . \$new_post_id . '&action=edit'),
                'post_id' => \$new_post_id
            ]);
        }
    }
}