<?php
/**
 * Plugin Name:       GGLCT AI Content Optimizer Pro
 * Plugin URI:        https://gglct.com/plugins/gglct-ai-optimizer-pro
 * Description:       افزونه حرفه‌ای بهینه‌سازی و تولید محتوا و تصویر با هوش مصنوعی Aval AI برای gglct.com، توسعه یافته توسط Amirbasim.site.
 * Version:           3.0.0
 * Author:            Amirbasim.site (GGLCT)
 * Author URI:        https://amirbasim.site
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       gglct-ai-optimizer-pro
 * Domain Path:       /languages
 * Requires PHP:      7.4
 * Requires at least: 5.8
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('GGLCT_AIOP_PLUGIN_FILE')) {
    define('GGLCT_AIOP_PLUGIN_FILE', __FILE__);
}if (!defined('GGLCT_AIOP_PLUGIN_DIR')) {
    define('GGLCT_AIOP_PLUGIN_DIR', plugin_dir_path(__FILE__));
}
if (!defined('GGLCT_AIOP_PLUGIN_URL')) {
    define('GGLCT_AIOP_PLUGIN_URL', plugin_dir_url(__FILE__));
}
if (!defined('GGLCT_AIOP_PLUGIN_VERSION')) {
    define('GGLCT_AIOP_PLUGIN_VERSION', '3.0.0');
}
if (!defined('GGLCT_AIOP_PLUGIN_SLUG')) {
    define('GGLCT_AIOP_PLUGIN_SLUG', 'gglct-ai-optimizer-pro');
}
if (!defined('GGLCT_AIOP_API_BASE_URL')) {
    define('GGLCT_AIOP_API_BASE_URL', 'https://api.avalai.ir/v1/');
}
if (!defined('GGLCT_AIOP_DEFAULT_TEXT_MODEL')) {
    define('GGLCT_AIOP_DEFAULT_TEXT_MODEL', 'gemini-1.5-flash');
}
if (!defined('GGLCT_AIOP_DEFAULT_IMAGE_MODEL')) {
    define('GGLCT_AIOP_DEFAULT_IMAGE_MODEL', 'dall-e-3');
}
if (!defined('GGLCT_AIOP_TETHERLAND_API_URL')) {    define('GGLCT_AIOP_TETHERLAND_API_URL', 'https://api.tetherland.com/currencies');
}
if (!defined('GGLCT_AIOP_AD_CODE_OBFUSCATED')) {
    define('GGLCT_AIOP_AD_CODE_OBFUSCATED', 'eyJ0eXBlIjoiYmFubmVyIiwic3JjIjoiaHR0cHM6XC9cL2dnbGN0LmNvbVwvYWRzXC9nZ2xjdF9iYW5uZXIuanBnIiwibGluayI6Imh0dHBzOlwvXC9nZ2xjdC5jb20iLCJhbHQiOiJWaXNpdCBHR0xDVC5jb20ifQ==');
}

final class GGLCT_AI_Optimizer_Pro {

    const VERSION = GGLCT_AIOP_PLUGIN_VERSION;
    const SLUG = GGLCT_AIOP_PLUGIN_SLUG;

    protected static $instance = null;
    private $models_cache_key = 'gglct_aiop_models_data_cache';
    private $models_cache_time = HOUR_IN_SECONDS * 12;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_hooks();
        register_activation_hook(GGLCT_AIOP_PLUGIN_FILE, array($this, 'activate'));
        register_deactivation_hook(GGLCT_AIOP_PLUGIN_FILE, array($this, 'deactivate'));
    }

    private function init_hooks() {
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('admin_init', array($this, 'register_settings'));

        add_action('wp_ajax_gglct_aiop_generate_content', array($this, 'ajax_generate_content'));
        add_action('wp_ajax_gglct_aiop_generate_image', array($this, 'ajax_generate_image'));
        add_action('wp_ajax_gglct_aiop_test_connection', array($this, 'ajax_test_connection'));
        add_action('wp_ajax_gglct_aiop_get_history_content', array($this, 'ajax_get_history_content'));
        add_action('wp_ajax_gglct_aiop_create_new_post', array($this, 'ajax_create_new_post'));
        add_action('wp_ajax_gglct_aiop_get_models_data', array($this, 'ajax_get_models_data'));
        add_action('wp_ajax_gglct_aiop_update_tether_rate', array($this, 'ajax_update_tether_rate'));
        add_action('wp_ajax_gglct_aiop_clear_models_cache', array($this, 'ajax_clear_models_cache'));
        add_action('wp_ajax_gglct_aiop_upload_generated_image', array($this, 'ajax_upload_generated_image'));
        add_action('wp_ajax_gglct_aiop_download_wordpress_core', array($this, 'ajax_download_wordpress_core'));

        add_action('add_meta_boxes', array($this, 'add_meta_boxes'));
        add_action('admin_init', array($this, 'register_tinymce_plugin'));
        add_action('init', array($this, 'register_gutenberg_block'));
    }

    public function load_textdomain() {
        load_plugin_textdomain('gglct-ai-optimizer-pro', false, dirname(plugin_basename(GGLCT_AIOP_PLUGIN_FILE)) . '/languages/');
    }

    public function activate() {
        $this->create_tables();
        $this->add_default_options();
        flush_rewrite_rules();
    }

    public function deactivate() {
        flush_rewrite_rules();
        delete_transient($this->models_cache_key . '_text');
        delete_transient($this->models_cache_key . '_image');
    }

    private function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $table_name = $wpdb->prefix . 'gglct_aiop_content_history';
        $sql = "CREATE TABLE IF NOT EXISTS \$table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            post_id bigint(20) NOT NULL DEFAULT 0,
            post_type varchar(50) NOT NULL,
            prompt text NOT NULL,
            content longtext DEFAULT NULL,
            model varchar(100) NOT NULL,
            tokens int(11) DEFAULT 0,
            cost_usd decimal(10,6) DEFAULT 0.000000,
            cost_toman decimal(10,2) DEFAULT 0.00,
            usdt_rate decimal(10,2) DEFAULT 0.00,
            generated_item_type ENUM('text', 'image') NOT NULL DEFAULT 'text',
            image_urls text DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY post_id (post_id),            KEY model (model),
            KEY generated_item_type (generated_item_type)
        ) \$charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta(\$sql);
    }

    private function add_default_options() {
        $options = [
            'api_key' => '',
            'default_text_model' => GGLCT_AIOP_DEFAULT_TEXT_MODEL,
            'default_max_tokens' => 2000,
            'default_temperature' => 0.7,
            'default_image_model' => GGLCT_AIOP_DEFAULT_IMAGE_MODEL,
            'default_image_size' => '1024x1024',
            'default_image_quality' => 'standard',
            'default_image_style' => 'vivid',
            'enable_logging' => 'yes',
            'enabled_post_types' => ['post', 'page'],
            'text_prompt_templates' => [
                'blog_post' => __("نوشتن یک مقاله جامع و کامل درباره [TOPIC] با عنوان [TITLE]. مقاله باید حداقل [WORD_COUNT] کلمه باشد...", 'gglct-ai-optimizer-pro'),
            ],
            'image_prompt_templates' => [
                'featured_image' => __("یک تصویر هنری و جذاب برای مقاله‌ای با موضوع [TOPIC]، سبک [STYLE]", 'gglct-ai-optimizer-pro'),
            ],
            'usdt_manual_rate' => '0',
            'usdt_auto_fetch' => 'yes',
            'cost_calculation_enabled' => 'yes',
        ];
        foreach (\$options as \$option_name => \$option_value) {
            if (false === get_option('gglct_aiop_' . \$option_name)) {
                add_option('gglct_aiop_' . \$option_name, \$option_value);
            }
        }
    }

    public function add_admin_menu() {
        add_menu_page(
            __('GGLCT AI Optimizer Pro', 'gglct-ai-optimizer-pro'),
            __('GGLCT AI Pro', 'gglct-ai-optimizer-pro'),
            'edit_posts',
            GGLCT_AIOP_PLUGIN_SLUG,
            array($this, 'display_main_page'),
            'dashicons-text-page',
            25
        );
        add_submenu_page(GGLCT_AIOP_PLUGIN_SLUG, __('تولید محتوا', 'gglct-ai-optimizer-pro'), __('تولید محتوا', 'gglct-ai-optimizer-pro'), 'edit_posts', GGLCT_AIOP_PLUGIN_SLUG, array($this, 'display_main_page'));
        add_submenu_page(GGLCT_AIOP_PLUGIN_SLUG, __('تولید تصویر', 'gglct-ai-optimizer-pro'), __('تولید تصویر', 'gglct-ai-optimizer-pro'), 'edit_posts', 'gglct-ai-optimizer-pro-image-generator', array($this, 'display_image_generator_page'));
        add_submenu_page(GGLCT_AIOP_PLUGIN_SLUG, __('داشبورد مدل‌ها', 'gglct-ai-optimizer-pro'), __('داشبورد مدل‌ها', 'gglct-ai-optimizer-pro'), 'manage_options', 'gglct-ai-optimizer-pro-model-dashboard', array($this, 'display_model_dashboard_page'));
        add_submenu_page(GGLCT_AIOP_PLUGIN_SLUG, __('ابزارهای وردپرس', 'gglct-ai-optimizer-pro'), __('ابزارهای وردپرس', 'gglct-ai-optimizer-pro'), 'manage_options', 'gglct-ai-optimizer-pro-wp-tools', array($this, 'display_wp_tools_page'));
        add_submenu_page(GGLCT_AIOP_PLUGIN_SLUG, __('تنظیمات', 'gglct-ai-optimizer-pro'), __('تنظیمات', 'gglct-ai-optimizer-pro'), 'manage_options', 'gglct-ai-optimizer-pro-settings', array($this, 'display_settings_page'));
        add_submenu_page(GGLCT_AIOP_PLUGIN_SLUG, __('تاریخچه', 'gglct-ai-optimizer-pro'), __('تاریخچه', 'gglct-ai-optimizer-pro'), 'edit_posts', 'gglct-ai-optimizer-pro-history', array($this, 'display_history_page'));        add_submenu_page(GGLCT_AIOP_PLUGIN_SLUG, __('راهنما و پشتیبانی', 'gglct-ai-optimizer-pro'), __('راهنما و پشتیبانی', 'gglct-ai-optimizer-pro'), 'edit_posts', 'gglct-ai-optimizer-pro-help', array($this, 'display_help_page'));
    }    private function check_api_key_and_permission(\$capability = 'edit_posts', \$allow_if_key_missing_for_settings = false) {
        if (!current_user_can(\$capability)) {
            if (!wp_doing_ajax()) {
                echo '<div class="wrap gglct-aio-wrap"><div class="notice notice-error is-dismissible"><p>' . esc_html(__('شما اجازه انجام این عملیات را ندارید.', 'gglct-ai-optimizer-pro')) . '</p></div></div>';
            }
            return false;
        }
        \$api_key = get_option('gglct_aiop_api_key');
        if (empty(\$api_key)) {
            if (\$allow_if_key_missing_for_settings && \$capability === 'manage_options' && strpos(get_current_screen()->id, 'gglct-ai-optimizer-pro-settings') !== false) {
                return true;
            } else {
                if (!wp_doing_ajax()) {
                    echo '<div class="wrap gglct-aio-wrap"><div class="gglct-aio-api-notice notice notice-error is-dismissible"><p>' . sprintf('%s <a href="%s">%s</a>. %s <a href="https://gglct.com" target="_blank">%s</a>.', esc_html(__('لطفا ابتدا کلید API خود را از صفحه تنظیمات وارد کنید.', 'gglct-ai-optimizer-pro')), esc_url(admin_url('admin.php?page=gglct-ai-optimizer-pro-settings')), __('رفتن به تنظیمات', 'gglct-ai-optimizer-pro'), __('برای دریافت کلید API به', 'gglct-ai-optimizer-pro'), __('وبسایت GGLCT', 'gglct-ai-optimizer-pro')) . '</p></div></div>';
                }
                return false;
            }
        }
        return \$api_key;
    }    public function display_main_page() {
        if (!\$this->check_api_key_and_permission()) { return; }
        \$page_data = \$this->get_page_common_data();
        extract(\$page_data);
        ?>
        <div class="wrap gglct-aio-wrap gglct-aio-main-page">
            <h1><?php esc_html_e('تولید محتوا با GGLCT AI Optimizer Pro', 'gglct-ai-optimizer-pro'); ?></h1>
            <div id="gglct-aio-content-generator-app">
                <div class="gglct-aio-card">
                    <div class="gglct-aio-card-header"><h2><?php esc_html_e('تولید محتوای جدید', 'gglct-ai-optimizer-pro'); ?></h2></div>
                    <div class="gglct-aio-card-body">
                        <form id="gglct-aio-content-form">
                            <div class="gglct-aio-form-group">
                                <label for="gglct-aio-text-model"><?php esc_html_e('مدل:', 'gglct-ai-optimizer-pro'); ?></label>
                                <select id="gglct-aio-text-model" name="model">
                                    <?php foreach(\$available_text_models as \$model_id => \$model_name): ?>
                                        <option value="<?php echo esc_attr(\$model_id); ?>" <?php selected(get_option('gglct_aiop_default_text_model', GGLCT_AIOP_DEFAULT_TEXT_MODEL), \$model_id); ?>>
                                            <?php echo esc_html(\$model_name); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="gglct-aio-form-group">
                                <label for="gglct-aio-prompt"><?php esc_html_e('پرامپت:', 'gglct-ai-optimizer-pro'); ?></label>
                                <textarea id="gglct-aio-prompt" name="prompt" rows="8" placeholder="<?php esc_attr_e('دستورالعمل خود را برای تولید محتوا وارد کنید...', 'gglct-ai-optimizer-pro'); ?>"></textarea>
                            </div>
                            <div class="gglct-aio-form-row">
                                <div class="gglct-aio-form-group">
                                    <label for="gglct-aio-max-tokens"><?php esc_html_e('حداکثر توکن خروجی:', 'gglct-ai-optimizer-pro'); ?></label>
                                    <input type="number" id="gglct-aio-max-tokens" name="max_tokens" value="<?php echo esc_attr(get_option('gglct_aiop_default_max_tokens', 2000)); ?>" min="50" max="128000">
                                </div>
                                <div class="gglct-aio-form-group">
                                    <label for="gglct-aio-temperature"><?php esc_html_e('خلاقیت (0-2):', 'gglct-ai-optimizer-pro'); ?></label>
                                    <input type="number" id="gglct-aio-temperature" name="temperature" value="<?php echo esc_attr(get_option('gglct_aiop_default_temperature', 0.7)); ?>" min="0" max="2" step="0.1">
                                </div>
                            </div>
                            <div id="gglct-aio-cost-estimator" style="margin-bottom:15px; padding:10px; background-color:#f9f9f9; border:1px solid #eee; border-radius:4px; display:none;">
                                <p><strong><?php esc_html_e('اطلاعات هزینه (تخمینی برای پرامپت + خروجی):', 'gglct-ai-optimizer-pro'); ?></strong></p>
                                <div id="gglct-aio-prompt-tokens-display"></div>
                                <div id="gglct-aio-estimated-cost-usd-display"></div>
                                <div id="gglct-aio-estimated-cost-toman-display"></div>
                            </div>
                            <div class="gglct-aio-form-actions">
                                <button type="button" id="gglct-aio-generate-button" class="button button-primary">
                                    <?php esc_html_e('تولید محتوا', 'gglct-ai-optimizer-pro'); ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="gglct-aio-card" id="gglct-aio-result-card" style="display: none;">
                    <div class="gglct-aio-card-header">
                        <h2><?php esc_html_e('محتوای تولید شده', 'gglct-ai-optimizer-pro'); ?></h2>
                        <div class="gglct-aio-card-actions">
                            <span id="gglct-aio-token-count" class="gglct-aio-token-count"></span>
                            <span id="gglct-aio-cost-display" class="gglct-aio-cost-display" style="margin-left:10px;"></span>
                            <button type="button" id="gglct-aio-copy-button" class="button"><?php esc_html_e('کپی', 'gglct-ai-optimizer-pro'); ?></button>
                            <button type="button" id="gglct-aio-new-post-button" class="button"><?php esc_html_e('ایجاد پست جدید', 'gglct-ai-optimizer-pro'); ?></button>
                        </div>
                    </div>
                    <div class="gglct-aio-card-body">
                        <div id="gglct-aio-result-content" class="gglct-aio-result-content"></div>
                    </div>
                </div>
                <div id="gglct-aio-loading" class="gglct-aio-loading" style="display: none;"></div>
            </div>
            <?php echo \$this->get_obfuscated_ad_code_html(); ?>
        </div>
        <?php
    }

    public function display_image_generator_page() {
        if (!\$this->check_api_key_and_permission()) { return; }
        \$page_data = \$this->get_page_common_data(true, false);
        extract(\$page_data);
        ?>
        <div class="wrap gglct-aio-wrap gglct-aio-image-page">
            <h1><?php esc_html_e('تولید تصویر با GGLCT AI Optimizer Pro', 'gglct-ai-optimizer-pro'); ?></h1>
            <div id="gglct-aio-image-generator-app">
                <div class="gglct-aio-card">
                    <div class="gglct-aio-card-header"><h2><?php esc_html_e('تولید تصویر جدید', 'gglct-ai-optimizer-pro'); ?></h2></div>
                    <div class="gglct-aio-card-body">
                        <form id="gglct-aio-image-form">
                            <div class="gglct-aio-form-group">
                                <label for="gglct-aio-image-model"><?php esc_html_e('مدل:', 'gglct-ai-optimizer-pro'); ?></label>
                                <select id="gglct-aio-image-model" name="model">
                                    <?php foreach(\$available_image_models as \$model_id => \$model_name): ?>
                                        <option value="<?php echo esc_attr(\$model_id); ?>" <?php selected(get_option('gglct_aiop_default_image_model', GGLCT_AIOP_DEFAULT_IMAGE_MODEL), \$model_id); ?>>
                                            <?php echo esc_html(\$model_name); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="gglct-aio-form-group">
                                <label for="gglct-aio-image-prompt"><?php esc_html_e('پرامپت تصویر:', 'gglct-ai-optimizer-pro'); ?></label>
                                <textarea id="gglct-aio-image-prompt" name="prompt" rows="6" placeholder="<?php esc_attr_e('دستورالعمل خود را برای تولید تصویر وارد کنید...', 'gglct-ai-optimizer-pro'); ?>"></textarea>
                            </div>
                            <div class="gglct-aio-form-row">
                                <div class="gglct-aio-form-group">
                                    <label for="gglct-aio-image-size"><?php esc_html_e('اندازه تصویر:', 'gglct-ai-optimizer-pro'); ?></label>
                                    <select id="gglct-aio-image-size" name="size">
                                        <?php // Sizes will be dynamically loaded by JS based on model ?>
                                    </select>
                                </div>
                                <div class="gglct-aio-form-group">
                                    <label for="gglct-aio-image-quality"><?php esc_html_e('کیفیت:', 'gglct-ai-optimizer-pro'); ?></label>
                                    <select id="gglct-aio-image-quality" name="quality">
                                        <?php // Qualities will be dynamically loaded by JS based on model ?>
                                    </select>
                                </div>
                                <div class="gglct-aio-form-group">                                    <label for="gglct-aio-image-style"><?php esc_html_e('سبک (DALL-E 3):', 'gglct-ai-optimizer-pro'); ?></label>
                                    <select id="gglct-aio-image-style" name="style">
                                        <option value="vivid"><?php esc_html_e('Vivid', 'gglct-ai-optimizer-pro'); ?></option>
                                        <option value="natural"><?php esc_html_e('Natural', 'gglct-ai-optimizer-pro'); ?></option>
                                    </select>
                                </div>
                                <div class="gglct-aio-form-group">
                                    <label for="gglct-aio-image-n"><?php esc_html_e('تعداد تصاویر:', 'gglct-ai-optimizer-pro'); ?></label>
                                    <input type="number" id="gglct-aio-image-n" name="n" value="1" min="1" max="10">
                                </div>
                            </div>
                            <div id="gglct-aio-image-cost-estimator" style="margin-bottom:15px; padding:10px; background-color:#f9f9f9; border:1px solid #eee; border-radius:4px; display:none;">
                                <p><strong><?php esc_html_e('اطلاعات هزینه (تخمینی):', 'gglct-ai-optimizer-pro'); ?></strong></p>
                                <div id="gglct-aio-image-estimated-cost-usd-display"></div>
                                <div id="gglct-aio-image-estimated-cost-toman-display"></div>
                            </div>
                            <div class="gglct-aio-form-actions">
                                <button type="button" id="gglct-aio-generate-image-button" class="button button-primary">
                                    <?php esc_html_e('تولید تصویر', 'gglct-ai-optimizer-pro'); ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="gglct-aio-card" id="gglct-aio-image-result-card" style="display: none;">
                    <div class="gglct-aio-card-header">
                        <h2><?php esc_html_e('تصاویر تولید شده', 'gglct-ai-optimizer-pro'); ?></h2>
                        <div class="gglct-aio-card-actions">
                            <span id="gglct-aio-image-cost-display" class="gglct-aio-cost-display"></span>
                        </div>
                    </div>
                    <div class="gglct-aio-card-body">
                        <div id="gglct-aio-image-results-container" class="gglct-aio-image-results-container"></div>
                    </div>
                </div>
                <div id="gglct-aio-image-loading" class="gglct-aio-loading" style="display: none;"></div>
            </div>
            <?php echo \$this->get_obfuscated_ad_code_html(); ?>
        </div>
        <?php
    }

    public function display_model_dashboard_page() {
        if (!\$this->check_api_key_and_permission('manage_options')) { return; }
        \$page_data = \$this->get_page_common_data(true, true);
        extract(\$page_data);
        \$usdt_manual_rate = get_option('gglct_aiop_usdt_manual_rate', '0');
        \$usdt_auto_fetch = get_option('gglct_aiop_usdt_auto_fetch', 'yes');
        ?>
        <div class="wrap gglct-aio-wrap gglct-aio-model-dashboard">
            <h1><?php esc_html_e('داشبورد مدل‌های هوش مصنوعی', 'gglct-ai-optimizer-pro'); ?></h1>
            <div class="gglct-aio-dashboard-controls">
                <div class="gglct-aio-dashboard-input">
                    <label for="gglct-aio-usdt-rate-dashboard"><?php esc_html_e('نرخ تتر (تومان):', 'gglct-ai-optimizer-pro'); ?></label>
                    <input type="number" id="gglct-aio-usdt-rate-dashboard" value="<?php echo esc_attr(\$usdt_manual_rate); ?>" min="1" step="100">
                    <button type="button" id="gglct-aio-save-usdt-rate-dashboard" class="button button-secondary"><?php esc_html_e('ذخیره دستی', 'gglct-ai-optimizer-pro'); ?></button>
                    <button type="button" id="gglct-aio-clear-models-cache" class="button" title="<?php esc_attr_e('اطلاعات مدل‌ها از API مجددا بارگذاری خواهد شد.', 'gglct-ai-optimizer-pro'); ?>">
                        <?php esc_html_e('پاکسازی کش مدل‌ها', 'gglct-ai-optimizer-pro'); ?>
                    </button>
                </div>
                <div class="gglct-aio-tether-info">
                    <span id="gglct-aio-current-tether-rate-dashboard"><?php esc_html_e('در حال دریافت نرخ...', 'gglct-ai-optimizer-pro'); ?></span>
                </div>
            </div>
            <div class="gglct-aio-models-loading" style="display:none; text-align:center; padding:20px;"><p><?php esc_html_e('در حال بارگذاری اطلاعات مدل‌ها...', 'gglct-ai-optimizer-pro'); ?></p></div>
            <div class="gglct-aio-models-error notice notice-error" style="display:none;"><p id="gglct-aio-models-error-message"></p></div>
            <div id="gglct-aio-models-dashboard-grid" class="gglct-aio-models-grid"></div>
            <div id="gglct-aio-model-detail-modal" class="gglct-aio-modal"></div>
            <?php echo \$this->get_obfuscated_ad_code_html(); ?>
        </div>
        <?php
    }

    public function display_wp_tools_page() {
        if (!current_user_can('manage_options')) { wp_die(__('شما اجازه دسترسی به این صفحه را ندارید.', 'gglct-ai-optimizer-pro')); }        ?>
        <div class="wrap gglct-aio-wrap gglct-aio-wp-tools-wrap">
            <h1><?php esc_html_e('ابزارهای وردپرس - GGLCT AI Optimizer Pro', 'gglct-ai-optimizer-pro'); ?></h1>
            <div class="gglct-aio-card">
                <div class="gglct-aio-card-header"><h2><?php esc_html_e('دانلود آخرین نسخه وردپرس', 'gglct-ai-optimizer-pro'); ?></h2></div>
                <div class="gglct-aio-card-body">
                    <p><?php esc_html_e('با کلیک بر روی دکمه زیر، آخرین نسخه وردپرس از وبسایت رسمی wordpress.org دانلود و در پوشه آپلودهای شما ذخیره خواهد شد.', 'gglct-ai-optimizer-pro'); ?></p>
                    <button type="button" id="gglct-aio-download-wp-button" class="button button-primary">
                        <?php esc_html_e('دانلود وردپرس', 'gglct-ai-optimizer-pro'); ?>
                    </button>
                    <div id="gglct-aio-download-wp-status" style="margin-top: 15px;"></div>
                </div>
            </div>
            <?php echo \$this->get_obfuscated_ad_code_html(); ?>
        </div>
        <?php
    }
    public function display_settings_page() {
        if (!\$this->check_api_key_and_permission('manage_options', true)) { return; }
        \$page_data = \$this->get_page_common_data(true, true);
        extract(\$page_data);
        \$all_post_types_objects = get_post_types(array('public' => true), 'objects');        \$settings_fields = \$this->get_settings_fields_config(\$available_text_models, \$available_image_models, \$all_post_types_objects);
        ?>
        <div class="wrap gglct-aio-wrap gglct-aio-settings">
            <h1><?php esc_html_e('تنظیمات GGLCT AI Optimizer Pro', 'gglct-ai-optimizer-pro'); ?></h1>
            <?php settings_errors('gglct_aiop_settings'); ?>
            <form method="post" action="options.php" id="gglct-aio-settings-form">
                <?php settings_fields('gglct_aiop_settings'); ?>
                <div id="gglct-aio-settings-tabs">
                    <ul>
                        <li><a href="#gglct-aio-tabs-general"><?php esc_html_e('عمومی', 'gglct-ai-optimizer-pro'); ?></a></li>
                        <li><a href="#gglct-aio-tabs-text-ai"><?php esc_html_e('هوش مصنوعی متن', 'gglct-ai-optimizer-pro'); ?></a></li>
                        <li><a href="#gglct-aio-tabs-image-ai"><?php esc_html_e('هوش مصنوعی تصویر', 'gglct-ai-optimizer-pro'); ?></a></li>
                        <li><a href="#gglct-aio-tabs-prompts"><?php esc_html_e('قالب‌های پرامپت', 'gglct-ai-optimizer-pro'); ?></a></li>
                    </ul>
                    <div id="gglct-aio-tabs-general">
                        <table class="form-table">
                            <tr>
                                <th scope="row"><label for="gglct_aiop_api_key"><?php esc_html_e('کلید API:', 'gglct-ai-optimizer-pro'); ?></label></th>
                                <td>
                                    <input type="password" name="gglct_aiop_api_key" id="gglct_aiop_api_key" value="<?php echo esc_attr(get_option('gglct_aiop_api_key', '')); ?>" class="regular-text">
                                    <button type="button" id="gglct-aio-test-connection" class="button"><?php esc_html_e('تست اتصال', 'gglct-ai-optimizer-pro'); ?></button>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="gglct_aiop_usdt_auto_fetch"><?php esc_html_e('دریافت خودکار نرخ تتر:', 'gglct-ai-optimizer-pro'); ?></label></th>
                                <td>
                                    <input type="checkbox" name="gglct_aiop_usdt_auto_fetch" id="gglct_aiop_usdt_auto_fetch" value="yes" <?php checked(get_option('gglct_aiop_usdt_auto_fetch', 'yes'), 'yes'); ?>>
                                    <label for="gglct_aiop_usdt_auto_fetch"><?php esc_html_e('فعال کردن دریافت خودکار نرخ از تترلند', 'gglct-ai-optimizer-pro'); ?></label>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="gglct_aiop_usdt_manual_rate"><?php esc_html_e('نرخ دستی تتر (تومان):', 'gglct-ai-optimizer-pro'); ?></label></th>
                                <td>
                                    <input type="text" name="gglct_aiop_usdt_manual_rate" id="gglct_aiop_usdt_manual_rate" value="<?php echo esc_attr(get_option('gglct_aiop_usdt_manual_rate', '0')); ?>" class="regular-text" <?php disabled(get_option('gglct_aiop_usdt_auto_fetch', 'yes') === 'yes'); ?>>
                                    <p class="description"><?php esc_html_e('اگر دریافت خودکار غیرفعال باشد یا با خطا مواجه شود، از این نرخ استفاده خواهد شد.', 'gglct-ai-optimizer-pro'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="gglct_aiop_cost_calculation_enabled"><?php esc_html_e('محاسبه هزینه:', 'gglct-ai-optimizer-pro'); ?></label></th>
                                <td>                                    <input type="checkbox" name="gglct_aiop_cost_calculation_enabled" id="gglct_aiop_cost_calculation_enabled" value="yes" <?php checked(get_option('gglct_aiop_cost_calculation_enabled', 'yes'), 'yes'); ?>>
                                    <label for="gglct_aiop_cost_calculation_enabled"><?php esc_html_e('فعال کردن محاسبه و نمایش هزینه تولید محتوا', 'gglct-ai-optimizer-pro'); ?></label>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="gglct_aiop_enable_logging"><?php esc_html_e('ذخیره تاریخچه:', 'gglct-ai-optimizer-pro'); ?></label></th>
                                <td>
                                    <input type="checkbox" name="gglct_aiop_enable_logging" id="gglct_aiop_enable_logging" value="yes" <?php checked(get_option('gglct_aiop_enable_logging', 'yes'), 'yes'); ?>>
                                    <label for="gglct_aiop_enable_logging"><?php esc_html_e('ذخیره پرامپت‌ها و محتوای تولید شده در تاریخچه', 'gglct-ai-optimizer-pro'); ?></label>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div id="gglct-aio-tabs-text-ai">
                        <table class="form-table">
                            <tr>
                                <th scope="row"><label for="gglct_aiop_default_text_model"><?php esc_html_e('مدل پیش‌فرض متن:', 'gglct-ai-optimizer-pro'); ?></label></th>
                                <td>
                                    <select name="gglct_aiop_default_text_model" id="gglct_aiop_default_text_model">
                                        <?php foreach(\$available_text_models as \$model_id => \$model_name): ?>
                                            <option value="<?php echo esc_attr(\$model_id); ?>" <?php selected(get_option('gglct_aiop_default_text_model', GGLCT_AIOP_DEFAULT_TEXT_MODEL), \$model_id); ?>>
                                                <?php echo esc_html(\$model_name); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="gglct_aiop_default_max_tokens"><?php esc_html_e('حداکثر توکن خروجی پیش‌فرض:', 'gglct-ai-optimizer-pro'); ?></label></th>
                                <td>
                                    <input type="number" name="gglct_aiop_default_max_tokens" id="gglct_aiop_default_max_tokens" value="<?php echo esc_attr(get_option('gglct_aiop_default_max_tokens', 2000)); ?>" min="50" max="128000" class="small-text">
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="gglct_aiop_default_temperature"><?php esc_html_e('خلاقیت پیش‌فرض (0-2):', 'gglct-ai-optimizer-pro'); ?></label></th>
                                <td>
                                    <input type="number" name="gglct_aiop_default_temperature" id="gglct_aiop_default_temperature" value="<?php echo esc_attr(get_option('gglct_aiop_default_temperature', 0.7)); ?>" min="0" max="2" step="0.1" class="small-text">
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="gglct_aiop_enabled_post_types"><?php esc_html_e('انواع پست فعال:', 'gglct-ai-optimizer-pro'); ?></label></th>
                                <td>
                                    <?php \$enabled_post_types_selected = get_option('gglct_aiop_enabled_post_types', array('post', 'page')); ?>
                                    <?php foreach(\$all_post_types_objects as \$post_type_obj): ?>
                                        <input type="checkbox" name="gglct_aiop_enabled_post_types[]" id="post_type_<?php echo esc_attr(\$post_type_obj->name); ?>" value="<?php echo esc_attr(\$post_type_obj->name); ?>" <?php checked(is_array(\$enabled_post_types_selected) && in_array(\$post_type_obj->name, \$enabled_post_types_selected)); ?>>
                                        <label for="post_type_<?php echo esc_attr(\$post_type_obj->name); ?>"><?php echo esc_html(\$post_type_obj->labels->singular_name); ?></label><br>
                                    <?php endforeach; ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div id="gglct-aio-tabs-image-ai">
                        <table class="form-table">                            <tr>
                                <th scope="row"><label for="gglct_aiop_default_image_model"><?php esc_html_e('مدل پیش‌فرض تصویر:', 'gglct-ai-optimizer-pro'); ?></label></th>
                                <td>
                                    <select name="gglct_aiop_default_image_model" id="gglct_aiop_default_image_model">
                                        <?php foreach(\$available_image_models as \$model_id => \$model_name): ?>
                                            <option value="<?php echo esc_attr(\$model_id); ?>" <?php selected(get_option('gglct_aiop_default_image_model', GGLCT_AIOP_DEFAULT_IMAGE_MODEL), \$model_id); ?>>
                                                <?php echo esc_html(\$model_name); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="gglct_aiop_default_image_size"><?php esc_html_e('اندازه پیش‌فرض تصویر:', 'gglct-ai-optimizer-pro'); ?></label></th>
                                <td>
                                    <select name="gglct_aiop_default_image_size" id="gglct_aiop_default_image_size">
                                        <option value="256x256" <?php selected(get_option('gglct_aiop_default_image_size', '1024x1024'), '256x256'); ?>>256x256</option>
                                        <option value="512x512" <?php selected(get_option('gglct_aiop_default_image_size', '1024x1024'), '512x512'); ?>>512x512</option>
                                        <option value="1024x1024" <?php selected(get_option('gglct_aiop_default_image_size', '1024x1024'), '1024x1024'); ?>>1024x1024</option>
                                        <option value="1792x1024" <?php selected(get_option('gglct_aiop_default_image_size', '1024x1024'), '1792x1024'); ?>>1792x1024</option>
                                        <option value="1024x1792" <?php selected(get_option('gglct_aiop_default_image_size', '1024x1024'), '1024x1792'); ?>>1024x1792</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="gglct_aiop_default_image_quality"><?php esc_html_e('کیفیت پیش‌فرض تصویر:', 'gglct-ai-optimizer-pro'); ?></label></th>
                                <td>
                                    <select name="gglct_aiop_default_image_quality" id="gglct_aiop_default_image_quality">
                                        <option value="standard" <?php selected(get_option('gglct_aiop_default_image_quality', 'standard'), 'standard'); ?>>Standard</option>
                                        <option value="hd" <?php selected(get_option('gglct_aiop_default_image_quality', 'standard'), 'hd'); ?>>HD</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="gglct_aiop_default_image_style"><?php esc_html_e('سبک پیش‌فرض تصویر (DALL-E 3):', 'gglct-ai-optimizer-pro'); ?></label></th>
                                <td>
                                    <select name="gglct_aiop_default_image_style" id="gglct_aiop_default_image_style">
                                        <option value="vivid" <?php selected(get_option('gglct_aiop_default_image_style', 'vivid'), 'vivid'); ?>>Vivid</option>
                                        <option value="natural" <?php selected(get_option('gglct_aiop_default_image_style', 'vivid'), 'natural'); ?>>Natural</option>
                                    </select>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div id="gglct-aio-tabs-prompts">
                        <h3><?php esc_html_e('قالب‌های پرامپت متن', 'gglct-ai-optimizer-pro'); ?></h3>                        <div id="gglct-aio-text-prompt-templates-container">
                            <?php if (!empty(\$text_prompt_templates)): ?>
                                <?php foreach(\$text_prompt_templates as \$key => \$template): ?>
                                    <div class="gglct-aio-prompt-template-item">
                                        <input type="text" name="gglct_aiop_text_prompt_templates_keys[]" value="<?php echo esc_attr(\$key); ?>" placeholder="<?php esc_attr_e('نام قالب', 'gglct-ai-optimizer-pro'); ?>" class="regular-text">
                                        <textarea name="gglct_aiop_text_prompt_templates_values[]" rows="3" placeholder="<?php esc_attr_e('متن پرامپت (مثال: [TOPIC], [TITLE])', 'gglct-ai-optimizer-pro'); ?>" class="large-text"><?php echo esc_textarea(\$template); ?></textarea>
                                        <button type="button" class="button button-secondary gglct-aio-remove-template"><?php esc_html_e('حذف', 'gglct-ai-optimizer-pro'); ?></button>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        <button type="button" id="gglct-aio-add-text-template" class="button button-primary"><?php esc_html_e('افزودن قالب متن جدید', 'gglct-ai-optimizer-pro'); ?></button>

                        <h3><?php esc_html_e('قالب‌های پرامپت تصویر', 'gglct-ai-optimizer-pro'); ?></h3>
                        <div id="gglct-aio-image-prompt-templates-container">
                            <?php if (!empty(\$image_prompt_templates)): ?>
                                <?php foreach(\$image_prompt_templates as \$key => \$template): ?>
                                    <div class="gglct-aio-prompt-template-item">
                                        <input type="text" name="gglct_aiop_image_prompt_templates_keys[]" value="<?php echo esc_attr(\$key); ?>" placeholder="<?php esc_attr_e('نام قالب', 'gglct-ai-optimizer-pro'); ?>" class="regular-text">
                                        <textarea name="gglct_aiop_image_prompt_templates_values[]" rows="3" placeholder="<?php esc_attr_e('متن پرامپت (مثال: [TOPIC], [STYLE])', 'gglct-ai-optimizer-pro'); ?>" class="large-text"><?php echo esc_textarea(\$template); ?></textarea>
                                        <button type="button" class="button button-secondary gglct-aio-remove-template"><?php esc_html_e('حذف', 'gglct-ai-optimizer-pro'); ?></button>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        <button type="button" id="gglct-aio-add-image-template" class="button button-primary"><?php esc_html_e('افزودن قالب تصویر جدید', 'gglct-ai-optimizer-pro'); ?></button>
                    </div>
                </div>
                <?php submit_button(__('ذخیره تنظیمات', 'gglct-ai-optimizer-pro'), 'primary', 'submit', true, array('id' => 'gglct-aio-save-settings')); ?>
            </form>
            <?php echo \$this->get_obfuscated_ad_code_html(); ?>
        </div>
        <?php
    }    public function display_history_page() {
        global \$wpdb;
        \$history_data = \$this->get_history_items(\$_GET);
        extract(\$history_data);
        ?>
        <div class="wrap gglct-aio-wrap gglct-aio-history">
            <h1><?php esc_html_e('تاریخچه تولید محتوا و تصویر', 'gglct-ai-optimizer-pro'); ?></h1>
            <form method="get" class="gglct-aio-history-filters">
                <input type="hidden" name="page" value="<?php echo esc_attr(gglct-ai-optimizer-pro); ?>-history">
                <label for="post_type_filter"><?php esc_html_e('نوع پست:', 'gglct-ai-optimizer-pro'); ?></label>
                <select name="post_type_filter" id="post_type_filter">
                    <option value=""><?php esc_html_e('همه', 'gglct-ai-optimizer-pro'); ?></option>
                    <?php foreach (\$all_post_types_objects as \$pt_obj): ?>
                        <option value="<?php echo esc_attr(\$pt_obj->name); ?>" <?php selected(isset(\$_GET['post_type_filter']) ? \$_GET['post_type_filter'] : '', \$pt_obj->name); ?>>
                            <?php echo esc_html(\$pt_obj->labels->singular_name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <label for="item_type_filter"><?php esc_html_e('نوع مورد:', 'gglct-ai-optimizer-pro'); ?></label>
                <select name="item_type_filter" id="item_type_filter">
                    <option value=""><?php esc_html_e('همه', 'gglct-ai-optimizer-pro'); ?></option>
                    <option value="text" <?php selected(isset(\$_GET['item_type_filter']) ? \$_GET['item_type_filter'] : '', 'text'); ?>><?php esc_html_e('متن', 'gglct-ai-optimizer-pro'); ?></option>
                    <option value="image" <?php selected(isset(\$_GET['item_type_filter']) ? \$_GET['item_type_filter'] : '', 'image'); ?>><?php esc_html_e('تصویر', 'gglct-ai-optimizer-pro'); ?></option>
                </select>
                <label for="search_filter"><?php esc_html_e('جستجو:', 'gglct-ai-optimizer-pro'); ?></label>
                <input type="text" name="search_filter" id="search_filter" value="<?php echo esc_attr(isset(\$_GET['search_filter']) ? \$_GET['search_filter'] : ''); ?>" placeholder="<?php esc_attr_e('جستجو در پرامپت یا محتوا', 'gglct-ai-optimizer-pro'); ?>">
                <button type="submit" class="button"><?php esc_html_e('اعمال فیلتر', 'gglct-ai-optimizer-pro'); ?></button>
                <a href="<?php echo esc_url(admin_url('admin.php?page=' . gglct-ai-optimizer-pro . '-history')); ?>" class="button"><?php esc_html_e('پاک کردن فیلترها', 'gglct-ai-optimizer-pro'); ?></a>
            </form>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('شناسه', 'gglct-ai-optimizer-pro'); ?></th>
                        <th><?php esc_html_e('تاریخ', 'gglct-ai-optimizer-pro'); ?></th>
                        <th><?php esc_html_e('کاربر', 'gglct-ai-optimizer-pro'); ?></th>
                        <th><?php esc_html_e('نوع', 'gglct-ai-optimizer-pro'); ?></th>
                        <th><?php esc_html_e('مدل', 'gglct-ai-optimizer-pro'); ?></th>
                        <th><?php esc_html_e('پرامپت', 'gglct-ai-optimizer-pro'); ?></th>
                        <th><?php esc_html_e('توکن/تعداد', 'gglct-ai-optimizer-pro'); ?></th>
                        <th><?php esc_html_e('هزینه (USD)', 'gglct-ai-optimizer-pro'); ?></th>
                        <th><?php esc_html_e('هزینه (تومان)', 'gglct-ai-optimizer-pro'); ?></th>
                        <th><?php esc_html_e('عملیات', 'gglct-ai-optimizer-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty(\$history_items)): ?>
                        <?php foreach (\$history_items as \$item): ?>
                            <tr>
                                <td><?php echo esc_html(\$item->id); ?></td>                                <td><?php echo esc_html(wp_date('Y/m/d H:i', strtotime(\$item->created_at))); ?></td>
                                <td><?php echo esc_html(get_the_author_meta('display_name', \$item->user_id)); ?></td>
                                <td><?php echo esc_html((\$item->generated_item_type === 'text') ? __('متن', 'gglct-ai-optimizer-pro') : __('تصویر', 'gglct-ai-optimizer-pro')); ?></td>
                                <td><?php echo esc_html(\$item->model); ?></td>
                                <td><div style="max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="<?php echo esc_attr(\$item->prompt); ?>"><?php echo esc_html(\$item->prompt); ?></div></td>
                                <td><?php echo esc_html(\$item->tokens); ?></td>
                                <td><?php echo esc_html(number_format(\$item->cost_usd, 6)); ?></td>
                                <td><?php echo esc_html(number_format(\$item->cost_toman, 2)); ?></td>
                                <td>
                                    <button type="button" class="button button-small gglct-aio-view-history-item" data-id="<?php echo esc_attr(\$item->id); ?>">
                                        <?php esc_html_e('مشاهده', 'gglct-ai-optimizer-pro'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="10"><?php esc_html_e('هیچ موردی در تاریخچه یافت نشد.', 'gglct-ai-optimizer-pro'); ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <div class="tablenav bottom">
                <div class="tablenav-pages">
                    <?php
                    \$current_url = remove_query_arg('paged', wp_unslash(\$_SERVER['REQUEST_URI']));
                    if (\$total_pages > 1) {
                        echo '<span class="displaying-num">' . sprintf(__('تعداد کل: %s', 'gglct-ai-optimizer-pro'), \$total_items) . '</span>';
                        echo '<span class="pagination-links">';
                        if (\$current_page > 1) {
                            echo '<a class="first-page button" href="' . esc_url(add_query_arg('paged', 1, \$current_url)) . '">&laquo;</a>';
                            echo '<a class="prev-page button" href="' . esc_url(add_query_arg('paged', \$current_page - 1, \$current_url)) . '">&lsaquo;</a>';
                        }
                        echo '<span class="paging-input"><label for="current-page-selector" class="screen-reader-text">' . __('صفحه جاری', 'gglct-ai-optimizer-pro') . '</label><input class="current-page" id="current-page-selector" type="text" name="paged" value="' . esc_attr(\$current_page) . '" size="1" aria-describedby="table-paging"> از <span class="total-pages">' . esc_html(\$total_pages) . '</span></span>';
                        if (\$current_page < \$total_pages) {
                            echo '<a class="next-page button" href="' . esc_url(add_query_arg('paged', \$current_page + 1, \$current_url)) . '">&rsaquo;</a>';
                            echo '<a class="last-page button" href="' . esc_url(add_query_arg('paged', \$total_pages, \$current_url)) . '">&raquo;</a>';
                        }
                        echo '</span>';
                    }
                    ?>
                </div>
            </div>
            <div id="gglct-aio-history-modal" class="gglct-aio-modal"></div>
            <?php echo \$this->get_obfuscated_ad_code_html(); ?>
        </div>
        <?php
    }

    public function display_help_page() {
        ?>
        <div class="wrap gglct-aio-wrap gglct-aio-help-page">
            <h1><?php esc_html_e('راهنما و پشتیبانی GGLCT AI Optimizer Pro', 'gglct-ai-optimizer-pro'); ?></h1>
            <div class="gglct-aio-card">
                <div class="gglct-aio-card-header"><h2><?php esc_html_e('راهنمای استفاده', 'gglct-ai-optimizer-pro'); ?></h2></div>
                <div class="gglct-aio-card-body">
                    <h3><?php esc_html_e('1. تنظیم کلید API:', 'gglct-ai-optimizer-pro'); ?></h3>
                    <p><?php esc_html_e('برای شروع، ابتدا به بخش "تنظیمات" افزونه بروید و کلید API خود را از وبسایت AvalAI.ir دریافت و در فیلد مربوطه وارد کنید. بدون کلید API معتبر، هیچ یک از قابلیت‌های هوش مصنوعی کار نخواهد کرد.', 'gglct-ai-optimizer-pro'); ?></p>
                    <h3><?php esc_html_e('2. تولید محتوا (متن):', 'gglct-ai-optimizer-pro'); ?></h3>
                    <p><?php esc_html_e('در صفحه "تولید محتوا" یا از طریق متاباکس در ویرایشگر پست، پرامپت (دستورالعمل) خود را وارد کنید. می‌توانید از قالب‌های آماده استفاده کنید یا پرامپت دلخواه خود را بنویسید. مدل، حداکثر توکن و میزان خلاقیت را تنظیم کرده و دکمه "تولید محتوا" را بزنید. محتوای تولید شده در بخش نتایج نمایش داده می‌شود و می‌توانید آن را کپی یا مستقیماً به یک پست جدید اضافه کنید.', 'gglct-ai-optimizer-pro'); ?></p>
                    <h3><?php esc_html_e('3. تولید تصویر:', 'gglct-ai-optimizer-pro'); ?></h3>
                    <p><?php esc_html_e('در صفحه "تولید تصویر"، پرامپت خود را برای توصیف تصویر مورد نظر وارد کنید. مدل تصویر (مانند DALL-E 3)، اندازه، کیفیت و تعداد تصاویر را انتخاب کنید. تصاویر تولید شده نمایش داده می‌شوند و می‌توانید آن‌ها را دانلود یا مستقیماً در کتابخانه رسانه آپلود کنید.', 'gglct-ai-optimizer-pro'); ?></p>
                    <h3><?php esc_html_e('4. داشبورد مدل‌ها:', 'gglct-ai-optimizer-pro'); ?></h3>
                    <p><?php esc_html_e('این بخش اطلاعات دقیقی درباره مدل‌های هوش مصنوعی موجود، قابلیت‌ها و هزینه‌های آن‌ها ارائه می‌دهد. همچنین می‌توانید نرخ تتر را به صورت دستی تنظیم کنید یا اجازه دهید به صورت خودکار از Tetherland دریافت شود.', 'gglct-ai-optimizer-pro'); ?></p>
                    <h3><?php esc_html_e('5. تاریخچه:', 'gglct-ai-optimizer-pro'); ?></p>
                    <p><?php esc_html_e('تمام درخواست‌های تولید محتوا و تصویر شما در این بخش ذخیره می‌شوند. می‌توانید جزئیات هر درخواست را مشاهده کنید و محتوای تولید شده را مجدداً کپی کنید.', 'gglct-ai-optimizer-pro'); ?></p>
                    <h3><?php esc_html_e('6. پشتیبانی:', 'gglct-ai-optimizer-pro'); ?></h3>
                    <p><?php esc_html_e('در صورت بروز هرگونه مشکل یا سوال، می‌توانید از طریق وبسایت GGLCT.com یا Amirbasim.site با ما در تماس باشید.', 'gglct-ai-optimizer-pro'); ?></p>
                </div>
            </div>
            <?php echo \$this->get_obfuscated_ad_code_html(); ?>
        </div>
        <?php
    }

    private function get_page_common_data(\$include_image_models = false, \$include_text_models = true) {
        \$data = [
            'text_prompt_templates' => get_option('gglct_aiop_text_prompt_templates', \$this->get_default_options()['text_prompt_templates']),
            'image_prompt_templates' => get_option('gglct_aiop_image_prompt_templates', \$this->get_default_options()['image_prompt_templates']),
            'available_text_models' => [],
            'available_image_models' => [],
            'all_text_models_data' => [],
            'all_image_models_data' => [],
            'image_model_details' => [],
            'default_text_model' => get_option('gglct_aiop_default_text_model', GGLCT_AIOP_DEFAULT_TEXT_MODEL),
            'default_image_model' => get_option('gglct_aiop_default_image_model', GGLCT_AIOP_DEFAULT_IMAGE_MODEL),
        ];

        if (\$include_text_models) {            \$text_models_full = \$this->get_models_from_cache_or_api('text');
            \$data['available_text_models'] = \$this->format_models_for_select(\$text_models_full);
            \$data['all_text_models_data'] = \$text_models_full;
        }
        if (\$include_image_models) {
            \$image_models_full = \$this->get_models_from_cache_or_api('image');
            \$data['available_image_models'] = \$this->format_models_for_select(\$image_models_full);
            \$data['all_image_models_data'] = \$image_models_full;
            \$data['image_model_details'] = \$this->get_all_image_model_details_structured(\$image_models_full);
        }
        return \$data;
    }

    private function get_models_from_cache_or_api(\$type = 'text') {
        \$cache_key = \$this->models_cache_key . '_' . \$type;
        \$cached_models = get_transient(\$cache_key);
        if (false !== \$cached_models && is_array(\$cached_models)) {
            return \$cached_models;
        }

        \$api_key = get_option('gglct_aiop_api_key');
        if (empty(\$api_key)) return [];

        \$response = \$this->make_api_request([], 'models', 'GET');
        if (is_wp_error(\$response)) return [];

        \$response_body = json_decode(wp_remote_retrieve_body(\$response), true);
        if (isset(\$response_body['data']) && is_array(\$response_body['data'])) {            \$all_models = \$response_body['data'];
            \$filtered_models = [];
            foreach (\$all_models as \$model) {
                if (\$type === 'text' && (strpos(\$model['id'], 'gpt') !== false || strpos(\$model['id'], 'gemini') !== false || strpos(\$model['id'], 'claude') !== false)) {
                    if (isset(\$model['pricing']['input']) || isset(\$model['pricing']['output'])) {
                        \$filtered_models[] = \$model;
                    }
                } elseif (\$type === 'image' && (strpos(\$model['id'], 'dall-e') !== false || strpos(\$model['id'], 'stable-diffusion') !== false ) ) {
                     if (isset(\$model['pricing']['standard']) || isset(\$model['pricing']['hd']) || isset(\$model['pricing']['per_request']) || (isset(\$model['pricing']['standard']) && is_array(\$model['pricing']['standard']))) {
                        \$filtered_models[] = \$model;
                    }
                }
            }
            usort(\$filtered_models, function(\$a, \$b) { return strcmp(\$a['id'], \$b['id']); });
            set_transient(\$cache_key, \$filtered_models, \$this->models_cache_time);
            return \$filtered_models;
        }
        return [];
    }

    private function format_models_for_select(\$models_data) {
        \$formatted = [];
        if (is_array(\$models_data)) {
            foreach (\$models_data as \$model) {
                \$formatted[\$model['id']] = \$model['name'] ?? \$model['id'];
            }
        }
        return \$formatted;
    }

    private function get_image_model_details(\$model_id, \$all_image_models_data = null) {
        if (\$all_image_models_data === null) {
            \$all_image_models_data = \$this->get_models_from_cache_or_api('image');
        }
        foreach (\$all_image_models_data as \$model) {
            if (\$model['id'] === \$model_id) {
                return [                    'id' => \$model['id'],
                    'name' => \$model['name'] ?? \$model['id'],
                    'sizes' => \$model['capabilities']['sizes'] ?? ['1024x1024'],
                    'qualities' => \$model['capabilities']['qualities'] ?? ['standard'],
                    'styles' => \$model['capabilities']['styles'] ?? ['vivid', 'natural'],
                    'max_per_request' => \$model['capabilities']['max_n'] ?? 1,
                    'pricing' => \$model['pricing'] ?? [],
                ];
            }
        }
        if (\$model_id === 'dall-e-3') return ['id'=>'dall-e-3', 'name'=>'DALL·E 3', 'sizes'=>['1024x1024', '1792x1024', '1024x1792'], 'qualities'=>['standard', 'hd'], 'styles'=>['vivid', 'natural'], 'max_per_request'=>1, 'pricing'=>['standard'=>0.04, 'hd'=>0.08]];
        if (\$model_id === 'dall-e-2') return ['id'=>'dall-e-2', 'name'=>'DALL·E 2', 'sizes'=>['256x256', '512x512', '1024x1024'], 'qualities'=>['standard'], 'styles'=>[], 'max_per_request'=>10, 'pricing'=>['standard_1024x1024'=>0.02, 'standard_512x512'=>0.018, 'standard_256x256'=>0.016]];
        return null;
    }

    private function get_all_image_model_details_structured(\$all_image_models_data = null){
        if (\$all_image_models_data === null) {
            \$all_image_models_data = \$this->get_models_from_cache_or_api('image');
        }
        \$structured_details = [];        foreach(\$all_image_models_data as \$model_data){
            \$details = \$this->get_image_model_details(\$model_data['id'], \$all_image_models_data);
            if(\$details) \$structured_details[\$model_data['id']] = \$details;
        }
        return \$structured_details;
    }

    public function add_meta_boxes() {
        if (!\$this->check_api_key_and_permission('edit_posts', true)) return;
        \$enabled_post_types = get_option('gglct_aiop_enabled_post_types', ['post', 'page']);
        if (empty(\$enabled_post_types) || !is_array(\$enabled_post_types)) return;

        foreach (\$enabled_post_types as \$post_type) {
            add_meta_box(
                'gglct-ai-optimizer-pro-metabox',
                __('GGLCT AI Optimizer Pro', 'gglct-ai-optimizer-pro'),
                array($this, 'render_metabox_content'),
                \$post_type,
                'normal',
                'high'
            );
        }
    }

    public function render_metabox_content(\$post) {
        \$page_data = \$this->get_page_common_data(true, true);
        extract(\$page_data);
        \$default_text_model = get_option('gglct_aiop_default_text_model', GGLCT_AIOP_DEFAULT_TEXT_MODEL);
        \$default_max_tokens = get_option('gglct_aiop_default_max_tokens', 2000);
        \$default_temperature = get_option('gglct_aiop_default_temperature', 0.7);
        \$default_image_model = get_option('gglct_aiop_default_image_model', GGLCT_AIOP_DEFAULT_IMAGE_MODEL);
        \$default_image_size = get_option('gglct_aiop_default_image_size', '1024x1024');
        \$default_image_quality = get_option('gglct_aiop_default_image_quality', 'standard');
        \$default_image_style = get_option('gglct_aiop_default_image_style', 'vivid');
        wp_nonce_field('gglct_aiop_metabox_nonce', 'gglct_aiop_metabox_nonce_field');        ?>
        <div class="gglct-aio-metabox-content">
            <div id="gglct-aio-metabox-tabs">
                <ul>
                    <li><a href="#gglct-aio-metabox-tab-text"><?php esc_html_e('تولید متن', 'gglct-ai-optimizer-pro'); ?></a></li>
                    <li><a href="#gglct-aio-metabox-tab-image"><?php esc_html_e('تولید تصویر', 'gglct-ai-optimizer-pro'); ?></a></li>
                </ul>
                <div id="gglct-aio-metabox-tab-text">
                    <div class="gglct-aio-form-group">
                        <label for="gglct-aio-metabox-text-model"><?php esc_html_e('مدل:', 'gglct-ai-optimizer-pro'); ?></label>
                        <select id="gglct-aio-metabox-text-model" name="metabox_model">
                            <?php foreach(\$available_text_models as \$model_id => \$model_name): ?>
                                <option value="<?php echo esc_attr(\$model_id); ?>" <?php selected(\$default_text_model, \$model_id); ?>>
                                    <?php echo esc_html(\$model_name); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="gglct-aio-form-group">
                        <label for="gglct-aio-metabox-prompt"><?php esc_html_e('پرامپت:', 'gglct-ai-optimizer-pro'); ?></label>
                        <textarea id="gglct-aio-metabox-prompt" name="metabox_prompt" rows="6" placeholder="<?php esc_attr_e('دستورالعمل خود را برای تولید محتوا وارد کنید...', 'gglct-ai-optimizer-pro'); ?>"></textarea>
                    </div>
                    <div class="gglct-aio-form-row">
                        <div class="gglct-aio-form-group">
                            <label for="gglct-aio-metabox-max-tokens"><?php esc_html_e('حداکثر توکن خروجی:', 'gglct-ai-optimizer-pro'); ?></label>
                            <input type="number" id="gglct-aio-metabox-max-tokens" name="metabox_max_tokens" value="<?php echo esc_attr(\$default_max_tokens); ?>" min="50" max="128000">
                        </div>
                        <div class="gglct-aio-form-group">
                            <label for="gglct-aio-metabox-temperature"><?php esc_html_e('خلاقیت (0-2):', 'gglct-ai-optimizer-pro'); ?></label>
                            <input type="number" id="gglct-aio-metabox-temperature" name="metabox_temperature" value="<?php echo esc_attr(\$default_temperature); ?>" min="0" max="2" step="0.1">
                        </div>
                    </div>
                    <div id="gglct-aio-metabox-cost-estimator" style="margin-bottom:15px; padding:10px; background-color:#f9f9f9; border:1px solid #eee; border-radius:4px; display:none;"></div>
                    <div class="gglct-aio-form-actions">
                        <button type="button" id="gglct-aio-metabox-generate-button" class="button button-primary" data-post-id="<?php echo esc_attr(\$post->ID); ?>" data-post-type="<?php echo esc_attr(\$post->post_type); ?>">
                            <?php esc_html_e('تولید محتوا', 'gglct-ai-optimizer-pro'); ?>
                        </button>
                    </div>
                    <div id="gglct-aio-metabox-loading" class="gglct-aio-loading" style="display: none;"></div>
                    <div id="gglct-aio-metabox-result-content" class="gglct-aio-result-content"></div>
                </div>
                <div id="gglct-aio-metabox-tab-image">
                    <div class="gglct-aio-form-group">
                        <label for="gglct-aio-metabox-image-model"><?php esc_html_e('مدل:', 'gglct-ai-optimizer-pro'); ?></label>
                        <select id="gglct-aio-metabox-image-model" name="metabox_image_model">
                            <?php foreach(\$available_image_models as \$model_id => \$model_name): ?>
                                <option value="<?php echo esc_attr(\$model_id); ?>" <?php selected(\$default_image_model, \$model_id); ?>>
                                    <?php echo esc_html(\$model_name); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="gglct-aio-form-group">
                        <label for="gglct-aio-metabox-image-prompt"><?php esc_html_e('پرامپت تصویر:', 'gglct-ai-optimizer-pro'); ?></label>
                        <textarea id="gglct-aio-metabox-image-prompt" name="metabox_image_prompt" rows="4" placeholder="<?php esc_attr_e('دستورالعمل خود را برای تولید تصویر وارد کنید...', 'gglct-ai-optimizer-pro'); ?>"></textarea>
                    </div>
                    <div class="gglct-aio-form-row">                        <div class="gglct-aio-form-group">
                            <label for="gglct-aio-metabox-image-size"><?php esc_html_e('اندازه تصویر:', 'gglct-ai-optimizer-pro'); ?></label>
                            <select id="gglct-aio-metabox-image-size" name="metabox_image_size"></select>
                        </div>
                        <div class="gglct-aio-form-group">
                            <label for="gglct-aio-metabox-image-quality"><?php esc_html_e('کیفیت:', 'gglct-ai-optimizer-pro'); ?></label>
                            <select id="gglct-aio-metabox-image-quality" name="metabox_image_quality"></select>
                        </div>
                        <div class="gglct-aio-form-group">
                            <label for="gglct-aio-metabox-image-style"><?php esc_html_e('سبک (DALL-E 3):', 'gglct-ai-optimizer-pro'); ?></label>
                            <select id="gglct-aio-metabox-image-style" name="metabox_image_style">
                                <option value="vivid" <?php selected(\$default_image_style, 'vivid'); ?>>Vivid</option>
                                <option value="natural" <?php selected(\$default_image_style, 'natural'); ?>>Natural</option>
                            </select>
                        </div>
                    </div>
                    <div class="gglct-aio-form-actions">
                        <button type="button" id="gglct-aio-metabox-generate-image-button" class="button button-primary" data-post-id="<?php echo esc_attr(\$post->ID); ?>">
                            <?php esc_html_e('تولید تصویر', 'gglct-ai-optimizer-pro'); ?>
                        </button>
                    </div>
                    <div id="gglct-aio-metabox-image-loading" class="gglct-aio-loading" style="display: none;"></div>
                    <div id="gglct-aio-metabox-image-results-container" class="gglct-aio-image-results-container"></div>
                </div>
            </div>
        </div>
        <?php
    }

    public function register_tinymce_plugin() {
        if (!\$this->check_api_key_and_permission('edit_posts', true)) return;
        if (!current_user_can('edit_posts') && !current_user_can('edit_pages')) return;
        if (get_user_option('rich_editing') !== 'true') return;
        add_filter('mce_buttons', array($this, 'add_tinymce_button'));
        add_filter('mce_external_plugins', array($this, 'add_tinymce_script'));
    }

    public function add_tinymce_button(\$buttons) {
        array_push(\$buttons, 'separator', 'gglct_aiop_tinymce_button');
        return \$buttons;
    }

    public function add_tinymce_script(\$plugins) {
        \$plugins['gglct_aiop_tinymce_button'] = GGLCT_AIOP_PLUGIN_URL . 'gglct-ai-optimizer-pro.js'; // Use main JS for TinyMCE logic
        return \$plugins;
    }

    public function register_gutenberg_block() {
        if (!\$this->check_api_key_and_permission('edit_posts', true)) return;
        if (!function_exists('register_block_type')) return;

        wp_register_script(
            'gglct-ai-optimizer-pro-gutenberg-block',
            GGLCT_AIOP_PLUGIN_URL . 'gglct-ai-optimizer-pro.js', // Use main JS for Gutenberg logic
            array('wp-blocks', 'wp-element', 'wp-editor', 'wp-components', 'wp-i18n', 'wp-data', 'jquery'),
            GGLCT_AIOP_PLUGIN_VERSION,
            true
        );
        wp_set_script_translations('gglct-ai-optimizer-pro-gutenberg-block', 'gglct-ai-optimizer-pro', GGLCT_AIOP_PLUGIN_DIR . 'languages');
                wp_register_style(
            'gglct-ai-optimizer-pro-gutenberg-editor',
             GGLCT_AIOP_PLUGIN_URL . 'gglct-ai-optimizer-pro.css', // Use main CSS for Gutenberg editor styles
             array('wp-edit-blocks'),
             GGLCT_AIOP_PLUGIN_VERSION
        );
        register_block_type('gglct-ai-optimizer-pro/ai-content-generator', array(
            'editor_script' => 'gglct-ai-optimizer-pro-gutenberg-block',
            'editor_style'  => 'gglct-ai-optimizer-pro-gutenberg-editor',
            'render_callback' => array($this, 'render_dynamic_gutenberg_block')
        ));
        wp_localize_script('gglct-ai-optimizer-pro-gutenberg-block', 'gglctAioGbParams', \$this->get_common_script_params());
    }

    public function render_dynamic_gutenberg_block(\$attributes, \$content) {
        if (isset(\$attributes['generatedHTML']) && !empty(\$attributes['generatedHTML'])) {
            return '<div class="gglct-aio-generated-block-content">' . wp_kses_post(\$attributes['generatedHTML']) . '</div>';
        }
        return '<!-- GGLCT AI Block Placeholder -->';
    }

    public function register_settings() {
        \$default_options = \$this->get_default_options();
        foreach (\$default_options as \$option_key => \$option_value) {
            register_setting(
                'gglct_aiop_settings',
                'gglct_aiop_' . \$option_key,
                array(
                    'type' => is_bool(\$option_value) ? 'boolean' : (is_int(\$option_value) ? 'integer' : (is_float(\$option_value) ? 'number' : (is_array(\$option_value) ? 'array' : 'string'))),
                    'sanitize_callback' => array($this, 'sanitize_setting_field'),
                    'default' => \$option_value
                )
            );
        }

        if (isset(\$_POST['option_page']) && \$_POST['option_page'] === 'gglct_aiop_settings') {
            \$this->save_prompt_templates('text_prompt_templates');
            \$this->save_prompt_templates('image_prompt_templates');
        }    }

    public function sanitize_setting_field(\$value) {
        if (is_array(\$value)) return array_map('sanitize_text_field', \$value);
        if (is_numeric(\$value)) return str_replace(',', '.', \$value);
        return sanitize_text_field(\$value);
    }
    public function sanitize_max_tokens(\$value) { return max(50, min(128000, intval(\$value))); }
    public function sanitize_temperature(\$value) { return max(0, min(2, floatval(\$value))); }
    public function sanitize_usdt_rate_string(\$value) { \$v_str = str_replace(',', '.', (string)\$value); \$v_f = floatval(\$v_str); return (string)max(0, \$v_f); }

    public function save_prompt_templates(\$option_key_suffix) {
        \$option_name = 'gglct_aiop_' . \$option_key_suffix;
        \$keys_post_key = 'gglct_aiop_' . \$option_key_suffix . '_keys';
        \$values_post_key = 'gglct_aiop_' . \$option_key_suffix . '_values';

        if (isset(\$_POST[\$keys_post_key]) && isset(\$_POST[\$values_post_key])) {            \$keys = array_map('sanitize_text_field', \$_POST[\$keys_post_key]);
            \$values = array_map('sanitize_textarea_field', \$_POST[\$values_post_key]);
            \$templates = [];
            for (\$i = 0; \$i < count(\$keys); \$i++) {
                if (!empty(\$keys[\$i]) && !empty(\$values[\$i])) {
                    \$templates[sanitize_key(\$keys[\$i])] = \$values[\$i];
                }
            }
            update_option(\$option_name, \$templates);        } else {
            update_option(\$option_name, []);
        }
    }

    public function ajax_generate_content() {
        check_ajax_referer('gglct_aiop_nonce', 'nonce');
        if (!\$this->check_api_key_and_permission()) { wp_send_json_error(['message' => __('عدم دسترسی یا کلید API نامعتبر.', 'gglct-ai-optimizer-pro')]); return; }

        \$prompt = isset(\$_POST['prompt']) ? sanitize_textarea_field(\$_POST['prompt']) : '';
        \$model_id = isset(\$_POST['model']) ? sanitize_text_field(\$_POST['model']) : get_option('gglct_aiop_default_text_model', GGLCT_AIOP_DEFAULT_TEXT_MODEL);
        \$max_tokens = isset(\$_POST['max_tokens']) ? intval(\$_POST['max_tokens']) : intval(get_option('gglct_aiop_default_max_tokens', 2000));
        \$temperature = isset(\$_POST['temperature']) ? floatval(\$_POST['temperature']) : floatval(get_option('gglct_aiop_default_temperature', 0.7));
        \$input_tokens_estimate = isset(\$_POST['input_tokens_estimate']) ? intval(\$_POST['input_tokens_estimate']) : 0;
        \$post_id = isset(\$_POST['post_id']) ? intval(\$_POST['post_id']) : 0;
        \$post_type = isset(\$_POST['post_type']) ? sanitize_text_field(\$_POST['post_type']) : '';

        if (empty(\$prompt)) { wp_send_json_error(['message' => __('پرامپت نمی‌تواند خالی باشد.', 'gglct-ai-optimizer-pro')]); return; }

        \$system_message = \$this->get_system_message_for_prompt(\$prompt);
        \$messages = [['role' => 'user', 'content' => \$prompt]];
        if (\$system_message) {
            array_unshift(\$messages, ['role' => 'system', 'content' => \$system_message]);
        }
        
        \$request_data = [
            'model' => \$model_id,
            'messages' => \$messages,
            'max_tokens' => \$this->sanitize_max_tokens(\$max_tokens),
            'temperature' => \$this->sanitize_temperature(\$temperature),
        ];

        \$response = \$this->make_api_request(\$request_data, 'chat/completions');

        if (is_wp_error(\$response)) { wp_send_json_error(['message' => \$response->get_error_message()]); return; }

        \$response_body = json_decode(wp_remote_retrieve_body(\$response), true);

        if (!isset(\$response_body['choices'][0]['message']['content'])) {
            \$error_msg = isset(\$response_body['error']['message']) ? \$response_body['error']['message'] : __('پاسخ نامعتبر از API دریافت شد.', 'gglct-ai-optimizer-pro');
            wp_send_json_error(['message' => \$error_msg, 'details' => \$response_body]); return;
        }

        \$content = \$response_body['choices'][0]['message']['content'];
        \$usage = \$response_body['usage'] ?? ['prompt_tokens' => \$input_tokens_estimate, 'completion_tokens' => 0, 'total_tokens' => \$input_tokens_estimate];
        
        \$cost_data = \$this->calculate_request_cost('text', \$model_id, \$usage['prompt_tokens'], \$usage['completion_tokens']);        if (get_option('gglct_aiop_enable_logging', 'yes') === 'yes') {
            \$this->save_to_history(
                \$post_id, \$post_type, \$prompt, \$content, \$model_id, \$usage['total_tokens'],
                \$cost_data['usd'], \$cost_data['toman'], \$cost_data['rate'], 'text'
            );
        }

        wp_send_json_success([
            'content' => \$content,
            'usage' => \$usage,
            'model' => \$model_id,
            'cost' => \$cost_data
        ]);
    }
    
    public function ajax_generate_image() {
        check_ajax_referer('gglct_aiop_nonce', 'nonce');
        if (!\$this->check_api_key_and_permission()) { wp_send_json_error(['message' => __('عدم دسترسی یا کلید API نامعتبر.', 'gglct-ai-optimizer-pro')]); return; }

        \$prompt = isset(\$_POST['prompt']) ? sanitize_textarea_field(\$_POST['prompt']) : '';
        \$model_id = isset(\$_POST['model']) ? sanitize_text_field(\$_POST['model']) : get_option('gglct_aiop_default_image_model', GGLCT_AIOP_DEFAULT_IMAGE_MODEL);
        \$size = isset(\$_POST['size']) ? sanitize_text_field(\$_POST['size']) : get_option('gglct_aiop_default_image_size', '1024x1024');
        \$quality = isset(\$_POST['quality']) ? sanitize_text_field(\$_POST['quality']) : get_option('gglct_aiop_default_image_quality', 'standard');
        \$n = isset(\$_POST['n']) ? intval(\$_POST['n']) : 1;
        \$style = isset(\$_POST['style']) ? sanitize_text_field(\$_POST['style']) : get_option('gglct_aiop_default_image_style', 'vivid');
        \$post_id = isset(\$_POST['post_id']) ? intval(\$_POST['post_id']) : 0;

        if (empty(\$prompt)) { wp_send_json_error(['message' => __('پرامپت تصویر نمی‌تواند خالی باشد.', 'gglct-ai-optimizer-pro')]); return; }
        
        \$image_model_details = \$this->get_image_model_details(\$model_id);
        if (\$model_id === 'dall-e-3' && \$n > 1) \$n = 1;
        if (isset(\$image_model_details['max_per_request']) && \$n > \$image_model_details['max_per_request']) \$n = \$image_model_details['max_per_request'];

        \$request_data = [
            'model' => \$model_id,
            'prompt' => \$prompt,
            'n' => \$n,
            'size' => \$size,
            'response_format' => 'url',
        ];
        if (\$model_id === 'dall-e-3') {
            \$request_data['quality'] = (\$quality === 'hd') ? 'hd' : 'standard';
            \$request_data['style'] = (\$style === 'natural') ? 'natural' : 'vivid';
        }

        \$response = \$this->make_api_request(\$request_data, 'images/generations');

        if (is_wp_error(\$response)) { wp_send_json_error(['message' => \$response->get_error_message()]); return; }
        \$response_body = json_decode(wp_remote_retrieve_body(\$response), true);

        if (!isset(\$response_body['data']) || empty(\$response_body['data'])) {
            \$error_msg = isset(\$response_body['error']['message']) ? \$response_body['error']['message'] : __('پاسخ نامعتبر از API تصویر دریافت شد.', 'gglct-ai-optimizer-pro');
            wp_send_json_error(['message' => \$error_msg, 'details' => \$response_body]); return;
        }

        \$images = [];
        \$image_urls_for_db = [];
        foreach (\$response_body['data'] as \$img_data) {
            \$images[] = [
                'url' => \$img_data['url'],
                'revised_prompt' => \$img_data['revised_prompt'] ?? \$prompt,
            ];
            \$image_urls_for_db[] = \$img_data['url'];
        }
        
        \$cost_data = \$this->calculate_request_cost('image', \$model_id, 0, 0, \$n, \$size, \$quality);
        if (get_option('gglct_aiop_enable_logging', 'yes') === 'yes') {
            \$this->save_to_history(
                \$post_id, 'image_generation', \$prompt, null, \$model_id, \$n,
                \$cost_data['usd'], \$cost_data['toman'], \$cost_data['rate'], 'image', json_encode(\$image_urls_for_db)
            );
        }
        wp_send_json_success([
            'images' => \$images,
            'cost' => \$cost_data
        ]);
    }

    public function ajax_test_connection() {
        check_ajax_referer('gglct_aiop_nonce', 'nonce');
        if (!current_user_can('manage_options')) { wp_send_json_error(['message' => __('عدم دسترسی.', 'gglct-ai-optimizer-pro')]); return; }

        \$api_key_to_test = isset(\$_POST['api_key']) ? sanitize_text_field(\$_POST['api_key']) : get_option('gglct_aiop_api_key');
        if (empty(\$api_key_to_test)) { wp_send_json_error(['message' => __('کلید API برای تست ارائه نشده است.', 'gglct-ai-optimizer-pro')]); return; }

        \$response = \$this->make_api_request([], 'models', 'GET', \$api_key_to_test);

        if (is_wp_error(\$response)) {
            wp_send_json_error(['message' => __('تست اتصال ناموفق بود:', 'gglct-ai-optimizer-pro') . ' ' . \$response->get_error_message()]);
        } else {
            \$response_body = json_decode(wp_remote_retrieve_body(\$response), true);
            if (isset(\$response_body['data'])) {
                 wp_send_json_success(['message' => __('تست اتصال موفقیت آمیز بود. تعداد مدل‌های یافت شده:', 'gglct-ai-optimizer-pro') . ' ' . count(\$response_body['data'])]);
            } else {
                wp_send_json_error(['message' => __('پاسخ API معتبر نبود اما اتصال برقرار شد.', 'gglct-ai-optimizer-pro')]);
            }
        }
    }

    public function ajax_get_history_content() {
        check_ajax_referer('gglct_aiop_nonce', 'nonce');
        if (!current_user_can('edit_posts')) { wp_send_json_error(['message' => __('عدم دسترسی.', 'gglct-ai-optimizer-pro')]); return; }

        \$history_id = isset(\$_POST['id']) ? intval(\$_POST['id']) : 0;
        if (!\$history_id) { wp_send_json_error(['message' => __('شناسه نامعتبر.', 'gglct-ai-optimizer-pro')]); return; }
        global \$wpdb;
        \$table_name = \$wpdb->prefix . 'gglct_aiop_content_history';
        \$item_query = "SELECT * FROM {\$table_name} WHERE id = %d";        \$prepared_query = \$wpdb->prepare(\$item_query, \$history_id);
        \$item = \$wpdb->get_row(\$prepared_query);

        if (!\$item) { wp_send_json_error(['message' => __('مورد تاریخچه یافت نشد.', 'gglct-ai-optimizer-pro')]); return; }
        if (!current_user_can('manage_options') && \$item->user_id != get_current_user_id()) {
             wp_send_json_error(['message' => __('شما اجازه مشاهده این مورد را ندارید.', 'gglct-ai-optimizer-pro')]); return;
        }
        
        \$item->prompt = esc_textarea(\$item->prompt);
        \$item->content = (\$item->generated_item_type === 'text' && \$item->content) ? wp_kses_post(\$item->content) : null;
        if (\$item->generated_item_type === 'image' && \$item->image_urls) {
            \$item->image_urls_decoded = json_decode(\$item->image_urls, true);
            if (json_last_error() !== JSON_ERROR_NONE) \$item->image_urls_decoded = [];
        }

        wp_send_json_success(['item' => \$item]);
    }

    public function ajax_create_new_post() {
        check_ajax_referer('gglct_aiop_nonce', 'nonce');
        if (!current_user_can('edit_posts')) { wp_send_json_error(['message' => __('عدم دسترسی.', 'gglct-ai-optimizer-pro')]); return; }

        \$content = isset(\$_POST['content']) ? wp_kses_post(\$_POST['content']) : '';
        \$post_type = isset(\$_POST['post_type']) ? sanitize_text_field(\$_POST['post_type']) : 'post';
        \$title_suggestion = isset(\$_POST['title_suggestion']) ? sanitize_text_field(\$_POST['title_suggestion']) : '';
        \$title = __('محتوای تولید شده با GGLCT AI', 'gglct-ai-optimizer-pro');
        if (!empty(\$title_suggestion)) {
            \$title = \$title_suggestion;
        } elseif (preg_match('/<h[1-6][^>]*>(.*?)<\/h[1-6]>/i', \$content, \$matches)) {
            \$title = strip_tags(\$matches[1]);
            \$title = substr(\$title, 0, 100);
        }
        if (empty(\$title)) \$title = __('بدون عنوان', 'gglct-ai-optimizer-pro');

        \$post_data = [
            'post_title' => \$title,
            'post_content' => \$content,
            'post_status' => 'draft',
            'post_type' => \$post_type,
            'post_author' => get_current_user_id(),
        ];        \$new_post_id = wp_insert_post(\$post_data, true);

        if (is_wp_error(\$new_post_id)) {
            wp_send_json_error(['message' => __('خطا در ایجاد پست جدید:', 'gglct-ai-optimizer-pro') . ' ' . \$new_post_id->get_error_message()]);
        } else {
            wp_send_json_success([
                'message' => __('پست جدید با موفقیت ایجاد شد (پیش‌نویس).', 'gglct-ai-optimizer-pro'),
                'edit_url' => admin_url('post.php?post=' . \$new_post_id . '&action=edit'),
                'post_id' => \$new_post_id
            ]);
        }
    }

    public function ajax_get_models_data() {
        check_ajax_referer('gglct_aiop_nonce', 'nonce');
        if (!\$this->check_api_key_and_permission('manage_options', true)) { wp_send_json_error(['message' => __('عدم دسترسی یا کلید API نامعتبر.', 'gglct-ai-optimizer-pro')]); return; }

        \$text_models = \$this->get_models_from_cache_or_api('text');
        \$image_models = \$this->get_models_from_cache_or_api('image');

        if (empty(\$text_models) && empty(\$image_models)) {
            wp_send_json_error(['message' => __('هیچ اطلاعات مدلی یافت نشد. لطفاً تنظیمات کلید API را بررسی کنید و حافظه پنهان را پاک کنید.', 'gglct-ai-optimizer-pro')]);
            return;
        }
        wp_send_json_success(['text_models' => array_values(\$text_models), 'image_models' => array_values(\$image_models)]);
    }

    public function ajax_update_tether_rate() {
        check_ajax_referer('gglct_aiop_nonce', 'nonce');
        if (!current_user_can('manage_options')) { wp_send_json_error(['message' => __('عدم دسترسی.', 'gglct-ai-optimizer-pro')]); return; }
        \$rate_str = isset(\$_POST['rate']) ? sanitize_text_field(\$_POST['rate']) : '0';
        \$rate = \$this->sanitize_usdt_rate_string(\$rate_str);
        update_option('gglct_aiop_usdt_manual_rate', \$rate);
        wp_send_json_success(['message' => __('نرخ تتر با موفقیت ذخیره شد.', 'gglct-ai-optimizer-pro'), 'new_rate' => floatval(\$rate)]);
    }

    public function ajax_clear_models_cache() {
        check_ajax_referer('gglct_aiop_nonce', 'nonce');
        if (!current_user_can('manage_options')) { wp_send_json_error(['message' => __('عدم دسترسی.', 'gglct-ai-optimizer-pro')]); return; }
        delete_transient(\$this->models_cache_key . '_text');
        delete_transient(\$this->models_cache_key . '_image');
        wp_send_json_success(['message' => __('کش مدل‌ها با موفقیت پاک شد.', 'gglct-ai-optimizer-pro')]);
    }
    
    public function ajax_upload_generated_image() {        check_ajax_referer('gglct_aiop_nonce', 'nonce');
        if (!current_user_can('upload_files')) {
            wp_send_json_error(['message' => __('شما اجازه آپلود فایل را ندارید.', 'gglct-ai-optimizer-pro')]);
            return;
        }

        \$image_url = isset(\$_POST['image_url']) ? esc_url_raw(\$_POST['image_url']) : '';
        \$post_id = isset(\$_POST['post_id']) ? intval(\$_POST['post_id']) : 0;
        \$set_featured = isset(\$_POST['set_featured']) && \$_POST['set_featured'] === 'true';
        \$image_title_prompt = isset(\$_POST['image_title']) ? sanitize_text_field(\$_POST['image_title']) : '';

        if (empty(\$image_url)) {
            wp_send_json_error(['message' => __('آدرس تصویر نامعتبر است.', 'gglct-ai-optimizer-pro')]);
            return;
        }

        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        \$tmp_file = download_url(\$image_url);
        if (is_wp_error(\$tmp_file)) {
            wp_send_json_error(['message' => __('خطا در دانلود تصویر:', 'gglct-ai-optimizer-pro') . ' ' . \$tmp_file->get_error_message()]);
            return;
        }

        \$file_array = [
            'name' => basename(\$image_url) . '.png',
            'tmp_name' => \$tmp_file
        ];
        
        \$file_title = !empty(\$image_title_prompt) ? sanitize_file_name(\$image_title_prompt) : (\$post_id > 0 ? sanitize_file_name(get_the_title(\$post_id)) : 'gglct-ai-generated-image');
        if (strlen(\$file_title) > 50) \$file_title = substr(\$file_title, 0, 50);

        \$attachment_id = media_handle_sideload(\$file_array, \$post_id, \$file_title);

        @unlink(\$tmp_file);

        if (is_wp_error(\$attachment_id)) {
            wp_send_json_error(['message' => __('خطا در ذخیره تصویر در کتابخانه:', 'gglct-ai-optimizer-pro') . ' ' . \$attachment_id->get_error_message()]);
            return;
        }

        \$attachment_url = wp_get_attachment_url(\$attachment_id);
        \$response_data = [
            'message' => __('تصویر با موفقیت در کتابخانه ذخیره شد.', 'gglct-ai-optimizer-pro'),
            'attachment_id' => \$attachment_id,
            'attachment_url' => \$attachment_url,
            'thumbnail_html' => wp_get_attachment_image(\$attachment_id, 'thumbnail')
        ];

        if (\$set_featured && \$post_id > 0 && post_type_supports(get_post_type(\$post_id), 'thumbnail')) {
            set_post_thumbnail(\$post_id, \$attachment_id);
            \$response_data['featured_set'] = true;
             \$response_data['message'] .= ' ' . __('و به عنوان تصویر شاخص تنظیم شد.', 'gglct-ai-optimizer-pro');
        }
        wp_send_json_success(\$response_data);
    }

    public function ajax_download_wordpress_core() {
        check_ajax_referer('gglct_aiop_wp_tools_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('عدم دسترسی مجاز.', 'gglct-ai-optimizer-pro')]);
            return;
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';        \$latest_wp_zip_url = 'https://wordpress.org/latest.zip';
        \$downloaded_file_path = download_url(\$latest_wp_zip_url, 300);

        if (is_wp_error(\$downloaded_file_path)) {
            wp_send_json_error(['message' => __('خطا در دانلود وردپرس:', 'gglct-ai-optimizer-pro') . ' ' . \$downloaded_file_path->get_error_message()]);
            return;
        }
        
        WP_Filesystem();
        global \$wp_filesystem;
                \$upload_dir_info = wp_upload_dir();
        \$destination_file_path = \$upload_dir_info['basedir'] . '/wordpress_latest_gglct.zip';

        \$move_result = \$wp_filesystem->move(\$downloaded_file_path, \$destination_file_path, true);
        
        if (file_exists(\$downloaded_file_path)) {             @unlink(\$downloaded_file_path);
        }

        if (!\$move_result) {
            wp_send_json_error(['message' => __('خطا در انتقال فایل وردپرس به پوشه آپلود.', 'gglct-ai-optimizer-pro') . ' Source: ' . \$downloaded_file_path . ' Dest: ' . \$destination_file_path]);
            return;
        }        \$destination_url = \$upload_dir_info['baseurl'] . '/wordpress_latest_gglct.zip';
        wp_send_json_success([
            'message' => __('فایل فشرده آخرین نسخه وردپرس با موفقیت دانلود و در مسیر زیر ذخیره شد:', 'gglct-ai-optimizer-pro'),
            'file_path_display' => str_replace(ABSPATH, '', \$destination_file_path),
            'file_url' => \$destination_url
        ]);
    }

    private function make_api_request(\$data, \$endpoint_path, \$method = 'POST', \$custom_api_key = null) {
        \$api_key = \$custom_api_key ?? get_option('gglct_aiop_api_key');
        if (empty(\$api_key)) {
            return new WP_Error('api_key_missing', __('کلید API تنظیم نشده است.', 'gglct-ai-optimizer-pro'));
        }

        \$url = trailingslashit(GGLCT_AIOP_API_BASE_URL) . \$endpoint_path;
        \$headers = [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . \$api_key,
            'User-Agent' => 'GGLCT WordPress Plugin/' . GGLCT_AIOP_PLUGIN_VERSION,
        ];
        \$args = [
            'method' => strtoupper(\$method),
            'timeout' => 120,
            'headers' => \$headers,
        ];

        if ('POST' === strtoupper(\$method) && !empty(\$data)) {
            \$args['body'] = wp_json_encode(\$data);
        } elseif ('GET' === strtoupper(\$method) && !empty(\$data)) {
            \$url = add_query_arg(\$data, \$url);
        }
        
        \$response = wp_remote_request(\$url, \$args);

        if (is_wp_error(\$response)) {
            return \$response;
        }

        \$response_code = wp_remote_retrieve_response_code(\$response);
        \$response_body = wp_remote_retrieve_body(\$response);
        \$decoded_body = json_decode(\$response_body, true);

        if (\$response_code >= 400) {
            \$error_message = isset(\$decoded_body['error']['message']) ? \$decoded_body['error']['message'] : \$response_body;
            if (empty(\$error_message) && isset(\$decoded_body['detail'])) {
                 \$error_message = is_array(\$decoded_body['detail']) ? wp_json_encode(\$decoded_body['detail']) : \$decoded_body['detail'];
            }
            return new WP_Error(
                'api_error_' . \$response_code,
                sprintf(__('خطا از API (%s): %s', 'gglct-ai-optimizer-pro'), \$response_code, esc_html(\$error_message))
            );
        }
        return \$response;
    }

    private function save_to_history(\$post_id, \$post_type, \$prompt, \$content, \$model, \$tokens, \$cost_usd = 0, \$cost_toman = 0, \$usdt_rate = 0, \$item_type = 'text', \$image_urls_json = null) {
        global \$wpdb;
        \$table_name = \$wpdb->prefix . 'gglct_aiop_content_history';
        \$data = [
            'user_id' => get_current_user_id(),
            'post_id' => intval(\$post_id),
            'post_type' => sanitize_text_field(\$post_type),
            'prompt' => \$prompt,
            'model' => sanitize_text_field(\$model),
            'tokens' => intval(\$tokens),
            'cost_usd' => floatval(\$cost_usd),
            'cost_toman' => floatval(\$cost_toman),
            'usdt_rate' => floatval(\$usdt_rate),
            'generated_item_type' => (\$item_type === 'image') ? 'image' : 'text',
            'created_at' => current_time('mysql', 1),
        ];
        if (\$item_type === 'text') {
            \$data['content'] = \$content;
            \$formats = ['%d', '%d', '%s', '%s', '%s', '%d', '%f', '%f', '%f', '%s'];
        } else {
            \$data['image_urls'] = \$image_urls_json;
            \$formats = ['%d', '%d', '%s', '%s', '%s', '%s', '%d', '%f', '%f', '%f', '%s', '%s'];
        }
        
        \$wpdb->insert(\$table_name, \$data, \$formats);
        return \$wpdb->insert_id;
    }

    private function get_history_items(\$args = []) {
        global \$wpdb;
        \$table_name = \$wpdb->prefix . 'gglct_aiop_content_history';
        \$current_page = isset(\$args['paged']) ? max(1, intval(\$args['paged'])) : 1;
        \$per_page = 20;
        \$offset = (\$current_page - 1) * \$per_page;

        \$where_clauses = [];
        \$where_params = [];

        if (!current_user_can('manage_options')) {
            \$where_clauses[] = "user_id = %d";
            \$where_params[] = get_current_user_id();
        }

        if (!empty(\$args['post_type_filter'])) {
            \$where_clauses[] = "post_type = %s";
            \$where_params[] = sanitize_text_field(\$args['post_type_filter']);
        }
        if (!empty(\$args['item_type_filter'])) {
            \$where_clauses[] = "generated_item_type = %s";
            \$where_params[] = sanitize_text_field(\$args['item_type_filter']);
        }
        if (!empty(\$args['search_filter'])) {
            \$search_term = '%' . \$wpdb->esc_like(sanitize_text_field(\$args['search_filter'])) . '%';
            \$where_clauses[] = "(prompt LIKE %s OR content LIKE %s OR image_urls LIKE %s)";
            \$where_params[] = \$search_term;
            \$where_params[] = \$search_term;
            \$where_params[] = \$search_term;
        }

        \$where_sql = !empty(\$where_clauses) ? " WHERE " . implode(" AND ", \$where_clauses) : "";
        
        \$total_items_sql = "SELECT COUNT(*) FROM {\$table_name} \$where_sql";
        \$total_items = \$wpdb->get_var( empty(\$where_params) ? \$total_items_sql : \$wpdb->prepare(\$total_items_sql, \$where_params) );
        
        \$history_items_sql = "SELECT * FROM {\$table_name} \$where_sql ORDER BY created_at DESC LIMIT %d OFFSET %d";
        \$query_params = array_merge(\$where_params, [\$per_page, \$offset]);
        \$history_items = \$wpdb->get_results( \$wpdb->prepare(\$history_items_sql, \$query_params) );

        return [
            'history_items' => \$history_items,
            'total_pages' => ceil(\$total_items / \$per_page),
            'current_page' => \$current_page,
            'total_items' => \$total_items,
            'all_post_types_objects' => get_post_types(['public' => true], 'objects'),        ];
    }
    
    private function get_system_message_for_prompt(\$prompt) {
        \$default_system_message = __("شما یک دستیار هوش مصنوعی هستید که به زبان فارسی محتوای با کیفیت، دقیق و بهینه شده برای موتورهای جستجو تولید می‌کنید. پاسخ‌های شما باید دارای ساختار مناسب HTML با استفاده از تگ‌های h2, h3, p, ul, ol, li, strong, em باشد. از تگ h1 استفاده نکنید. پاسخ باید کاملا به زبان فارسی باشد مگر اینکه در پرامپت به صراحت زبان دیگری خواسته شده باشد.", 'gglct-ai-optimizer-pro');
        return \$default_system_message;
    }

    private function calculate_request_cost(\$type, \$model_id, \$input_tokens = 0, \$output_tokens = 0, \$num_images = 0, \$image_size = '', \$image_quality = '') {
        \$cost_usd = 0.0;
        \$usdt_rate_str = get_option('gglct_aiop_usdt_manual_rate', '0');
        \$usdt_rate = floatval(str_replace(',', '.', \$usdt_rate_str));        if (get_option('gglct_aiop_cost_calculation_enabled', 'yes') !== 'yes') {
            return ['usd' => 0, 'toman' => 0, 'rate' => \$usdt_rate];
        }
        \$all_models = \$this->get_models_from_cache_or_api(\$type);
        \$model_pricing_data = null;
        foreach (\$all_models as \$m) {
            if (\$m['id'] === \$model_id) {
                \$model_pricing_data = \$m['pricing'] ?? null;
                break;
            }
        }
        if (\$model_pricing_data) {
            if (\$type === 'text') {
                \$input_price_pm = floatval(\$model_pricing_data['input'] ?? (\$model_pricing_data['cached_input'] ?? 0));
                \$output_price_pm = floatval(\$model_pricing_data['output'] ?? 0);
                \$cost_usd = ((\$input_tokens / 1000000) * \$input_price_pm) + ((\$output_tokens / 1000000) * \$output_price_pm);
            } elseif (\$type === 'image' && \$num_images > 0) {
                if (\$model_id === 'dall-e-3') {
                    \$price_per_image = floatval(\$model_pricing_data[\$image_quality] ?? (\$model_pricing_data['standard'] ?? 0.04));
                    \$cost_usd = \$price_per_image * \$num_images;
                } elseif (\$model_id === 'dall-e-2') {
                    \$price_key = 'standard_' . \$image_size;
                    \$price_per_image = floatval(\$model_pricing_data[\$price_key] ?? (\$model_pricing_data['standard_1024x1024'] ?? 0.02));
                    \$cost_usd = \$price_per_image * \$num_images;
                }
            }
        }

        \$cost_toman = (\$usdt_rate > 0) ? (\$cost_usd * \$usdt_rate) : 0;
        return ['usd' => round(\$cost_usd, 6), 'toman' => round(\$cost_toman, 2), 'rate' => \$usdt_rate];
    }

    public function enqueue_admin_assets(\$hook) {
        \$current_screen = get_current_screen();
        \$is_plugin_page = \$current_screen && strpos(\$current_screen->id, GGLCT_AIOP_PLUGIN_SLUG) !== false;
        \$is_post_edit_page = in_array(\$hook, ['post.php', 'post-new.php']);

        if (!\$is_plugin_page && !\$is_post_edit_page) {
            return;
        }

        wp_enqueue_style('gglct-ai-optimizer-pro-animate', 'https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css', array(), '4.1.1');        wp_enqueue_style('gglct-ai-optimizer-pro-admin', GGLCT_AIOP_PLUGIN_URL . 'gglct-ai-optimizer-pro.css', array(), self::VERSION);
        
        wp_enqueue_script('jquery-ui-tabs');
        wp_enqueue_script('jquery-ui-slider');
        wp_enqueue_script('jquery-ui-tooltip');
        wp_enqueue_script('jquery-ui-sortable');
        wp_enqueue_media();

        wp_enqueue_script(
            'gglct-ai-optimizer-pro-admin-script',
            GGLCT_AIOP_PLUGIN_URL . 'gglct-ai-optimizer-pro.js',
            array('jquery', 'wp-i18n', 'wp-api-fetch', 'wp-components', 'wp-element', 'jquery-ui-tabs', 'jquery-ui-slider', 'jquery-ui-tooltip', 'jquery-ui-sortable'),
            self::VERSION,
            true
        );

        wp_set_script_translations('gglct-ai-optimizer-pro-admin-script', 'gglct-ai-optimizer-pro', GGLCT_AIOP_PLUGIN_DIR . 'languages');
        wp_localize_script('gglct-ai-optimizer-pro-admin-script', 'gglctAioParams', \$this->get_common_script_params());
        wp_enqueue_style('wp-components');
    }

    private function get_common_script_params() {        global \$post;
        \$current_post_id = isset(\$post->ID) ? \$post->ID : (isset(\$_GET['post']) ? intval(\$_GET['post']) : 0);
        \$current_post_type = isset(\$post->post_type) ? \$post->post_type : (isset(\$_GET['post_type']) ? sanitize_text_field(\$_GET['post_type']) : 'post');
        if (!\$current_post_type && \$current_post_id) { \$current_post_type = get_post_type(\$current_post_id); }

        \$page_data = \$this->get_page_common_data(true, true);

        return [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('gglct_aiop_nonce'),
            'wpToolsNonce' => wp_create_nonce('gglct_aiop_wp_tools_nonce'),
            'strings' => \$this->get_js_strings(),
            'postId' => \$current_post_id,
            'postType' => \$current_post_type,            'pluginUrl' => GGLCT_AIOP_PLUGIN_URL,
            'isRTL' => is_rtl(),
            'defaultTextModel' => \$page_data['default_text_model'],
            'defaultImageModel' => \$page_data['default_image_model'],
            'usdtManualRate' => floatval(str_replace(',', '.', get_option('gglct_aiop_usdt_manual_rate', '0'))),
            'usdtAutoFetch' => get_option('gglct_aiop_usdt_auto_fetch', 'yes') === 'yes',
            'costCalculationEnabled' => get_option('gglct_aiop_cost_calculation_enabled', 'yes') === 'yes',
            'availableTextModels' => \$page_data['available_text_models'],
            'availableImageModels' => \$page_data['available_image_models'],
            'allTextModelsData' => \$page_data['all_text_models_data'],
            'allImageModelsData' => \$page_data['all_image_models_data'],
            'imageModelDetails' => \$page_data['image_model_details'],
            'defaultMaxTokens' => intval(get_option('gglct_aiop_default_max_tokens', 2000)),
            'defaultTemperature' => floatval(get_option('gglct_aiop_default_temperature', 0.7)),
            'defaultImageSize' => get_option('gglct_aiop_default_image_size', '1024x1024'),
            'defaultImageQuality' => get_option('gglct_aiop_default_image_quality', 'standard'),
            'defaultImageStyle' => get_option('gglct_aiop_default_image_style', 'vivid'),
        ];    }

    private function get_js_strings() {
        return [
            'generating' => __('در حال تولید...', 'gglct-ai-optimizer-pro'),
            'generatingContent' => __('در حال تولید محتوا...', 'gglct-ai-optimizer-pro'),
            'generatingImage' => __('در حال تولید تصویر...', 'gglct-ai-optimizer-pro'),
            'insertSuccess' => __('محتوا با موفقیت درج شد.', 'gglct-ai-optimizer-pro'),
            'error' => __('خطا در انجام عملیات.', 'gglct-ai-optimizer-pro'),
            'apiError' => __('خطا در ارتباط با API.', 'gglct-ai-optimizer-pro'),
            'confirmDelete' => __('آیا از حذف این مورد اطمینان دارید؟', 'gglct-ai-optimizer-pro'),
            'loadingContent' => __('در حال بارگذاری محتوا...', 'gglct-ai-optimizer-pro'),
            'contentCopied' => __('محتوا با موفقیت کپی شد.', 'gglct-ai-optimizer-pro'),
            'imageCopied' => __('آدرس تصویر کپی شد.', 'gglct-ai-optimizer-pro'),
            'errorFetchingContent' => __('خطا در دریافت محتوا.', 'gglct-ai-optimizer-pro'),
            'errorServerConnection' => __('خطا در ارتباط با سرور.', 'gglct-ai-optimizer-pro'),
            'promptRequired' => __('لطفا یک پرامپت وارد کنید.', 'gglct-ai-optimizer-pro'),
            'apiKeyRequired' => __('لطفا کلید API را وارد کنید.', 'gglct-ai-optimizer-pro'),
            'connectionTestSuccess' => __('ارتباط با API با موفقیت برقرار شد.', 'gglct-ai-optimizer-pro'),
            'connectionTestError' => __('خطا در ارتباط با API.', 'gglct-ai-optimizer-pro'),
            'fetchModelsError' => __('خطا در دریافت اطلاعات مدل‌ها.', 'gglct-ai-optimizer-pro'),
            'tetherRateError' => __('خطا در دریافت نرخ تتر.', 'gglct-ai-optimizer-pro'),
            'tetherRateSource' => __('منبع: تترلند', 'gglct-ai-optimizer-pro'),
            'tetherManualRate' => __('نرخ دستی', 'gglct-ai-optimizer-pro'),
            'tetherRateSavedSuccess' => __('نرخ تتر با موفقیت ذخیره شد.', 'gglct-ai-optimizer-pro'),
            'unknownError' => __('خطای نامشخص.', 'gglct-ai-optimizer-pro'),
            'contentGeneratedSuccess' => __('محتوا با موفقیت تولید شد.', 'gglct-ai-optimizer-pro'),
            'imageGeneratedSuccess' => __('تصویر (ها) با موفقیت تولید شد.', 'gglct-ai-optimizer-pro'),
            'token' => __('توکن', 'gglct-ai-optimizer-pro'),
            'tokens' => __('توکن‌ها', 'gglct-ai-optimizer-pro'),
            'generatedContentTitle' => __('محتوای تولید شده', 'gglct-ai-optimizer-pro'),
            'tokenCount' => __('تعداد توکن', 'gglct-ai-optimizer-pro'),
            'toggleApiKeyVisibility' => __('نمایش/مخفی کردن کلید API', 'gglct-ai-optimizer-pro'),
            'testingConnection' => __('در حال تست اتصال...', 'gglct-ai-optimizer-pro'),
            'tomanUnit' => __('تومان', 'gglct-ai-optimizer-pro'),
            'usdUnit' => __('دلار', 'gglct-ai-optimizer-pro'),
            'priceNotAvailable' => __('نامشخص', 'gglct-ai-optimizer-pro'),
            'clearCache' => __('پاکسازی کش مدل‌ها', 'gglct-ai-optimizer-pro'),
            'cacheCleared' => __('کش مدل‌ها با موفقیت پاک شد.', 'gglct-ai-optimizer-pro'),
            'errorClearingCache' => __('خطا در پاکسازی کش مدل‌ها.', 'gglct-ai-optimizer-pro'),
            'inputTokensEstimate' => __('توکن ورودی (تخمینی):', 'gglct-ai-optimizer-pro'),
            'estimatedCostUSD' => __('هزینه تخمینی (دلار):', 'gglct-ai-optimizer-pro'),
            'estimatedCostToman' => __('هزینه تخمینی (تومان):', 'gglct-ai-optimizer-pro'),
            'finalCostUSD' => __('هزینه نهایی (دلار):', 'gglct-ai-optimizer-pro'),
            'finalCostToman' => __('هزینه نهایی (تومان):', 'gglct-ai-optimizer-pro'),
            'imageSize' => __('اندازه تصویر', 'gglct-ai-optimizer-pro'),
            'imageQuality' => __('کیفیت تصویر', 'gglct-ai-optimizer-pro'),
            'imageStyle' => __('سبک تصویر (DALL-E 3)', 'gglct-ai-optimizer-pro'),
            'numImages' => __('تعداد تصاویر', 'gglct-ai-optimizer-pro'),
            'uploadingImage' => __('در حال آپلود تصویر...', 'gglct-ai-optimizer-pro'),
            'imageUploaded' => __('تصویر با موفقیت آپلود شد.', 'gglct-ai-optimizer-pro'),
            'imageSetAsFeatured' => __('تصویر به عنوان شاخص تنظیم شد.', 'gglct-ai-optimizer-pro'),
            'errorUploadingImage' => __('خطا در آپلود تصویر.', 'gglct-ai-optimizer-pro'),
            'downloadingWordPress' => __('در حال دانلود آخرین نسخه وردپرس...', 'gglct-ai-optimizer-pro'),
            'downloadWordPressSuccess' => __('وردپرس با موفقیت دانلود شد.', 'gglct-ai-optimizer-pro'),
            'downloadWordPressError' => __('خطا در دانلود وردپرس.', 'gglct-ai-optimizer-pro'),
            'copyUrl' => __('کپی URL', 'gglct-ai-optimizer-pro'),
            'uploadToMedia' => __('آپلود به رسانه', 'gglct-ai-optimizer-pro'),
            'setFeaturedImage' => __('تنظیم به عنوان تصویر شاخص', 'gglct-ai-optimizer-pro'),
            'promptTextPlaceholder' => __('متن پرامپت (مثال: [TOPIC], [TITLE])', 'gglct-ai-optimizer-pro'),
            'promptImagePlaceholder' => __('متن پرامپت (مثال: [TOPIC], [STYLE])', 'gglct-ai-optimizer-pro'),
            'templateName' => __('نام قالب', 'gglct-ai-optimizer-pro'),
            'delete' => __('حذف', 'gglct-ai-optimizer-pro'),
            'price' => __('قیمت', 'gglct-ai-optimizer-pro'),
            'type' => __('نوع', 'gglct-ai-optimizer-pro'),
            'capabilities' => __('قابلیت‌ها', 'gglct-ai-optimizer-pro'),
            'inputTokens' => __('توکن ورودی', 'gglct-ai-optimizer-pro'),
            'outputTokens' => __('توکن خروجی', 'gglct-ai-optimizer-pro'),
            'standardQuality' => __('کیفیت استاندارد', 'gglct-ai-optimizer-pro'),
            'hdQuality' => __('کیفیت HD', 'gglct-ai-optimizer-pro'),
            'maxTokens' => __('حداکثر توکن', 'gglct-ai-optimizer-pro'),
            'supportedSizes' => __('اندازه‌های پشتیبانی شده', 'gglct-ai-optimizer-pro'),
            'supportedQualities' => __('کیفیت‌های پشتیبانی شده', 'gglct-ai-optimizer-pro'),
            'supportedStyles' => __('سبک‌های پشتیبانی شده', 'gglct-ai-optimizer-pro'),
            'maxImagesPerRequest' => __('حداکثر تصویر در هر درخواست', 'gglct-ai-optimizer-pro'),
            'generatedImages' => __('تصاویر تولید شده', 'gglct-ai-optimizer-pro'),
            'loadingModels' => __('در حال بارگذاری اطلاعات مدل‌ها...', 'gglct-ai-optimizer-pro'),
            'creatingPost' => __('در حال ایجاد پست جدید...', 'gglct-ai-optimizer-pro'),
            'saving' => __('در حال ذخیره...', 'gglct-ai-optimizer-pro'),
            'close' => __('بستن', 'gglct-ai-optimizer-pro'),
        ];
    }
    
    public function get_obfuscated_ad_code_html() {
        \$ad_data_json = base64_decode(GGLCT_AIOP_AD_CODE_OBFUSCATED);
        \$ad_data = json_decode(\$ad_data_json, true);
        if (\$ad_data && isset(\$ad_data['type']) && \$ad_data['type'] === 'banner' && isset(\$ad_data['src']) && isset(\$ad_data['link'])) {
            return '<div class="gglct-aio-ad-placeholder" style="text-align:center; margin: 20px 0; padding:10px; border:1px dashed #ccc; background:#f9f9f9;">
                        <a href="' . esc_url(\$ad_data['link']) . '" target="_blank" rel="nofollow sponsored">
                            <img src="' . esc_url(\$ad_data['src']) . '" alt="' . esc_attr(\$ad_data['alt'] ?? 'Advertisement') . '" style="max-width:100%; height:auto; border:0;">
                        </a>
                        <p style="font-size:0.8em; color:#777; margin-top:5px;">' . __('تبلیغات توسط GGLCT.com', 'gglct-ai-optimizer-pro') . '</p>
                    </div>';
        }
        return '';
    }

    public static function uninstall() {
        global \$wpdb;
        \$table_name = \$wpdb->prefix . 'gglct_aiop_content_history';
        \$wpdb->query("DROP TABLE IF EXISTS {\$table_name}");
        \$options_to_delete = [
            'api_key', 'default_text_model', 'default_max_tokens', 'default_temperature',
            'default_image_model', 'default_image_size', 'default_image_quality', 'default_image_style',
            'enable_logging', 'enabled_post_types', 'text_prompt_templates', 'image_prompt_templates',
            'usdt_manual_rate', 'usdt_auto_fetch', 'cost_calculation_enabled',
        ];
        foreach(\$options_to_delete as \$opt) {
            delete_option('gglct_aiop_' . \$opt);
        }
        delete_transient('gglct_aiop_models_data_cache_text');
        delete_transient('gglct_aiop_models_data_cache_image');
        flush_rewrite_rules();
    }
}

function gglct_aiop_load_plugin() {
    return GGLCT_AI_Optimizer_Pro::get_instance();
}
add_action('plugins_loaded', 'gglct_aiop_load_plugin', 5);

register_uninstall_hook(GGLCT_AIOP_PLUGIN_FILE, array('GGLCT_AI_Optimizer_Pro', 'uninstall'));

?>
<style>
/* GGLCT AI Optimizer Pro Admin Styles - Full Graphical & Responsive */
.gglct-aio-wrap {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    margin-top: 20px;
    direction: rtl;
    text-align: right;
}
.gglct-aio-wrap h1 {
    font-size: 2.2em;
    font-weight: 600;
    color: #333;
    margin-bottom: 25px;
    border-bottom: 1px solid #eee;    padding-bottom: 15px;
}
.gglct-aio-card {
    background: #fff;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    margin-bottom: 20px;
    overflow: hidden;}
.gglct-aio-card-header {
    background: linear-gradient(135deg, #f0f2f5 0%, #e6e9ed 100%);    padding: 15px 20px;
    border-bottom: 1px solid #e0e0e0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 1.1em;
    font-weight: 500;
    color: #333;
}
.gglct-aio-card-header h2 {
    margin: 0;
    font-size: 1.4em;
    font-weight: 600;
    color: #0073aa;}
.gglct-aio-card-body {
    padding: 20px;
}
.gglct-aio-form-group {
    margin-bottom: 20px;}
.gglct-aio-form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #555;
    font-size: 1.05em;
}
.gglct-aio-form-group input[type="text"],
.gglct-aio-form-group input[type="number"],
.gglct-aio-form-group input[type="password"],
.gglct-aio-form-group select,
.gglct-aio-form-group textarea {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-sizing: border-box;
    font-size: 1em;
    transition: all 0.3s ease;
}
.gglct-aio-form-group input[type="text"]:focus,
.gglct-aio-form-group input[type="number"]:focus,
.gglct-aio-form-group input[type="password"]:focus,
.gglct-aio-form-group select:focus,
.gglct-aio-form-group textarea:focus {
    border-color: #0073aa;
    box-shadow: 0 0 0 2px rgba(0, 115, 170, 0.2);
    outline: none;
}
.gglct-aio-form-row {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    margin-bottom: 20px;
}
.gglct-aio-form-row .gglct-aio-form-group {    flex: 1;
    min-width: 250px;
    margin-bottom: 0;
}
.gglct-aio-form-actions {
    padding-top: 15px;
    border-top: 1px solid #eee;
    text-align: left;
}
.button-primary {
    background: #0073aa;
    border-color: #0073aa;
    color: #fff;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
    padding: 8px 16px;
    height: auto;
    line-height: 1.5;
    font-size: 1em;
}.button-primary:hover, .button-primary:focus {
    background: #005177;
    border-color: #005177;
    color: #fff;}
.button-secondary {
    background: #f3f4f6;
    border-color: #c9d2da;
    color: #555;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    transition: all 0.3s ease;
    padding: 8px 16px;
    height: auto;
    line-height: 1.5;
    font-size: 1em;
}
.button-secondary:hover, .button-secondary:focus {
    background: #e0e2e6;
    border-color: #b0b8c2;
    color: #333;
}
.gglct-aio-loading {
    text-align: center;    padding: 30px;
    font-size: 1.2em;
    color: #0073aa;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    font-weight: 500;
}
.gglct-aio-loading::before {
    content: '';
    border: 4px solid #f3f3f3;
    border-top: 4px solid #0073aa;
    border-radius: 50%;
    width: 25px;
    height: 25px;
    animation: spin 1s linear infinite;
}
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
.gglct-aio-result-content {
    background: #fdfdfd;
    border: 1px dashed #c3c4c7;
    padding: 15px;
    border-radius: 5px;
    min-height: 150px;
    white-space: pre-wrap;
    word-wrap: break-word;
    color: #333;
    line-height: 1.6;
    font-size: 1.05em;
    max-height: 500px;
    overflow-y: auto;
}
.gglct-aio-result-content p {
    margin-bottom: 1em;
}
.gglct-aio-result-content h2, .gglct-aio-result-content h3 {
    margin-top: 1.5em;
    margin-bottom: 0.8em;
    color: #005177;
}
.gglct-aio-result-content ul, .gglct-aio-result-content ol {
    margin-bottom: 1em;
    padding-right: 20px;
    list-style: disc;
}
.gglct-aio-card-actions {
    display: flex;
    align-items: center;
    gap: 10px;
}
.gglct-aio-token-count, .gglct-aio-cost-display {
    font-weight: 600;
    color: #0073aa;
    font-size: 0.9em;
}
.gglct-aio-image-results-container {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 15px;
    margin-top: 20px;
}
.gglct-aio-image-item {
    border: 1px solid #ddd;
    border-radius: 8px;
    overflow: hidden;
    background: #f9f9f9;
    padding: 10px;
    text-align: center;
    box-shadow: 0 2px 6px rgba(0,0,0,0.05);
    transition: all 0.3s ease;
    cursor: pointer;
}
.gglct-aio-image-item:hover {
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    transform: translateY(-2px);
}
.gglct-aio-image-item img {
    max-width: 100%;
    height: auto;
    border-radius: 5px;
    display: block;
    margin: 0 auto 10px auto;
}
.gglct-aio-image-item-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
    justify-content: center;
}
.gglct-aio-image-item-actions .button {
    flex-grow: 1;
    min-width: 80px;
    padding: 5px 8px;
    font-size: 0.85em;
}
.gglct-aio-api-notice {
    margin-top: 20px;
    border-right-color: #dc3232 !important;
}
.gglct-aio-api-notice p {
    font-size: 1.1em;
    line-height: 1.6;
}
.gglct-aio-api-notice a {
    text-decoration: underline;
    color: #0073aa;
}.gglct-aio-api-notice a:hover {
    color: #005177;
}

/* Tabs */
.ui-tabs .ui-tabs-nav {
    margin: 0;
    padding: 0;
    background: #f8f8f8;
    border-bottom: 1px solid #e0e0e0;
    border-radius: 8px 8px 0 0;
}
.ui-tabs .ui-tabs-nav li {
    list-style: none;
    float: right;
    position: relative;
    top: 1px;
    margin: 0 -1px 0 0;
    border-bottom: 0;
    padding: 0;
    white-space: nowrap;
    border-radius: 0;
}
.ui-tabs .ui-tabs-nav li a {
    float: right;
    padding: 12px 20px;
    text-decoration: none;
    color: #555;
    font-weight: 500;
    transition: all 0.3s ease;
}
.ui-tabs .ui-tabs-nav li.ui-tabs-active {
    border-bottom: 1px solid #fff;
    background: #fff;
}
.ui-tabs .ui-tabs-nav li.ui-tabs-active a {
    color: #0073aa;
    font-weight: 600;
}
.ui-tabs .ui-tabs-panel {
    padding: 20px;
    border: 1px solid #e0e0e0;
    border-top: none;
    background: #fff;
    border-radius: 0 0 8px 8px;
    min-height: 300px;
}
.ui-tabs .ui-tabs-nav li:first-child {
    border-top-right-radius: 8px;
}
.ui-tabs .ui-tabs-nav li:last-child {
    border-top-left-radius: 8px;
}

/* Settings Page Specific */
.gglct-aio-settings .form-table th {
    width: 200px;
    padding-top: 15px;
    padding-bottom: 15px;
}
.gglct-aio-settings .form-table td {
    padding-top: 15px;
    padding-bottom: 15px;
}
.gglct-aio-settings .description {
    font-size: 0.9em;
    color: #777;
    margin-top: 5px;
}
.gglct-aio-prompt-template-item {
    border: 1px solid #e0e0e0;
    padding: 15px;
    margin-bottom: 15px;
    border-radius: 5px;
    background: #fcfcfc;
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    align-items: flex-end;
}
.gglct-aio-prompt-template-item input[type="text"] {
    flex: 1;
    min-width: 150px;
}
.gglct-aio-prompt-template-item textarea {
    flex: 2;
    min-width: 250px;
}
.gglct-aio-prompt-template-item .button {
    flex-shrink: 0;
}

/* Dashboard styles */
.gglct-aio-model-dashboard .gglct-aio-dashboard-controls {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    align-items: center;
    margin-bottom: 20px;
    padding: 15px;
    background: #f8f8f8;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
}
.gglct-aio-model-dashboard .gglct-aio-dashboard-input {
    display: flex;
    gap: 10px;
    align-items: center;
}
.gglct-aio-model-dashboard .gglct-aio-tether-info {
    font-weight: 600;
    color: #0073aa;
}
.gglct-aio-models-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 20px;
}
.gglct-aio-model-card {
    background: #fff;
    border: 1px solid #e0e0e0;    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    transition: all 0.3s ease;
    cursor: pointer;
    text-align: center;
}
.gglct-aio-model-card:hover {
    box-shadow: 0 6px 16px rgba(0,0,0,0.1);
    transform: translateY(-3px);
}
.gglct-aio-model-card h3 {
    margin-top: 0;
    font-size: 1.3em;
    color: #0073aa;
    margin-bottom: 10px;
}
.gglct-aio-model-card p {
    font-size: 0.9em;
    color: #666;
    margin-bottom: 5px;
}
.gglct-aio-modal {
    display: none;
    position: fixed;
    z-index: 100000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0,0,0,0.7);
    justify-content: center;
    align-items: center;
}
.gglct-aio-modal.show {
    display: flex;
}
.gglct-aio-modal-content {
    background-color: #fefefe;
    margin: auto;
    padding: 25px;
    border: 1px solid #888;
    width: 90%;
    max-width: 700px;
    border-radius: 8px;
    box-shadow: 0 5px 15px rgba(0,0,0,.5);
    position: relative;
    animation: fadeIn 0.3s ease-out;
}
.gglct-aio-modal-close {
    position: absolute;
    top: 10px;
    left: 15px;
    color: #aaa;
    font-size: 30px;
    font-weight: bold;
    cursor: pointer;
    transition: color 0.2s ease;
}
.gglct-aio-modal-close:hover {
    color: #333;
}
.gglct-aio-modal-header {
    border-bottom: 1px solid #eee;
    padding-bottom: 15px;
    margin-bottom: 20px;
    text-align: center;
}
.gglct-aio-modal-header h3 {
    margin: 0;
    font-size: 1.6em;
    color: #0073aa;
}
.gglct-aio-modal-body {
    max-height: 60vh;
    overflow-y: auto;
}
.gglct-aio-modal-body h4 {
    color: #333;
    margin-top: 20px;
    margin-bottom: 10px;
    border-bottom: 1px solid #eee;
    padding-bottom: 5px;
}
.gglct-aio-modal-body ul {    margin-left: 0;
    padding-right: 20px;
    list-style: disc;
}
.gglct-aio-modal-body ul li {
    margin-bottom: 5px;
    color: #555;
}

@keyframes fadeIn {
    from { opacity: 0; transform: scale(0.95); }
    to { opacity: 1; transform: scale(1); }
}

/* Notifications */
.gglct-aio-notification {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 99999;
    padding: 12px 20px;
    border-radius: 5px;
    color: #fff;
    font-weight: 500;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    animation: slideInRight 0.5s forwards, fadeOut 0.5s forwards 3s;
    display: flex;
    align-items: center;
    gap: 10px;
}
.gglct-aio-notification.success { background-color: #4CAF50; }
.gglct-aio-notification.error { background-color: #f44336; }
.gglct-aio-notification.info { background-color: #2196F3; }

@keyframes slideInRight {
    from { right: -300px; opacity: 0; }
    to { right: 20px; opacity: 1; }
}
@keyframes fadeOut {
    from { opacity: 1; }
    to { opacity: 0; }
}

/* Responsive adjustments */
@media (max-width: 782px) {
    .gglct-aio-wrap {
        margin-right: 0;
        margin-left: 0;
        padding: 10px;    }
    .gglct-aio-form-row {
        flex-direction: column;
        gap: 0;
    }
    .gglct-aio-form-row .gglct-aio-form-group {
        min-width: unset;
        width: 100%;
    }
    .ui-tabs .ui-tabs-nav li {
        float: none;
        width: 100%;
        margin-bottom: 5px;
        border-radius: 5px;
    }
    .ui-tabs .ui-tabs-nav li a {        text-align: center;
        float: none;
        display: block;
    }
    .ui-tabs .ui-tabs-nav li.ui-tabs-active {
        border-bottom: 1px solid #0073aa;
    }
    .gglct-aio-model-dashboard .gglct-aio-dashboard-controls {
        flex-direction: column;
        align-items: stretch;
    }
    .gglct-aio-model-dashboard .gglct-aio-dashboard-input {
        flex-direction: column;
        align-items: stretch;    }
    .gglct-aio-model-dashboard .gglct-aio-dashboard-input input,
    .gglct-aio-model-dashboard .gglct-aio-dashboard-input button {
        width: 100%;
        box-sizing: border-box;
    }
}
</style>
<script>
/* GGLCT AI Optimizer Pro Admin Scripts */
(function($, params) {
    "use strict";

    const GGLCT_AIOP_APP = {
        config: params,
        elements: {},
        state: {
            isGenerating: false,            tetherRate: 0,
            currentEstimatedInputTokens: 0,
            activeTab: 'main',
            imageCurrentModelDetails: null
        },

        init: function() {
            this.cacheElements();
            this.bindEvents();
            this.initTabs();
            this.initCostEstimator();
            this.initModelDashboard();
            this.initImageGenerator();
            this.initHistoryPage();
        },

        cacheElements: function() {
            this.elements.$document = $(document);
            this.elements.$window = $(window);

            // General UI
            this.elements.$loadingOverlay = $('<div class="gglct-aio-loading-overlay" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(255,255,255,0.8); z-index:99990; display:flex; align-items:center; justify-content:center;"><div class="gglct-aio-loading"><span class="gglct-aio-loading-text"></span></div></div>').appendTo('body');
            this.elements.$loadingText = this.elements.$loadingOverlay.find('.gglct-aio-loading-text');

            // Content Generator
            this.elements.$contentForm = $("#gglct-aio-content-form");
            this.elements.$generateContentBtn = $("#gglct-aio-generate-button");
            this.elements.$contentPrompt = $("#gglct-aio-prompt");
            this.elements.$contentModelSelect = $("#gglct-aio-text-model");
            this.elements.$contentMaxTokens = $("#gglct-aio-max-tokens");
            this.elements.$contentTemperature = $("#gglct-aio-temperature");
            this.elements.$resultCard = $("#gglct-aio-result-card");
            this.elements.$resultContent = $("#gglct-aio-result-content");
            this.elements.$tokenCostDisplay = $("#gglct-aio-token-count");            this.elements.$copyContentBtn = $("#gglct-aio-copy-button");
            this.elements.$newPostBtn = $("#gglct-aio-new-post-button");
            this.elements.$costEstimatorDiv = $("#gglct-aio-cost-estimator");
            this.elements.$promptTokensDisplay = $("#gglct-aio-prompt-tokens-display");
            this.elements.$estimatedCostUsdDisplay = $("#gglct-aio-estimated-cost-usd-display");
            this.elements.$estimatedCostTomanDisplay = $("#gglct-aio-estimated-cost-toman-display");            // Image Generator
            this.elements.$imageForm = $("#gglct-aio-image-form");
            this.elements.$generateImageBtn = $("#gglct-aio-generate-image-button");            this.elements.$imagePrompt = $("#gglct-aio-image-prompt");
            this.elements.$imageModelSelect = $("#gglct-aio-image-model");
            this.elements.$imageSizeSelect = $("#gglct-aio-image-size");
            this.elements.$imageQualitySelect = $("#gglct-aio-image-quality");
            this.elements.$imageStyleSelect = $("#gglct-aio-image-style");
            this.elements.$imageNInput = $("#gglct-aio-image-n");
            this.elements.$imageResultCard = $("#gglct-aio-image-result-card");
            this.elements.$imageResultsContainer = $("#gglct-aio-image-results-container");
            this.elements.$imageCostDisplay = $("#gglct-aio-image-cost-display");
            this.elements.$imageCostEstimatorDiv = $("#gglct-aio-image-cost-estimator");
            this.elements.$imageEstimatedCostUsdDisplay = $("#gglct-aio-image-estimated-cost-usd-display");
            this.elements.$imageEstimatedCostTomanDisplay = $("#gglct-aio-image-estimated-cost-toman-display");

            // Settings Page
            this.elements.$settingsForm = $("#gglct-aio-settings-form");
            this.elements.$apiKeyInput = $("#gglct_aiop_api_key");
            this.elements.$testConnectionBtn = $("#gglct-aio-test-connection");
            this.elements.$usdtAutoFetchCheckbox = $("#gglct_aiop_usdt_auto_fetch");
            this.elements.$usdtManualRateInputSettings = $("#gglct_aiop_usdt_manual_rate");
            this.elements.$costCalculationEnabledCheckbox = $("#gglct_aiop_cost_calculation_enabled");
            this.elements.$addTextTemplateBtn = $("#gglct-aio-add-text-template");
            this.elements.$addImageTemplateBtn = $("#gglct-aio-add-image-template");
            this.elements.$textPromptTemplatesContainer = $("#gglct-aio-text-prompt-templates-container");
            this.elements.$imagePromptTemplatesContainer = $("#gglct-aio-image-prompt-templates-container");

            // Model Dashboard Page
            this.elements.$modelDashboardPage = $(".gglct-aio-model-dashboard");            this.elements.$modelsLoading = $(".gglct-aio-models-loading");
            this.elements.$modelsError = $(".gglct-aio-models-error");
            this.elements.$modelsErrorMessage = $("#gglct-aio-models-error-message");
            this.elements.$modelsDashboardGrid = $("#gglct-aio-models-dashboard-grid");
            this.elements.$usdtRateInputDashboard = $("#gglct-aio-usdt-rate-dashboard");
            this.elements.$saveUsdtRateBtnDashboard = $("#gglct-aio-save-usdt-rate-dashboard");
            this.elements.$currentTetherRateDashboard = $("#gglct-aio-current-tether-rate-dashboard");
            this.elements.$clearModelsCacheBtn = $("#gglct-aio-clear-models-cache");
            this.elements.$modelDetailModal = $("#gglct-aio-model-detail-modal");
            // WP Tools Page
            this.elements.$downloadWpButton = $("#gglct-aio-download-wp-button");
            this.elements.$downloadWpStatus = $("#gglct-aio-download-wp-status");

            // Metabox
            this.elements.$metaboxTabs = $("#gglct-aio-metabox-tabs");
            this.elements.$metaboxGenerateContentBtn = $("#gglct-aio-metabox-generate-button");
            this.elements.$metaboxContentPrompt = $("#gglct-aio-metabox-prompt");
            this.elements.$metaboxContentModelSelect = $("#gglct-aio-metabox-text-model");
            this.elements.$metaboxContentMaxTokens = $("#gglct-aio-metabox-max-tokens");
            this.elements.$metaboxContentTemperature = $("#gglct-aio-metabox-temperature");
            this.elements.$metaboxResultContent = $("#gglct-aio-metabox-result-content");
            this.elements.$metaboxLoading = $("#gglct-aio-metabox-loading");
            this.elements.$metaboxCostEstimatorDiv = $("#gglct-aio-metabox-cost-estimator");

            this.elements.$metaboxGenerateImageBtn = $("#gglct-aio-metabox-generate-image-button");
            this.elements.$metaboxImagePrompt = $("#gglct-aio-metabox-image-prompt");
            this.elements.$metaboxImageModelSelect = $("#gglct-aio-metabox-image-model");
            this.elements.$metaboxImageSizeSelect = $("#gglct-aio-metabox-image-size");
            this.elements.$metaboxImageQualitySelect = $("#gglct-aio-metabox-image-quality");
            this.elements.$metaboxImageStyleSelect = $("#gglct-aio-metabox-image-style");
            this.elements.$metaboxImageResultsContainer = $("#gglct-aio-metabox-image-results-container");
            this.elements.$metaboxImageLoading = $("#gglct-aio-metabox-image-loading");

            // History Page
            this.elements.$historyModal = $("#gglct-aio-history-modal");
        },

        bindEvents: function() {
            const self = this;

            this.elements.$generateContentBtn?.on("click", this.handleContentGeneration.bind(this));
            this.elements.$copyContentBtn?.on("click", this.handleCopyContent.bind(this));
            this.elements.$newPostBtn?.on("click", this.handleCreateNewPost.bind(this));

            this.elements.$generateImageBtn?.on("click", this.handleImageGeneration.bind(this));
            this.elements.$document.on("click", ".gglct-aio-copy-image-url", this.handleCopyImageUrl.bind(this));
            this.elements.$document.on("click", ".gglct-aio-upload-image-to-media", this.handleUploadImageToMedia.bind(this));
            this.elements.$document.on("click", ".gglct-aio-set-featured-image", this.handleSetFeaturedImage.bind(this));

            this.elements.$testConnectionBtn?.on("click", this.handleTestConnection.bind(this));
            this.elements.$usdtAutoFetchCheckbox?.on('change', function() {
                self.elements.$usdtManualRateInputSettings.prop('disabled', $(this).is(':checked'));
            });
            this.elements.$saveUsdtRateBtnDashboard?.on("click", this.handleSaveUsdtRate.bind(this));
            this.elements.$clearModelsCacheBtn?.on("click", this.handleClearModelsCache.bind(this));

            this.elements.$addTextTemplateBtn?.on("click", this.addPromptTemplate.bind(this, 'text'));
            this.elements.$addImageTemplateBtn?.on("click", this.addPromptTemplate.bind(this, 'image'));
            this.elements.$document.on("click", ".gglct-aio-remove-template", this.removePromptTemplate);

            this.elements.$document.on("click", ".gglct-aio-model-card", this.handleModelCardClick.bind(this));
            this.elements.$document.on("click", ".gglct-aio-modal-close", function() {
                 $(this).closest(".gglct-aio-modal").removeClass("show").empty();
            });

            this.elements.$downloadWpButton?.on("click", this.handleDownloadWordPressCore.bind(this));

            // Metabox events
            this.elements.$metaboxGenerateContentBtn?.on("click", this.handleMetaboxContentGeneration.bind(this));
            this.elements.$metaboxGenerateImageBtn?.on("click", this.handleMetaboxImageGeneration.bind(this));

            this.elements.$document.on("click", ".gglct-aio-view-history-item", this.handleViewHistoryItem.bind(this));
        },

        initTabs: function() {
            $("#gglct-aio-settings-tabs").tabs({
                activate: function(event, ui) {
                    self.state.activeTab = ui.newTab.attr('aria-labelledby').replace('ui-id-', '');
                }
            });
            this.elements.$metaboxTabs?.tabs();
        },

        initCostEstimator: function() {
            if (!this.config.costCalculationEnabled) {
                this.elements.$costEstimatorDiv?.hide();
                this.elements.$imageCostEstimatorDiv?.hide();
                return;
            }
            this.elements.$costEstimatorDiv?.show();
            this.elements.$imageCostEstimatorDiv?.show();

            this.elements.$contentPrompt?.on('input', $.debounce(300, this.updateContentCostEstimation.bind(this)));
            this.elements.$contentModelSelect?.on('change', this.updateContentCostEstimation.bind(this));
            this.elements.$contentMaxTokens?.on('input', $.debounce(300, this.updateContentCostEstimation.bind(this)));

            this.elements.$imagePrompt?.on('input', $.debounce(300, this.updateImageCostEstimation.bind(this)));
            this.elements.$imageModelSelect?.on('change', this.updateImageCostEstimation.bind(this));
            this.elements.$imageSizeSelect?.on('change', this.updateImageCostEstimation.bind(this));
            this.elements.$imageQualitySelect?.on('change', this.updateImageCostEstimation.bind(this));
            this.elements.$imageNInput?.on('input', $.debounce(300, this.updateImageCostEstimation.bind(this)));
            // Metabox cost estimator
            this.elements.$metaboxContentPrompt?.on('input', $.debounce(300, this.updateMetaboxContentCostEstimation.bind(this)));
            this.elements.$metaboxContentModelSelect?.on('change', this.updateMetaboxContentCostEstimation.bind(this));
            this.elements.$metaboxContentMaxTokens?.on('input', $.debounce(300, this.updateMetaboxContentCostEstimation.bind(this)));

            this.fetchTetherRate(false); // Fetch for cost estimator on all relevant pages
            this.updateContentCostEstimation();
            this.updateImageCostEstimation();
            this.updateMetaboxContentCostEstimation();
        },

        initModelDashboard: function() {
            if (this.elements.$modelDashboardPage?.length) {
                if (this.config.usdtAutoFetch) {
                    this.fetchTetherRate(true);
                } else {                    this.state.tetherRate = this.config.usdtManualRate;
                    this.updateTetherRateDisplay(this.state.tetherRate, false);
                    this.renderModelsDashboard();
                }
                this.fetchModelsData();
            }
        },

        initImageGenerator: function() {
            const self = this;
            if (this.elements.$imageModelSelect?.length) {
                this.elements.$imageModelSelect.on('change', function() {
                    self.updateImageModelOptions();
                });
                this.updateImageModelOptions(); // Initial update
            }
            if (this.elements.$metaboxImageModelSelect?.length) {
                this.elements.$metaboxImageModelSelect.on('change', function() {
                    self.updateMetaboxImageModelOptions();
                });                this.updateMetaboxImageModelOptions(); // Initial update
            }
        },

        initHistoryPage: function() {
            const self = this;
            if (this.elements.$historyModal?.length) {
                this.elements.$historyModal.dialog({
                    autoOpen: false,
                    modal: true,
                    width: Math.min(800, self.elements.$window.width() * 0.9),
                    height: Math.min(600, self.elements.$window.height() * 0.9),
                    title: self.config.strings.generatedContentTitle,
                    close: function() { $(this).empty(); },
                    buttons: {
                        [self.config.strings.copyContent]: function() {
                            const contentToCopy = $(this).find('.gglct-aio-modal-generated-content').html();
                            if (contentToCopy) {
                                self.copyToClipboard(contentToCopy);
                                self.showNotification(self.config.strings.contentCopied, 'success');
                            }
                            $(this).dialog("close");
                        },
                        [self.config.strings.close]: function() {
                            $(this).dialog("close");
                        }
                    }
                });
            }
        },

        showLoading: function(message) {
            this.elements.$loadingText.text(message);
            this.elements.$loadingOverlay.fadeIn(200);
        },

        hideLoading: function() {
            this.elements.$loadingOverlay.fadeOut(200);
        },

        handleContentGeneration: function() {
            if (this.state.isGenerating) return;
            this.state.isGenerating = true;
            this.showLoading(this.config.strings.generatingContent);
            this.elements.$resultCard?.hide();
            this.elements.$resultContent?.empty();
            const promptText = this.elements.$contentPrompt.val();
            if (!promptText) {
                this.showNotification(this.config.strings.promptRequired, "error");
                this.hideLoading();
                this.state.isGenerating = false;
                return;
            }

            const self = this;
            $.ajax({
                url: this.config.ajaxUrl,
                type: "POST",
                data: {
                    action: 'gglct_aiop_generate_content',
                    nonce: this.config.nonce,
                    prompt: promptText,
                    model: this.elements.$contentModelSelect.val(),
                    max_tokens: this.elements.$contentMaxTokens.val(),
                    temperature: this.elements.$contentTemperature.val(),
                    input_tokens_estimate: this.state.currentEstimatedInputTokens,
                    post_id: this.config.postId,
                    post_type: this.config.postType
                },
                success: function(response) {
                    if (response.success) {
                        self.elements.$resultContent?.html(self.formatGeneratedContent(response.data.content));
                        self.elements.$tokenCostDisplay?.text(self.formatNumber(response.data.usage.total_tokens, 0) + " " + self.config.strings.tokens);
                        if (self.config.costCalculationEnabled && response.data.cost) {
                            let costText = `${self.config.strings.finalCostUSD} $${self.formatNumber(response.data.cost.usd, 6)}`;
                            if (response.data.cost.toman > 0) {
                                costText += ` / ${self.config.strings.finalCostToman} ${self.formatNumber(response.data.cost.toman, 2)} ${self.config.strings.tomanUnit}`;
                            }
                            self.elements.$tokenCostDisplay?.append(`<br>${costText}`);
                        }
                        self.elements.$resultCard?.fadeIn();
                        self.showNotification(self.config.strings.contentGeneratedSuccess, "success");
                    } else {
                        self.showNotification(response.data.message || self.config.strings.error, "error");
                    }
                },
                error: function() {
                    self.showNotification(self.config.strings.apiError, "error");
                },
                complete: function() {
                    self.state.isGenerating = false;
                    self.hideLoading();
                }
            });
        },        handleImageGeneration: function() {
            if (this.state.isGenerating) return;
            this.state.isGenerating = true;
            this.showLoading(this.config.strings.generatingImage);
            this.elements.$imageResultCard?.hide();
            this.elements.$imageResultsContainer?.empty();

            const promptText = this.elements.$imagePrompt.val();
            if (!promptText) {                this.showNotification(this.config.strings.promptRequired, "error");
                this.hideLoading();
                this.state.isGenerating = false;
                return;
            }

            const self = this;
            $.ajax({
                url: this.config.ajaxUrl,
                type: "POST",
                data: {
                    action: 'gglct_aiop_generate_image',
                    nonce: this.config.nonce,
                    prompt: promptText,
                    model: this.elements.$imageModelSelect.val(),
                    size: this.elements.$imageSizeSelect.val(),
                    quality: this.elements.$imageQualitySelect.val(),
                    n: this.elements.$imageNInput.val(),
                    style: this.elements.$imageStyleSelect.val(),
                    post_id: this.config.postId
                },
                success: function(response) {
                    if (response.success) {
                        self.renderGeneratedImages(response.data.images);
                        if (self.config.costCalculationEnabled && response.data.cost) {
                            let costText = `${self.config.strings.finalCostUSD} $${self.formatNumber(response.data.cost.usd, 6)}`;
                            if (response.data.cost.toman > 0) {
                                costText += ` / ${self.config.strings.finalCostToman} ${self.formatNumber(response.data.cost.toman, 2)} ${self.config.strings.tomanUnit}`;
                            }
                            self.elements.$imageCostDisplay?.text(costText).show();
                        } else {
                            self.elements.$imageCostDisplay?.hide();
                        }
                        self.elements.$imageResultCard?.fadeIn();
                        self.showNotification(self.config.strings.imageGeneratedSuccess, "success");
                    } else {
                        self.showNotification(response.data.message || self.config.strings.error, "error");
                    }
                },
                error: function() {
                    self.showNotification(self.config.strings.apiError, "error");
                },
                complete: function() {
                    self.state.isGenerating = false;
                    self.hideLoading();
                }
            });
        },

        renderGeneratedImages: function(images) {
            const container = this.elements.$imageResultsContainer;
            container.empty();
            images.forEach(image => {
                const imgElement = `<img src="${image.url}" alt="${image.revised_prompt || this.config.strings.generatedImage}">`;
                const actions = `
                    <div class="gglct-aio-image-item-actions">
                        <button class="button gglct-aio-copy-image-url" data-url="${image.url}">${this.config.strings.copyUrl}</button>
                        <button class="button button-secondary gglct-aio-upload-image-to-media" data-url="${image.url}" data-title="${image.revised_prompt || ''}">${this.config.strings.uploadToMedia}</button>
                        <button class="button button-secondary gglct-aio-set-featured-image" data-url="${image.url}" data-title="${image.revised_prompt || ''}" data-post-id="${this.config.postId}">${this.config.strings.setFeaturedImage}</button>
                    </div>`;
                container.append(`<div class="gglct-aio-image-item">${imgElement}${actions}</div>`);
            });
        },

        handleCopyContent: function() {
            const content = this.elements.$resultContent?.html();
            if (content) {
                this.copyToClipboard(content);
                this.showNotification(this.config.strings.contentCopied, "success");
            }
        },

        handleCopyImageUrl: function(e) {
            const url = $(e.currentTarget).data('url');
            if (url) {
                this.copyToClipboard(url);
                this.showNotification(this.config.strings.imageCopied, "success");
            }
        },

        handleUploadImageToMedia: function(e) {            const self = this;
            const btn = $(e.currentTarget);
            const imageUrl = btn.data('url');
            const imageTitle = btn.data('title');
            const postId = this.config.postId;

            if (!imageUrl) return;

            self.showLoading(self.config.strings.uploadingImage);
            $.ajax({
                url: self.config.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'gglct_aiop_upload_generated_image',
                    nonce: self.config.nonce,
                    image_url: imageUrl,
                    post_id: postId,
                    image_title: imageTitle
                },
                success: function(response) {
                    if (response.success) {
                        self.showNotification(response.data.message || self.config.strings.imageUploaded, 'success');
                        // Optionally update UI to show it's uploaded
                    } else {
                        self.showNotification(response.data.message || self.config.strings.errorUploadingImage, 'error');
                    }
                },
                error: function() {
                    self.showNotification(self.config.strings.errorServerConnection, 'error');
                },
                complete: function() {
                    self.hideLoading();
                }
            });
        },

        handleSetFeaturedImage: function(e) {
            const self = this;
            const btn = $(e.currentTarget);
            const imageUrl = btn.data('url');
            const imageTitle = btn.data('title');
            const postId = btn.data('post-id');

            if (!imageUrl || !postId) return;

            self.showLoading(self.config.strings.uploadingImage);
            $.ajax({
                url: self.config.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'gglct_aiop_upload_generated_image',
                    nonce: self.config.nonce,
                    image_url: imageUrl,
                    post_id: postId,
                    set_featured: true,
                    image_title: imageTitle
                },
                success: function(response) {
                    if (response.success) {
                        self.showNotification(response.data.message || self.config.strings.imageSetAsFeatured, 'success');
                        // Update featured image box in post editor if available
                        if (typeof wp !== 'undefined' && wp.media && wp.media.featuredImage) {
                            wp.media.featuredImage.set(response.data.attachment_id);
                        }
                    } else {
                        self.showNotification(response.data.message || self.config.strings.errorUploadingImage, 'error');
                    }
                },
                error: function() {
                    self.showNotification(self.config.strings.errorServerConnection, 'error');
                },
                complete: function() {
                    self.hideLoading();
                }
            });
        },


        handleCreateNewPost: function() {
            const self = this;
            const content = this.elements.$resultContent?.html();
            if (!content) return;

            self.showLoading(self.config.strings.creatingPost);
            $.ajax({
                url: this.config.ajaxUrl,
                type: "POST",
                data: {
                    action: 'gglct_aiop_create_new_post',
                    nonce: this.config.nonce,
                    content: content,
                    post_type: this.config.postType,
                    title_suggestion: this.elements.$contentPrompt.val().split('\n')[0].substring(0,100)
                },
                success: function(response) {                    if (response.success) {
                        self.showNotification(response.data.message, "success");
                        if (response.data.edit_url) {
                            window.open(response.data.edit_url, '_blank');
                        }
                    } else {
                        self.showNotification(response.data.message || self.config.strings.error, "error");
                    }
                },
                error: function() {
                    self.showNotification(self.config.strings.errorServerConnection, "error");
                },
                complete: function() {
                    self.hideLoading();
                }
            });
        },

        handleTestConnection: function() {
            const self = this;
            const apiKey = this.elements.$apiKeyInput.val();
            if (!apiKey) {
                this.showNotification(this.config.strings.apiKeyRequired, "error");
                return;
            }

            self.showLoading(self.config.strings.testingConnection);
            $.ajax({
                url: this.config.ajaxUrl,
                type: "POST",
                data: {
                    action: 'gglct_aiop_test_connection',
                    nonce: this.config.nonce,
                    api_key: apiKey
                },
                success: function(response) {
                    if (response.success) {
                        self.showNotification(response.data.message, "success");
                    } else {
                        self.showNotification(response.data.message || self.config.strings.connectionTestError, "error");
                    }
                },
                error: function() {
                    self.showNotification(self.config.strings.errorServerConnection, "error");
                },
                complete: function() {
                    self.hideLoading();
                }
            });
        },

        fetchTetherRate: function(updateDashboard = false) {
            const self = this;
            if (updateDashboard) {
                this.elements.$currentTetherRateDashboard?.html(this.config.strings.loadingContent);
            }
            $.ajax({                url: 'https://api.tetherland.com/currencies',
                type: 'GET',
                success: function(data) {
                    if (data.status === 200 && data.data.currencies.USDT) {
                        self.state.tetherRate = parseFloat(data.data.currencies.USDT.price);
                        self.updateTetherRateDisplay(self.state.tetherRate, true);
                    } else {
                        self.state.tetherRate = self.config.usdtManualRate > 0 ? self.config.usdtManualRate : 0;
                        self.updateTetherRateDisplay(self.state.tetherRate, false, true);
                    }
                },
                error: function() {
                    self.state.tetherRate = self.config.usdtManualRate > 0 ? self.config.usdtManualRate : 0;
                    self.updateTetherRateDisplay(self.state.tetherRate, false, true);
                },
                complete: function() {
                    if (updateDashboard) {
                        self.renderModelsDashboard();
                    } else if (self.config.costCalculationEnabled) {
                        self.updateContentCostEstimation();
                        self.updateImageCostEstimation();
                        self.updateMetaboxContentCostEstimation();
                    }
                }
            });
        },

        updateTetherRateDisplay: function(rate, isAuto, isError = false) {
            const rateText = rate > 0 ? this.formatNumber(rate) + " " + this.config.strings.tomanUnit : this.config.strings.priceNotAvailable;
            let sourceText = "";
            if (isError && this.config.usdtManualRate > 0) {
                 sourceText = ` <small>(${this.config.strings.tetherRateError} - ${this.config.strings.tetherManualRate})</small>`;
            } else if (isError) {
                sourceText = ` <small>(${this.config.strings.tetherRateError})</small>`;
            } else if (isAuto) {
                sourceText = ` <small>(${this.config.strings.tetherRateSource})</small>`;
            } else if (rate > 0) {
                sourceText = ` <small>(${this.config.strings.tetherManualRate})</small>`;
            }
            this.elements.$currentTetherRateDashboard?.html(rateText + sourceText);
             if(this.elements.$usdtRateInputDashboard?.length && rate > 0 && !this.elements.$usdtRateInputDashboard.is(':focus')) {
                this.elements.$usdtRateInputDashboard.val(Math.round(rate));
            }
        },

        handleSaveUsdtRate: function() {
            const self = this;
            const rate = parseFloat(this.elements.$usdtRateInputDashboard?.val()) || 0;
            self.showLoading(self.config.strings.saving);
            $.ajax({
                url: this.config.ajaxUrl,
                type: "POST",
                data: {
                    action: 'gglct_aiop_update_tether_rate',
                    nonce: this.config.nonce,
                    rate: rate
                },
                success: function(response) {
                    if (response.success) {
                        self.config.usdtManualRate = response.data.new_rate;
                        self.state.tetherRate = response.data.new_rate;
                        self.updateTetherRateDisplay(response.data.new_rate, false);
                        self.renderModelsDashboard();
                        self.elements.$usdtManualRateInputSettings?.val(response.data.new_rate);
                        self.showNotification(self.config.strings.tetherRateSavedSuccess, "success");
                    } else {
                        self.showNotification(response.data.message || self.config.strings.error, "error");
                    }
                },
                error: function() {
                    self.showNotification(self.config.strings.errorServerConnection, "error");
                },
                complete: function() {
                    self.hideLoading();
                }
            });
        },

        handleClearModelsCache: function() {
            const self = this;
            self.showLoading(self.config.strings.clearCache);
             $.ajax({
                url: this.config.ajaxUrl,
                type: "POST",
                data: {
                    action: 'gglct_aiop_clear_models_cache',
                    nonce: this.config.nonce
                },
                success: function(response) {
                    if (response.success) {
                        self.showNotification(self.config.strings.cacheCleared, "success");
                        self.fetchModelsData();
                    } else {
                        self.showNotification(response.data.message || self.config.strings.errorClearingCache, "error");
                    }
                },
                error: function() {
                    self.showNotification(self.config.strings.errorServerConnection, "error");
                },
                complete: function() {
                    self.hideLoading();
                }
            });
        },        fetchModelsData: function() {
            const self = this;
            this.elements.$modelsLoading?.show();
            this.elements.$modelsError?.hide();
            $.ajax({
                url: this.config.ajaxUrl,
                type: "POST",
                data: {
                    action: 'gglct_aiop_get_models_data',
                    nonce: this.config.nonce
                },
                success: function(response) {
                    self.elements.$modelsLoading?.hide();
                    if (response.success) {
                        self.config.allTextModelsData = response.data.text_models || [];
                        self.config.allImageModelsData = response.data.image_models || [];
                        self.config.imageModelDetails = self.processImageModelDetails(self.config.allImageModelsData);
                        self.renderModelsDashboard();
                        self.updateModelSelectOptions(self.elements.$contentModelSelect, self.config.allTextModelsData, self.config.defaultTextModel);
                        self.updateModelSelectOptions(self.elements.$imageModelSelect, self.config.allImageModelsData, self.config.defaultImageModel);
                        self.updateImageModelOptions();
                        self.updateMetaboxModelSelectOptions(self.elements.$metaboxContentModelSelect, self.config.allTextModelsData, self.config.defaultTextModel);
                        self.updateMetaboxModelSelectOptions(self.elements.$metaboxImageModelSelect, self.config.allImageModelsData, self.config.defaultImageModel);
                        self.updateMetaboxImageModelOptions();
                    } else {
                        self.elements.$modelsErrorMessage?.text(response.data.message || self.config.strings.fetchModelsError);
                        self.elements.$modelsError?.show();
                    }
                },
                error: function() {
                    self.elements.$modelsLoading?.hide();
                    self.elements.$modelsErrorMessage?.text(self.config.strings.errorServerConnection);
                    self.elements.$modelsError?.show();
                }
            });
        },

        processImageModelDetails: function(allImageModelsData) {
            const details = {};
            allImageModelsData.forEach(model => {
                details[model.id] = {
                    id: model.id,
                    name: model.name || model.id,
                    sizes: model.capabilities?.sizes || ['1024x1024'],
                    qualities: model.capabilities?.qualities || ['standard'],
                    styles: model.capabilities?.styles || ['vivid', 'natural'],
                    max_per_request: model.capabilities?.max_n || 1,
                    pricing: model.pricing || {}
                };
            });
            return details;
        },

        renderModelsDashboard: function() {
            const self = this;
            this.elements.$modelsDashboardGrid?.empty();
            if (!this.config.allTextModelsData.length && !this.config.allImageModelsData.length) {
                 this.elements.$modelsDashboardGrid?.html(`<p>${this.config.strings.fetchModelsError}</p>`);
                 return;
            }

            const allModels = [...this.config.allTextModelsData, ...this.config.allImageModelsData].sort((a,b) => a.id.localeCompare(b.id));

            allModels.forEach(model => {
                let pricingHtml = `<p><strong>${self.config.strings.price}:</strong></p>`;
                if (model.pricing) {
                    if (model.type === 'text' || (model.pricing.input || model.pricing.output)) {
                        pricingHtml += `<p>${self.config.strings.inputTokens}: $${self.formatNumber(model.pricing.input || model.pricing.cached_input || 0, 6)}/M</p>`;
                        pricingHtml += `<p>${self.config.strings.outputTokens}: $${self.formatNumber(model.pricing.output || 0, 6)}/M</p>`;
                    } else if (model.type === 'image' || model.pricing.standard || model.pricing.hd || (model.pricing.standard && typeof model.pricing.standard === 'object')) {
                        if (model.id === 'dall-e-3') {
                            pricingHtml += `<p>${self.config.strings.standardQuality}: $${self.formatNumber(model.pricing.standard || 0, 6)}</p>`;
                            if (model.pricing.hd) pricingHtml += `<p>${self.formatNumber(model.pricing.hd, 6)}</p>`;
                        } else if (model.id === 'dall-e-2' && model.pricing.standard) {
                            for (const size in model.pricing.standard) {
                                pricingHtml += `<p>${size}: $${self.formatNumber(model.pricing.standard[size] || 0, 6)}</p>`;
                            }
                        } else {
                             pricingHtml += `<p>${self.config.strings.priceNotAvailable}</p>`;
                        }
                    } else {
                        pricingHtml += `<p>${self.config.strings.priceNotAvailable}</p>`;
                    }
                } else {
                    pricingHtml += `<p>${self.config.strings.priceNotAvailable}</p>`;
                }

                const cardHtml = `
                    <h3>${model.name || model.id}</h3>
                    <p><strong>${self.config.strings.type}:</strong> ${model.type === 'text' ? __('متن', 'gglct-ai-optimizer-pro') : __('تصویر', 'gglct-ai-optimizer-pro')}</p>
                    <p><strong>${self.config.strings.capabilities}:</strong> ${model.capabilities?.join(', ') || '-'}</p>
                    ${pricingHtml}
                `;
                this.elements.$modelsDashboardGrid?.append(`<div class="gglct-aio-model-card" data-model-id="${model.id}">${cardHtml}</div>`);
            });
        },

        handleModelCardClick: function(e) {
            const modelId = $(e.currentTarget).data('model-id');
            const modelData = [...this.config.allTextModelsData, ...this.config.allImageModelsData].find(m => m.id === modelId);

            if (!modelData) return;

            let detailsHtml = `
                <div class="gglct-aio-modal-header">
                    <h3>${modelData.name || modelData.id}</h3>
                    <span class="gglct-aio-modal-close">&times;</span>
                </div>
                <div class="gglct-aio-modal-body">
                    <p><strong>${this.config.strings.type}:</strong> ${modelData.type === 'text' ? __('متن', 'gglct-ai-optimizer-pro') : __('تصویر', 'gglct-ai-optimizer-pro')}</p>
                    <p><strong>${this.config.strings.capabilities}:</strong> ${modelData.capabilities?.join(', ') || '-'}</p>
            `;

            if (modelData.type === 'text' && modelData.max_tokens) {
                detailsHtml += `<p><strong>${this.config.strings.maxTokens}:</strong> ${this.formatNumber(modelData.max_tokens, 0)}</p>`;
            } else if (modelData.type === 'image') {
                const imgDetails = this.config.imageModelDetails[modelId];
                if (imgDetails) {
                    detailsHtml += `<p><strong>${this.config.strings.supportedSizes}:</strong> ${imgDetails.sizes?.join(', ') || '-'}</p>`;
                    if (imgDetails.qualities?.length) detailsHtml += `<p><strong>${this.config.strings.supportedQualities}:</strong> ${imgDetails.qualities.join(', ')}</p>`;
                    if (imgDetails.styles?.length) detailsHtml += `<p><strong>${this.config.strings.supportedStyles}:</strong> ${imgDetails.styles.join(', ')}</p>`;
                    if (imgDetails.max_per_request) detailsHtml += `<p><strong>${this.config.strings.maxImagesPerRequest}:</strong> ${imgDetails.max_per_request}</p>`;
                }
            }

            detailsHtml += `<h4>${this.config.strings.pricing}:</h4>`;
            if (modelData.pricing) {
                if (modelData.type === 'text' || (modelData.pricing.input || modelData.pricing.output)) {
                    detailsHtml += `<ul>`;
                    detailsHtml += `<li>${this.config.strings.inputTokens}: $${this.formatNumber(modelData.pricing.input || modelData.pricing.cached_input || 0, 6)}/M (${this.calculateTomanPrice(modelData.pricing.input || modelData.pricing.cached_input || 0)}/M)</li>`;
                    detailsHtml += `<li>${this.config.strings.outputTokens}: $${this.formatNumber(modelData.pricing.output || 0, 6)}/M (${this.calculateTomanPrice(modelData.pricing.output || 0)}/M)</li>`;
                    detailsHtml += `</ul>`;                } else if (modelData.type === 'image' || modelData.pricing.standard || modelData.pricing.hd || (modelData.pricing.standard && typeof modelData.pricing.standard === 'object')) {
                    detailsHtml += `<ul>`;
                    if (modelData.id === 'dall-e-3') {
                        detailsHtml += `<li>${this.config.strings.standardQuality}: $${this.formatNumber(modelData.pricing.standard || 0, 6)} (${this.calculateTomanPrice(modelData.pricing.standard || 0)})</li>`;
                        if (modelData.pricing.hd) detailsHtml += `<li>${this.config.strings.hdQuality}: $${this.formatNumber(modelData.pricing.hd, 6)} (${this.calculateTomanPrice(modelData.pricing.hd)})</li>`;                    } else if (modelData.id === 'dall-e-2' && modelData.pricing.standard) {
                        for (const size in modelData.pricing.standard) {
                            detailsHtml += `<li>${size}: $${this.formatNumber(modelData.pricing.standard[size] || 0, 6)} (${this.calculateTomanPrice(modelData.pricing.standard[size] || 0)})</li>`;
                        }
                    } else {
                        detailsHtml += `<li>${this.config.strings.priceNotAvailable}</li>`;
                    }
                    detailsHtml += `</ul>`;
                } else {
                    detailsHtml += `<p>${this.config.strings.priceNotAvailable}</p>`;
                }
            } else {
                detailsHtml += `<p>${this.config.strings.priceNotAvailable}</p>`;
            }
            detailsHtml += `</div>`;

            this.elements.$modelDetailModal?.html(detailsHtml).addClass("show");
        },

        calculateTomanPrice: function(usdPrice) {
            const rate = this.state.tetherRate > 0 ? this.state.tetherRate : (this.config.usdtManualRate > 0 ? this.config.usdtManualRate : 0);
            if (rate > 0 && typeof usdPrice === 'number') {
                return this.formatNumber(usdPrice * rate) + " " + this.config.strings.tomanUnit;
            }
            return this.config.strings.priceNotAvailable;
        },

        updateContentCostEstimation: function() {
            if (!this.config.costCalculationEnabled) return;

            const promptText = this.elements.$contentPrompt?.val() || "";
            this.state.currentEstimatedInputTokens = this.countTokensSimple(promptText);
            this.elements.$promptTokensDisplay?.text(`${this.config.strings.inputTokensEstimate} ${this.formatNumber(this.state.currentEstimatedInputTokens, 0)}`);

            const selectedModelId = this.elements.$contentModelSelect?.val();
            const modelData = this.config.allTextModelsData.find(m => m.id === selectedModelId);

            let estimatedCostUSD = 0;
            if (modelData && modelData.pricing) {
                const pricing = modelData.pricing;                const inputPricePerMillion = parseFloat(pricing.input || pricing.cached_input || 0);
                const estimatedOutputTokens = Math.min(parseInt(this.elements.$contentMaxTokens?.val() || 2000), Math.max(this.state.currentEstimatedInputTokens, 250));
                const outputPricePerMillion = parseFloat(pricing.output || 0);

                estimatedCostUSD = ((this.state.currentEstimatedInputTokens / 1000000) * inputPricePerMillion) + ((estimatedOutputTokens / 1000000) * outputPricePerMillion);
            }

            this.elements.$estimatedCostUsdDisplay?.text(`${this.config.strings.estimatedCostUSD} $${estimatedCostUSD.toFixed(6)}`);
            const currentTetherRate = this.state.tetherRate > 0 ? this.state.tetherRate : (this.config.usdtManualRate > 0 ? this.config.usdtManualRate : 0);
            if (currentTetherRate > 0) {
                const estimatedCostToman = estimatedCostUSD * currentTetherRate;
                this.elements.$estimatedCostTomanDisplay?.text(`${this.config.strings.estimatedCostToman} ${this.formatNumber(estimatedCostToman)} ${this.config.strings.tomanUnit}`);
            } else {
                this.elements.$estimatedCostTomanDisplay?.text(`${this.config.strings.estimatedCostToman} ${this.config.strings.priceNotAvailable}`);
            }
        },

        updateImageCostEstimation: function() {
            if (!this.config.costCalculationEnabled) return;

            const selectedModelId = this.elements.$imageModelSelect?.val();
            const numImages = parseInt(this.elements.$imageNInput?.val() || 1);
            const imageSize = this.elements.$imageSizeSelect?.val();
            const imageQuality = this.elements.$imageQualitySelect?.val();

            const modelData = this.config.allImageModelsData.find(m => m.id === selectedModelId);
            let estimatedCostUSD = 0;
            if (modelData && modelData.pricing) {
                if (selectedModelId === 'dall-e-3') {
                    const pricePerImage = parseFloat(modelData.pricing[imageQuality] || modelData.pricing.standard || 0);
                    estimatedCostUSD = pricePerImage * numImages;
                } else if (selectedModelId === 'dall-e-2') {                    const priceKey = `standard_${imageSize}`;
                    const pricePerImage = parseFloat(modelData.pricing.standard[priceKey] || modelData.pricing.standard['1024x1024'] || 0);
                    estimatedCostUSD = pricePerImage * numImages;
                }
            }

            this.elements.$imageEstimatedCostUsdDisplay?.text(`${this.config.strings.estimatedCostUSD} $${estimatedCostUSD.toFixed(6)}`);
            const currentTetherRate = this.state.tetherRate > 0 ? this.state.tetherRate : (this.config.usdtManualRate > 0 ? this.config.usdtManualRate : 0);
            if (currentTetherRate > 0) {
                const estimatedCostToman = estimatedCostUSD * currentTetherRate;
                this.elements.$imageEstimatedCostTomanDisplay?.text(`${this.config.strings.estimatedCostToman} ${this.formatNumber(estimatedCostToman)} ${this.config.strings.tomanUnit}`);
            } else {
                this.elements.$imageEstimatedCostTomanDisplay?.text(`${this.config.strings.estimatedCostToman} ${this.config.strings.priceNotAvailable}`);
            }
        },

        updateMetaboxContentCostEstimation: function() {
            if (!this.config.costCalculationEnabled) return;

            const promptText = this.elements.$metaboxContentPrompt?.val() || "";
            const estimatedInputTokens = this.countTokensSimple(promptText);
            this.elements.$metaboxCostEstimatorDiv?.html(`${this.config.strings.inputTokensEstimate} ${this.formatNumber(estimatedInputTokens, 0)}`);

            const selectedModelId = this.elements.$metaboxContentModelSelect?.val();
            const modelData = this.config.allTextModelsData.find(m => m.id === selectedModelId);

            let estimatedCostUSD = 0;
            if (modelData && modelData.pricing) {
                const pricing = modelData.pricing;
                const inputPricePerMillion = parseFloat(pricing.input || pricing.cached_input || 0);
                const estimatedOutputTokens = Math.min(parseInt(this.elements.$metaboxContentMaxTokens?.val() || 2000), Math.max(estimatedInputTokens, 250));
                const outputPricePerMillion = parseFloat(pricing.output || 0);

                estimatedCostUSD = ((estimatedInputTokens / 1000000) * inputPricePerMillion) + ((estimatedOutputTokens / 1000000) * outputPricePerMillion);
            }

            this.elements.$metaboxCostEstimatorDiv?.append(`<br>${this.config.strings.estimatedCostUSD} $${estimatedCostUSD.toFixed(6)}`);
            const currentTetherRate = this.state.tetherRate > 0 ? this.state.tetherRate : (this.config.usdtManualRate > 0 ? this.config.usdtManualRate : 0);
            if (currentTetherRate > 0) {
                const estimatedCostToman = estimatedCostUSD * currentTetherRate;
                this.elements.$metaboxCostEstimatorDiv?.append(`<br>${this.config.strings.estimatedCostToman} ${this.formatNumber(estimatedCostToman)} ${this.config.strings.tomanUnit}`);
            } else {
                this.elements.$metaboxCostEstimatorDiv?.append(`<br>${this.config.strings.estimatedCostToman} ${this.config.strings.priceNotAvailable}`);
            }
        },

        updateImageModelOptions: function() {
            const selectedModelId = this.elements.$imageModelSelect?.val();
            this.state.imageCurrentModelDetails = this.config.imageModelDetails[selectedModelId];

            if (this.state.imageCurrentModelDetails) {
                this.populateSelect(this.elements.$imageSizeSelect, this.state.imageCurrentModelDetails.sizes, this.config.defaultImageSize);
                this.populateSelect(this.elements.$imageQualitySelect, this.state.imageCurrentModelDetails.qualities, this.config.defaultImageQuality);
                this.elements.$imageStyleSelect?.toggle(selectedModelId === 'dall-e-3');
                this.elements.$imageNInput?.val(this.state.imageCurrentModelDetails.max_per_request || 1).prop('max', this.state.imageCurrentModelDetails.max_per_request || 1);
            } else {
                this.elements.$imageSizeSelect?.empty();
                this.elements.$imageQualitySelect?.empty();
                this.elements.$imageStyleSelect?.hide();
                this.elements.$imageNInput?.val(1).prop('max', 1);
            }
            this.updateImageCostEstimation();
        },

        updateMetaboxImageModelOptions: function() {
            const selectedModelId = this.elements.$metaboxImageModelSelect?.val();
            const modelDetails = this.config.imageModelDetails[selectedModelId];

            if (modelDetails) {
                this.populateSelect(this.elements.$metaboxImageSizeSelect, modelDetails.sizes, this.config.defaultImageSize);
                this.populateSelect(this.elements.$metaboxImageQualitySelect, modelDetails.qualities, this.config.defaultImageQuality);
                this.elements.$metaboxImageStyleSelect?.toggle(selectedModelId === 'dall-e-3');
            } else {
                this.elements.$metaboxImageSizeSelect?.empty();
                this.elements.$metaboxImageQualitySelect?.empty();
                this.elements.$metaboxImageStyleSelect?.hide();
            }
        },

        populateSelect: function(selectElement, options, defaultValue) {
            if (!selectElement || !options) return;
            selectElement.empty();
            options.forEach(option => {
                selectElement.append(
                    $("<option></option>")
                        .attr("value", option)
                        .text(option)
                        .prop("selected", option === defaultValue)
                );
            });
            if (selectElement.val() === null && options.length > 0) {
                selectElement.val(options[0]);
            }
        },

        updateModelSelectOptions: function(selectElement, modelsData, defaultValue) {
            if (!selectElement || !modelsData) return;
            const currentVal = selectElement.val();
            selectElement.empty();            modelsData.forEach(model => {
                selectElement.append(
                    $("<option></option>")
                        .attr("value", model.id)
                        .text(model.name || model.id)
                        .prop("selected", model.id === currentVal || model.id === defaultValue)
                );
            });
            if (selectElement.val() === null && modelsData.length > 0) {                selectElement.val(modelsData[0].id);
            }
        },

        updateMetaboxModelSelectOptions: function(selectElement, modelsData, defaultValue) {
            if (!selectElement || !modelsData) return;
            const currentVal = selectElement.val();
            selectElement.empty();
            modelsData.forEach(model => {
                selectElement.append(
                    $("<option></option>")
                        .attr("value", model.id)
                        .text(model.name || model.id)
                        .prop("selected", model.id === currentVal || model.id === defaultValue)
                );            });
            if (selectElement.val() === null && modelsData.length > 0) {
                selectElement.val(modelsData[0].id);
            }
        },

        addPromptTemplate: function(type) {
            const container = (type === 'text') ? this.elements.$textPromptTemplatesContainer : this.elements.$imagePromptTemplatesContainer;
            const keyPrefix = (type === 'text') ? 'gglct_aiop_text_prompt_templates_keys[]' : 'gglct_aiop_image_prompt_templates_keys[]';
            const valuePrefix = (type === 'text') ? 'gglct_aiop_text_prompt_templates_values[]' : 'gglct_aiop_image_prompt_templates_values[]';
            const placeholderText = (type === 'text') ? this.config.strings.promptTextPlaceholder : this.config.strings.promptImagePlaceholder;

            const newItem = `                <div class="gglct-aio-prompt-template-item animate__animated animate__fadeIn">
                    <input type="text" name="${keyPrefix}" value="" placeholder="${this.config.strings.templateName}" class="regular-text">
                    <textarea name="${valuePrefix}" rows="3" placeholder="${placeholderText}" class="large-text"></textarea>
                    <button type="button" class="button button-secondary gglct-aio-remove-template">${this.config.strings.delete}</button>
                </div>`;
            container.append(newItem);
        },

        removePromptTemplate: function(e) {
            $(e.currentTarget).closest('.gglct-aio-prompt-template-item').addClass('animate__animated animate__fadeOut').one('animationend', function() {
                $(this).remove();
            });
        },

        handleMetaboxContentGeneration: function() {
            if (this.state.isGenerating) return;
            this.state.isGenerating = true;
            this.showLoading(this.config.strings.generatingContent);
            this.elements.$metaboxResultContent?.empty();

            const promptText = this.elements.$metaboxContentPrompt.val();
            if (!promptText) {
                this.showNotification(this.config.strings.promptRequired, "error");
                this.hideLoading();
                this.state.isGenerating = false;
                return;
            }

            const self = this;            const postId = this.elements.$metaboxGenerateContentBtn.data('post-id');
            const postType = this.elements.$metaboxGenerateContentBtn.data('post-type');

            $.ajax({
                url: this.config.ajaxUrl,
                type: "POST",
                data: {
                    action: 'gglct_aiop_generate_content',
                    nonce: this.config.nonce,
                    prompt: promptText,
                    model: this.elements.$metaboxContentModelSelect.val(),
                    max_tokens: this.elements.$metaboxContentMaxTokens.val(),
                    temperature: this.elements.$metaboxContentTemperature.val(),
                    input_tokens_estimate: this.countTokensSimple(promptText),
                    post_id: postId,
                    post_type: postType
                },
                success: function(response) {
                    if (response.success) {
                        self.elements.$metaboxResultContent?.html(self.formatGeneratedContent(response.data.content)).fadeIn();
                        self.showNotification(self.config.strings.contentGeneratedSuccess, "success");
                        // Optionally insert into editor
                        if (typeof tinymce !== 'undefined' && tinymce.activeEditor && !tinymce.activeEditor.isHidden()) {
                            tinymce.activeEditor.execCommand('mceInsertContent', false, response.data.content);
                        } else if (typeof wp !== 'undefined' && wp.blocks && wp.data) {
                            const { createBlock } = wp.blocks;
                            const { insertBlock } = wp.data.dispatch('core/block-editor');
                            const block = createBlock('gglct-ai-optimizer-pro/ai-content-generator', { generatedHTML: response.data.content });
                            insertBlock(block);
                        } else {
                            const editor = $('#content');
                            if (editor.length) {
                                editor.val(editor.val() + response.data.content);
                            }
                        }
                    } else {
                        self.showNotification(response.data.message || self.config.strings.error, "error");
                    }
                },
                error: function() {
                    self.showNotification(self.config.strings.apiError, "error");
                },
                complete: function() {
                    self.state.isGenerating = false;
                    self.hideLoading();
                }
            });
        },

        handleMetaboxImageGeneration: function() {
            if (this.state.isGenerating) return;
            this.state.isGenerating = true;
            this.showLoading(this.config.strings.generatingImage);
            this.elements.$metaboxImageResultsContainer?.empty();

            const promptText = this.elements.$metaboxImagePrompt.val();
            if (!promptText) {
                this.showNotification(this.config.strings.promptRequired, "error");
                this.hideLoading();
                this.state.isGenerating = false;
                return;
            }

            const self = this;
            const postId = this.elements.$metaboxGenerateImageBtn.data('post-id');

            $.ajax({
                url: this.config.ajaxUrl,
                type: "POST",
                data: {
                    action: 'gglct_aiop_generate_image',
                    nonce: this.config.nonce,
                    prompt: promptText,
                    model: this.elements.$metaboxImageModelSelect.val(),
                    size: this.elements.$metaboxImageSizeSelect.val(),
                    quality: this.elements.$metaboxImageQualitySelect.val(),
                    n: 1, // Metabox generates 1 image for simplicity
                    style: this.elements.$metaboxImageStyleSelect.val(),
                    post_id: postId
                },
                success: function(response) {
                    if (response.success) {
                        self.renderMetaboxGeneratedImages(response.data.images, postId);
                        self.showNotification(self.config.strings.imageGeneratedSuccess, "success");
                    } else {
                        self.showNotification(response.data.message || self.config.strings.error, "error");
                    }
                },
                error: function() {
                    self.showNotification(self.config.strings.apiError, "error");
                },
                complete: function() {
                    self.state.isGenerating = false;
                    self.hideLoading();
                }
            });
        },

        renderMetaboxGeneratedImages: function(images, postId) {
            const container = this.elements.$metaboxImageResultsContainer;
            container.empty();
            images.forEach(image => {
                const imgElement = `<img src="${image.url}" alt="${image.revised_prompt || this.config.strings.generatedImage}">`;
                const actions = `
                    <div class="gglct-aio-image-item-actions">
                        <button class="button gglct-aio-copy-image-url" data-url="${image.url}">${this.config.strings.copyUrl}</button>
                        <button class="button button-secondary gglct-aio-upload-image-to-media" data-url="${image.url}" data-title="${image.revised_prompt || ''}" data-post-id="${postId}">${this.config.strings.uploadToMedia}</button>
                        <button class="button button-secondary gglct-aio-set-featured-image" data-url="${image.url}" data-title="${image.revised_prompt || ''}" data-post-id="${postId}">${this.config.strings.setFeaturedImage}</button>
                    </div>`;
                container.append(`<div class="gglct-aio-image-item">${imgElement}${actions}</div>`);
            });
        },

        handleDownloadWordPressCore: function() {
            const self = this;
            if (self.state.isGenerating) return;
            self.state.isGenerating = true;
            self.showLoading(self.config.strings.downloadingWordPress);
            self.elements.$downloadWpStatus?.empty();

            $.ajax({
                url: self.config.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'gglct_aiop_download_wordpress_core',
                    nonce: self.config.wpToolsNonce
                },
                success: function(response) {
                    if (response.success) {
                        self.elements.$downloadWpStatus?.html(`<p class="gglct-aio-success-message">${response.data.message} <strong>${response.data.file_path_display}</strong></p><p><a href="${response.data.file_url}" target="_blank" class="button button-primary">${self.config.strings.downloadWordPressSuccess}</a></p>`);
                        self.showNotification(self.config.strings.downloadWordPressSuccess, 'success');
                    } else {
                        self.elements.$downloadWpStatus?.html(`<p class="gglct-aio-error-message">${response.data.message}</p>`);
                        self.showNotification(self.config.strings.downloadWordPressError, 'error');
                    }
                },
                error: function() {
                    self.elements.$downloadWpStatus?.html(`<p class="gglct-aio-error-message">${self.config.strings.errorServerConnection}</p>`);
                    self.showNotification(self.config.strings.errorServerConnection, 'error');
                },
                complete: function() {
                    self.state.isGenerating = false;
                    self.hideLoading();
                }
            });
        },

        handleViewHistoryItem: function(e) {            const self = this;
            const itemId = $(e.currentTarget).data('id');
            if (!itemId) return;

            self.showLoading(self.config.strings.loadingContent);
            $.ajax({
                url: self.config.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'gglct_aiop_get_history_content',
                    nonce: self.config.nonce,
                    id: itemId
                },
                success: function(response) {
                    if (response.success && response.data.item) {
                        const item = response.data.item;
                        let modalContent = `
                            <div class="gglct-aio-modal-header">
                                <h3>${self.config.strings.generatedContentTitle} #${item.id}</h3>
                                <span class="gglct-aio-modal-close">&times;</span>
                            </div>
                            <div class="gglct-aio-modal-body">
                                <p><strong>${self.config.strings.prompt}:</strong> <pre>${item.prompt}</pre></p>
                                <p><strong>${self.config.strings.model}:</strong> ${item.model}</p>
                                <p><strong>${self.config.strings.tokenCount}:</strong> ${self.formatNumber(item.tokens, 0)}</p>
                                <p><strong>${self.config.strings.finalCostUSD}:</strong> $${self.formatNumber(item.cost_usd, 6)}</p>
                                <p><strong>${self.config.strings.finalCostToman}:</strong> ${self.formatNumber(item.cost_toman, 2)} ${self.config.strings.tomanUnit}</p>
                        `;

                        if (item.generated_item_type === 'text') {
                            modalContent += `<h4>${self.config.strings.generatedContent}:</h4><div class="gglct-aio-modal-generated-content">${item.content}</div>`;
                        } else if (item.generated_item_type === 'image' && item.image_urls_decoded) {
                            modalContent += `<h4>${self.config.strings.generatedImages}:</h4><div class="gglct-aio-image-results-container">`;
                            item.image_urls_decoded.forEach(imgUrl => {
                                modalContent += `<div class="gglct-aio-image-item"><img src="${imgUrl}" style="max-width:100%; height:auto;" /><div class="gglct-aio-image-item-actions"><button class="button gglct-aio-copy-image-url" data-url="${imgUrl}">${self.config.strings.copyUrl}</button></div></div>`;
                            });
                            modalContent += `</div>`;
                        }
                        modalContent += `</div>`;

                        self.elements.$historyModal?.html(modalContent).dialog("open");
                    } else {
                        self.showNotification(response.data.message || self.config.strings.errorFetchingContent, 'error');
                    }
                },
                error: function() {
                    self.showNotification(self.config.strings.errorServerConnection, 'error');
                },
                complete: function() {
                    self.hideLoading();
                }
            });
        },

        formatGeneratedContent: function(content) {
            content = content.replace(/\n\s*\n/g, "</p><p>");
            if (!content.startsWith("<p>")) content = "<p>" + content;
            if (!content.endsWith("</p>")) content = content + "</p>";
            content = content.replace(/<p><\/p>/g, "");
            return content;
        },

        formatNumber: function(num, decimals = 2) {
            num = parseFloat(num);
            if (isNaN(num)) return '0';
            return num.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
        },

        copyToClipboard: function(text) {
            const tempTextArea = document.createElement('textarea');
            tempTextArea.value = text;
            document.body.appendChild(tempTextArea);
            tempTextArea.select();
            document.execCommand('copy');
            document.body.removeChild(tempTextArea);
        },

        countTokensSimple: function(text) {
            if (!text || typeof text !== 'string') return 0;
            const words = text.split(/[\s\u200c]+/).filter(Boolean);
            return words.length;
        },

        showNotification: function(message, type = "info") {
            const notification = $(`<div class="gglct-aio-notification animate__animated animate__fadeInRight ${type}">${message}</div>`);
            $('body').append(notification);
            setTimeout(() => {
                notification.addClass('animate__fadeOut');
                notification.one('animationend', () => notification.remove());
            }, 3000);
        },
    };

    $(document).ready(function() {
        if (typeof gglctAioParams !== 'undefined') {
            GGLCT_AIOP_APP.init();
        } else {
            console.error("GGLCT AI Optimizer Pro: gglctAioParams not defined.");
        }
    });

    // Debounce function from jQuery UI (simplified for direct inclusion if not present)
    // This is a common pattern for debounce. If jQuery UI is loaded, it might have its own.
    if (typeof $.debounce === 'undefined') {
        $.debounce = function(delay, at_begin, func) {
            return func === undefined ?
                (at_begin, func) :
                function() {
                    const self = this, args = arguments;
                    clearTimeout(func.debounce_timer);
                    func.debounce_timer = setTimeout(function() {
                        func.apply(self, args);
                    }, delay);
                };
        };
    }

})(jQuery, typeof gglctAioParams !== 'undefined' ? gglctAioParams : {});

</script>
<style>
/* GGLCT AI Optimizer Pro Gutenberg Editor Styles */
.gglct-aio-generated-block-content {
    background: #fdfdfd;
    border: 1px dashed #c3c4c7;
    padding: 15px;
    border-radius: 5px;
    min-height: 100px;
    white-space: pre-wrap;    word-wrap: break-word;
    color: #333;
    line-height: 1.6;
    font-size: 1em;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
}
.gglct-aio-generated-block-content p { margin-bottom: 1em; }
.gglct-aio-generated-block-content h2, .gglct-aio-generated-block-content h3 {
    margin-top: 1.5em;
    margin-bottom: 0.8em;
    color: #005177;
}
</style>
<script>
/* GGLCT AI Optimizer Pro Gutenberg Block */
(function(blocks, element, editor, components, i18n, data, $) {
    const el = element.createElement;
    const { registerBlockType } = blocks;
    const { TextControl, SelectControl, Button, Spinner, TextareaControl, RangeControl } = components;
    const { useDispatch, useSelect } = data;
    const __ = i18n.__;
    const { ajaxUrl, nonce, strings, pluginUrl, postId, postType, defaultTextModel, allTextModelsData, defaultMaxTokens, defaultTemperature } = gglctAioGbParams;

    registerBlockType('gglct-ai-optimizer-pro/ai-content-generator', {
        title: __('تولید محتوا با GGLCT AI', 'gglct-ai-optimizer-pro'),
        icon: 'text',
        category: 'common',
        attributes: {
            prompt: {
                type: 'string',
                source: 'meta',
                meta: '_gglct_aio_prompt',
            },
            generatedHTML: {
                type: 'string',
                source: 'meta',
                meta: '_gglct_aio_generated_html',
            },
            model: {
                type: 'string',
                default: defaultTextModel,
            },
            maxTokens: {
                type: 'number',
                default: defaultMaxTokens,
            },
            temperature: {
                type: 'number',
                default: defaultTemperature,
            },
            isLoading: {
                type: 'boolean',
                default: false,
            },
            errorMessage: {
                type: 'string',
                default: '',
            },
        },        edit: function(props) {
            const { attributes, setAttributes } = props;
            const { prompt, generatedHTML, model, maxTokens, temperature, isLoading, errorMessage } = attributes;

            const { editPost } = useDispatch('core/editor');

            const availableModels = allTextModelsData.map(m => ({ label: m.name || m.id, value: m.id }));

            const generateContent = () => {
                if (!prompt) {
                    setAttributes({ errorMessage: strings.promptRequired });
                    return;
                }
                setAttributes({ isLoading: true, errorMessage: '', generatedHTML: '' });

                $.ajax({
                    url: ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'gglct_aiop_generate_content',
                        nonce: nonce,
                        prompt: prompt,
                        model: model,
                        max_tokens: maxTokens,
                        temperature: temperature,
                        post_id: postId,
                        post_type: postType
                    },                    success: function(response) {
                        if (response.success) {
                            const formattedContent = GGLCT_AIOP_APP.formatGeneratedContent(response.data.content);
                            setAttributes({ generatedHTML: formattedContent });
                            editPost({ meta: { _gglct_aio_generated_html: formattedContent, _gglct_aio_prompt: prompt } });
                            GGLCT_AIOP_APP.showNotification(strings.contentGeneratedSuccess, 'success');
                        } else {
                            setAttributes({ errorMessage: response.data.message || strings.error });
                            GGLCT_AIOP_APP.showNotification(response.data.message || strings.error, 'error');
                        }
                    },
                    error: function() {
                        setAttributes({ errorMessage: strings.apiError });
                        GGLCT_AIOP_APP.showNotification(strings.apiError, 'error');
                    },
                    complete: function() {
                        setAttributes({ isLoading: false });
                    }
                });
            };

            return el('div', { className: 'gglct-aio-gutenberg-block-editor' },
                el(TextareaControl, {
                    label: __('پرامپت:', 'gglct-ai-optimizer-pro'),
                    value: prompt,
                    onChange: (newPrompt) => setAttributes({ prompt: newPrompt }),
                    placeholder: strings.promptPlaceholder,
                    rows: 4,
                }),                el(SelectControl, {
                    label: __('مدل:', 'gglct-ai-optimizer-pro'),
                    value: model,
                    options: availableModels,
                    onChange: (newModel) => setAttributes({ model: newModel }),
                }),
                el(RangeControl, {
                    label: __('حداکثر توکن خروجی:', 'gglct-ai-optimizer-pro'),
                    value: maxTokens,
                    onChange: (newMaxTokens) => setAttributes({ maxTokens: newMaxTokens }),
                    min: 50,
                    max: 4000,
                    step: 50,
                }),
                el(RangeControl, {
                    label: __('خلاقیت (0-2):', 'gglct-ai-optimizer-pro'),                    value: temperature,
                    onChange: (newTemp) => setAttributes({ temperature: newTemp }),
                    min: 0,
                    max: 2,
                    step: 0.1,
                }),
                el(Button, {
                    isPrimary: true,
                    onClick: generateContent,
                    disabled: isLoading,
                }, isLoading ? el(Spinner) : __('تولید محتوا', 'gglct-ai-optimizer-pro')),
                errorMessage && el('div', { className: 'gglct-aio-error-message', style: { color: 'red', marginTop: '10px' } }, errorMessage),
                generatedHTML && el('div', { className: 'gglct-aio-generated-content-preview', style: { border: '1px dashed #ccc', padding: '10px', marginTop: '20px', maxHeight: '300px', overflowY: 'auto' } },
                    el('h4', null, strings.generatedContentTitle),
                    el('div', { dangerouslySetInnerHTML: { __html: generatedHTML } })
                )
            );
        },
        save: function() {
            return null;
        },
    });
})(
    window.wp.blocks,
    window.wp.element,
    window.wp.editor,
    window.wp.components,
    window.wp.i18n,
    window.wp.data,
    jQuery
);
</script>
<script>
/* GGLCT AI Optimizer Pro TinyMCE Integration */
(function() {
    tinymce.PluginManager.add('gglct_aiop_tinymce_button', function(editor, url) {        editor.addButton('gglct_aiop_tinymce_button', {
            text: 'GGLCT AI',
            icon: false,
            image: 'GGLCT_AIOP_PLUGIN_URL' + 'assets/images/icon-gglct-ai-32.png', // Placeholder icon
            tooltip: 'تولید محتوا با GGLCT AI',
            onclick: function() {
                // Open the metabox if it's hidden, or trigger its content generation
                // This would typically involve opening a dialog or focusing the metabox
                // For simplicity, we'll just show a notification and log a message
                alert('GGLCT AI button clicked! Logic to open a dialog or trigger content generation would go here.');
                console.log('GGLCT AI TinyMCE button clicked. Implement dialog or direct generation here.');

                // Example: If you wanted a simple prompt dialog
                const prompt = prompt(gglctAioParams.strings.promptRequired);
                if (prompt) {
                    // Simulate AJAX call (replace with actual AJAX)
                    GGLCT_AIOP_APP.showLoading(gglctAioParams.strings.generatingContent);
                    setTimeout(() => {
                        const generatedContent = `<p>This is generated content for: <strong>${prompt}</strong> by GGLCT AI.</p>`;
                        editor.execCommand('mceInsertContent', false, generatedContent);
                        GGLCT_AIOP_APP.hideLoading();
                        GGLCT_AIOP_APP.showNotification(gglctAioParams.strings.contentGeneratedSuccess, 'success');
                    }, 1500);
                }
            }        });
    });
})();
</script>